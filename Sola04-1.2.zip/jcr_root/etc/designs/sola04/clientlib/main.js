/**
 * The main file to start the library.
 */

$(document).ready(function(){
	// Removes the 300ms delay for click events.
	FastClick.attach(document.body);

	// On Android for versions before 4.4.2 if the files are run locally and any url parameters
	// are added then the page will not render so only add a random number for non-android.
	// Math.random() is appended so files are not taken from the cache.
	var r = navigator.userAgent.toLowerCase().indexOf("android") == -1 ? "?r=" + Math.random() : "";

	// Specify an absolute path for development so a new IPA does not have to be created for each change.
	var path = "/etc/designs/sola04/clientlib/";//"http://lighthouse.adobe.com/users/derek/default_library_v3/";

	var jsFiles = [path + "DropDown.js" + r, 					// Drop down that displays a list of items to select from.
	               path + "FlipSwitch.js" + r,					// Horizontal switch that toggles between off and on.
	               path + "LibraryCollection.js" + r,				// Collection which stores the folio data for the library.
	               path + "ArchiveFolioItemView.js" + r,	// The folio item view for archiving.
	               path + "ArchiveView.js" + r,				// The view for archiving folios.
	               path + "LoginDialog.js" + r,				// Dialog used to display the login form.
	               path + "PreviewDialog.js" + r,			// Dialog used to display the folio preview.
	               path + "RestoreDialog.js" + r,			// Dialog used to display "restore purchases" confirmation.
	               path + "SubscribeDialog.js" + r,			// Dialog used to display the subscription options.
	               path + "FolioItemView.js" + r,		// Item renderer used to display a folio in the grid.
	               path + "SectionFolioItemView.js" + r,	// The folio item view for sections.
	               path + "SectionsView.js" + r,			// The view for downloading sections.
	               path + "AppView.js" + r,							// The application file which handles the main view.
	               path + "Config.js" + r];								// The config data for the application.

	var css = path + "styles.css" + r;

	var jsFilesLoaded = 0;
	var isOnline = false;

	function init() {
        loadAssets();
    }

	function loadAssets() {
		// Load the stylesheet.
		var el = document.createElement("link");
		el.setAttribute("rel", "stylesheet");
		el.setAttribute("type", "text/css");
		el.setAttribute("href", css);
		document.getElementsByTagName("head")[0].appendChild(el);

		loadJavaScriptFile(0);
	}
	
	function loadJavaScriptFile(index) {
		var path = jsFiles[index];
		var script = document.getElementsByTagName("script")[0];
		var el = document.createElement("script");
		el.onload = javascriptLoadHandler; 
		el.src = path;
		script.parentNode.insertBefore(el, script);
	}

	function javascriptLoadHandler() {
		jsFilesLoaded += 1;
		if (jsFilesLoaded == jsFiles.length) {
			new ADOBE.AppView(typeof adobeDPS != "undefined", isOnline);
		} else {
			loadJavaScriptFile(jsFilesLoaded);
		}
	}

    setTimeout(function(){
        if($("#emptyBox").height() != 42 && navigator.userAgent.match(/iPad/i) != null){
            location.reload();
        }
    }, 10000);

	// To test on the desktop remove the JavaScript include for AdobeLibraryAPI.js.
	if (typeof adobeDPS == "undefined") // Call init() immediately. This will be the case for dev on the desktop.
		init(); 
	else								// API is available so wait for adobeDPS.initializationComplete.
		adobeDPS.initializationComplete.addOnce(function(){init() });
});

/*function checkImg() {
	var img = document.getElementsByTagName("img")[0];
	img.onload = function() {
		setTimeout( start(), 10000);

        if(this.height = 460){
            setTimeout( start(), 1000);
        }
        else{
			setTimeout( checkImg(), 1000);
        }

	}
}

$(document).ready(function() {
	checkImg();
});*/