/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * Password-reset
 */
var validPasswordResetEmail = false;

function initPasswordResetPane() {
	addPasswordResetValidationEmail($('#passwordResetEmailInput'), onPasswordResetValidationEmail);
}

function showPasswordResetPane() {
	//window.location.hash = '#passwordReset';
	$('.dpsPasswordResetContainer').show();
}

function hidePasswordResetPane() {
	window.location.hash = '#';
	$('.dpsPasswordResetContainer').hide();
}

function onPasswordResetValidationEmail(result) {
	validPasswordResetEmail = result;
}

function getPasswordResetValidationResult() {
	return validPasswordResetEmail;
}

function passwordReset() {
	var email = document.getElementById("passwordResetEmailInput").value;
	if(!getPasswordResetValidationResult()||email==""){
		alert("Please input a valid email");
		return false;
	}
	updateLoadingIndicator(1);

    if (__DEBUG__) {
	    var json = jsonSignIn;
	    signInResult(json, '', null);
    }
    else {
	    var url = urlBase + "/PasswordReset";
	    $.ajax(
	    {
	        type : 'POST',
	        url : url,
	        data : {
	            emailAddress: email,
	        },
	        success : passwordResetResult,
	        dataType : "json"
	    });
    }
    return false;
}

function passwordResetResult(data, textStatus, jqXHR) {
	updateLoadingIndicator(-1);
	console.log(data);
	if (data.success) {
		alert("Password has been reset, please check your email for the temporary password.");
	} else {
		alert(data.message);
	}
	hidePasswordResetPane();
}
