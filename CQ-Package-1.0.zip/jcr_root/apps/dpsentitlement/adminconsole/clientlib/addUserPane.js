/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * addUserPane 
 */
var validAddUserFName = false;
var validAddUserLName = false;
var validAddUserEmail = false;
var validAddUserLoginName = false;
var validAddUserPassword = false;
var validAddUserPasswordConfirm = false;

function initAddUserPane() {
	addValidationNonEmpty($('#newUserFNameInput'), onAddUserValidationFName);
	addValidationNonEmpty($('#newUserLNameInput'), onAddUserValidationLName);
	addValidationEmail($('#newUserEmailInput'), onAddUserValidationEmail);
	addValidationNonEmpty($('#newUserPasswordInput'), onAddUserValidationPassword);
	addValidationConfirmPassword($('#newUserPasswordInputConfirm'), onAddUserValidationPasswordConfirm);

	$('#saveAddUserFolioButton').click(function() {
		addUserSubmit();
	});
	
	$('#newUserLoginNameInput').change(function() {
		setAddUserSetNeedsSave(true);
	});
	$('#newUserFolioManagementPermission').change(function() {
		setAddUserSetNeedsSave(true);
	});
	$('#newUserUserManagementPermission').change(function() {
		setAddUserSetNeedsSave(true);
	});
	$('#newUserCompanyManagementPermission').change(function() {
		setAddUserSetNeedsSave(true);
	});
	$('#newUserSettingManagementPermission').change(function() {
		setAddUserSetNeedsSave(true);
	});
	$('#newUserNotificationManagementPermission').change(function() {
		setAddUserSetNeedsSave(true);
	});
	$('#newUserUdidManagementPermission').change(function() {
		setAddUserSetNeedsSave(true);
	});
	
	
	$.ajax({
		url: urlBase + UDID_SERVICE_PATH,
		statusCode: {
			200: function() {
				$('#newUserUdidManagementRow').css('display', '');
			}
		}
	});
	
	$.ajax({
		url: urlBase + "/SendPushNotificationService",
		statusCode: {
			200: function() {
				$('#newUserNotificationManagementRow').css('display', '' );
			}
		}
	});
	
	$.ajax({
		url: urlBase + "/CompanyManagementService",
		statusCode: {
			200: function() {
				$('#newUserCompanyManagementRow').css('display', '' );
			}
		}
	});
}

function setAddUserSetNeedsSave(status) {
	addUserNeedsSave = status;
}

function addUserPageBlurHandler() {
	if (addUserNeedsSave) {
		if (confirm(DISCARD_CHANGES) == false)
			return false;
	}
	hideAddUserPane();
	return true;
}

function showAddUserPane() {
	if (!dpsPageBlurHandler())
		return;

	if (getCurrentCompany() != null && getCurrentCompany() != "") {
		$('#newUserCompanyManagementRow').hide();
	}
	// Need to clear and trigger validation routines before clear the NeedsSave flag...
	clearUserFolioFields();

	setAddUserSetNeedsSave(false);
	dpsPageBlurHandler = addUserPageBlurHandler;

	$('#dpsAddUser').fadeIn(kTransitionDuration);
	$('#dpsManageUsers').fadeOut(0);
	$('#showUsersConsoleButton').addClass('active');
	$('#showGroupsConsoleButton').removeClass('active');
	$('#dpsManageGroups').fadeOut(0);
	
	userManagementAddEditUserGroupButtonVisibility(false);

	resizePane($('#dpsAddUser'),-13);
}

function hideAddUserPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

	$('#dpsAddUser').fadeOut(0);
	if (userManagementUserConsoleSelected) {
		$('#dpsManageUsers').fadeIn(kTransitionDuration);
		$('#dpsManageGroups').fadeOut(0);
		$('#showUsersConsoleButton').addClass('active');
		$('#showGroupsConsoleButton').removeClass('active');
	}
	else {
		$('#dpsManageUsers').fadeOut(0);
		$('#dpsManageGroups').fadeIn(kTransitionDuration);
		$('#showUsersConsoleButton').removeClass('active');
		$('#showGroupsConsoleButton').addClass('active');
	}

	userManagementAddEditUserGroupButtonVisibility(true);
}

function clearUserFolioFields() {
	$('#newUserFNameInput').val('');
	$('#newUserLNameInput').val('');
	$('#newUserEmailInput').val('');
	$('#newUserLoginNameInput').val('');
	$('#newUserPasswordInput').val('');
	$('#newUserPasswordInputConfirm').val('');

	$('#newUserFNameInput').keyup();
	$('#newUserLNameInput').keyup();
	$('#newUserEmailInput').keyup();
	$('#newUserLoginNameInput').keyup();
	$('#newUserPasswordInput').keyup();
	$('#newUserPasswordInputConfirm').keyup();
}

/* validation */
function onAddUserValidationFName(result) {
	validAddUserFName = result;
	setAddUserSetNeedsSave(true);
	freshAddUserValidationStatus();
}

function onAddUserValidationLName(result) {
	validAddUserLName = result;
	setAddUserSetNeedsSave(true);
	freshAddUserValidationStatus();
}

function onAddUserValidationEmail(result) {
	validAddUserEmail = result;
	setAddUserSetNeedsSave(true);
	freshAddUserValidationStatus();
}

function onAddUserValidationLoginName(result) {
	validAddUserLoginName = result;
	setAddUserSetNeedsSave(true);
	freshAddUserValidationStatus();
}

function onAddUserValidationPassword(result) {
	validAddUserPassword = result;
	setAddUserSetNeedsSave(true);
	freshAddUserValidationStatus();
}

function onAddUserValidationPasswordConfirm(result) {
	validAddUserPasswordConfirm = result;
	setAddUserSetNeedsSave(true);
	freshAddUserValidationStatus();
}

function getAddUserValidationResult() {
	return validAddUserFName && validAddUserLName && validAddUserEmail && 
		validAddUserPasswordConfirm && validAddUserPassword;
}

function freshAddUserValidationStatus() {
	$('#saveAddUserFolioButton').prop('disabled', !getAddUserValidationResult());
}

/* submittion */
function addUserSubmit() {
    if (__DEBUG__) {
	    var json = jsonAddUser_addUser;
	    addUserSubmitResult(json, '', null);
	    console.warn("DEBUG addUserSubmit");
	}
    else {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, "addUser");
	    ajaxPost(url,
	        {
	        	'firstName' : $('#newUserFNameInput').val(),
	        	'lastName' : $('#newUserLNameInput').val(),
	        	'email' : $('#newUserEmailInput').val(),
	        	'loginName' : $('#newUserLoginNameInput').val(),
	        	'password' : $('#newUserPasswordInput').val(),
	        	'productPrivilege' : $('#newUserFolioManagementPermission').val(),
	        	'userPrivilege' : $('#newUserUserManagementPermission').val(),
	        	'companyPrivilege' : $('#newUserCompanyManagementPermission').val(),
	        	'settingPrivilege' : $('#newUserSettingManagementPermission').val(),
	        	'notificationPrivilege' : $('#newUserNotificationManagementPermission').val(),
	        	'udidPrivilege' : $('#newUserUdidManagementPermission').val()
	        },
	        addUserSubmitResult);
    }
}

function addUserSubmitResult(data) {
    if (data.success) {
    	hideAddUserPane();
    	hideManageGroupsPane();
    	showManageUsersPane(data.data.id);
    }
    else {
        alert(data.message);
    }
}