/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/**
 * pushNotificationPane
 */
var pushNotificationUserJson = [];
var pushNotificationGroupJson = [];

function initPushNotificationPane() {
	$("#adminNotification").click(function() {
		togglePushNotificationPane();
		return false;
	});
	
	$('#sendPushNotificationButton').click(function() {
		pushNotificationSubmit();
		return false;
	});
	
	$('#pushNotificationNumberInput').on('focus', function() {
		hidePushNotificationUserSuggestionPane();
	});
	$('#pushNotificationMessageInput').on('focus', function() {
		hidePushNotificationUserSuggestionPane();
	});

	$('#pushNotificationMessageInput').keyup(function() {
		validatePushNotificationFields();
	});
	$('#pushNotificationMessageInput').change(function() {
		validatePushNotificationFields();
	});
	
	$('#pushNotificationNumberInput').on('keyup paste change', function() {
		validatePushNotificationFields();
	});

	$('#pushNotificationMessageInput').autogrow();
	
	// Setup tags input
	$('#pushNotificationSendToInput').tagsInput({
		width: '308px',
		height: 'auto',
		autocomplete_url: {source: []}
	});
	$('#pushNotificationSendToInput_tag').on('keyup change paste', function() {
		updatePushNotificationUserFilter();
		validatePushNotificationFields();
	});
}

function setPushNotificationSetNeedsSave(status) {
	pushNotificationNeedsSave = status;
}

function pushNotificationPageBlurHandler() {
	var sendTo = $('#pushNotificationSendToInput').val().trim();
    var number = $('#pushNotificationNumberInput').val().trim();
    var msg = $('#pushNotificationMessageInput').val().trim();
    
    if (sendTo.length == 0 && number.length == 0 && msg.length == 0)
    	return true;

	if (pushNotificationNeedsSave) {
		if (confirm(DISCARD_PUSH_NOTIFICATION_MESSAGE) == false)
			return false;
	}
	setPushNotificationSetNeedsSave(false);
	return true;
}

function disablePushNotifiaction() {
	$('#adminNotification').hide();
}

function enablePushNotifiaction() {
	$('#adminNotification').show();
}

function showPushNotificationPane() {
	// Need to clear and trigger validation routines before clear the NeedsSave flag...
	clearPushNotificationFields();
	setPushNotificationSetNeedsSave(false);

	$('#pushNotificationPopup').removeClass('hide');
	$('#pushNotificationSendToInput').importTags('');
	updatePushNotificationPane();
	refreshPushNotificationUserList();
	clearPushNotificationUserList();
}

function hidePushNotificationPane() {
	if (!pushNotificationPageBlurHandler())
		return;

	setPushNotificationSetNeedsSave(false);
	$('#pushNotificationPopup').addClass('hide');
	updatePushNotificationPane();
}

function clearPushNotificationUserList() {
	$('#pusNotificationUserContainer').hide();
	$('#pushNotificationSendToInput_tag').val('');
}

function togglePushNotificationPane() {
	if ($('#pushNotificationPopup').hasClass('hide')) {
		showPushNotificationPane();
	}
	else {
		hidePushNotificationPane();
	}
}

function updatePushNotificationPane() {
	if ($('#pushNotificationPopup').hasClass('hide')) {
		$('#pushNotificationOverlay').css('display', 'none');
	}
	else {
		$('#pushNotificationOverlay').css('display', 'block');
	}
}

function clearPushNotificationFields() {
    $('#pushNotificationMessageInput').val('');
}

function validatePushNotificationFields() {
	var ok = $('#pushNotificationSendToInput').val().length > 0 && $('#pushNotificationMessageInput').val().length > 0;
	var number = $('#pushNotificationNumberInput').val();
	if (number.length > 0 && isNaN(number))
		ok = false;
	$('#sendPushNotificationButton').prop('disabled', ok ? '' : 'disabled');
	setPushNotificationSetNeedsSave(true);
}

/* submittion */
function pushNotificationSubmit() {
	if (!validateSession())
		return;

    updateLoadingIndicator(1);
    if (__DEBUG__) {
	    var json = jsonSettings_sendPushNotificationOp;
	    editUserSubmitResult(json, '', null);
	    console.warn("DEBUG pushNotificationSubmit");
	}
    else {
    	var emailList = $('#pushNotificationSendToInput').val().split(',');
    	var url = urlBase + '/SendPushNotificationService';
		var msgData = {
        	'authToken': getAuthToken(),
        	'emailAddressList' : emailList,
        	'badge' : $('#pushNotificationNumberInput').val(),
        	'body' : $('#pushNotificationMessageInput').val()
        };

	    $.ajax(
	    {
	        type : 'POST',
	        url : url,
	        data : msgData,
	        success : pushNotificationSubmitResult,
	        error: pushNotificationSubmitError,
	        dataType : "json"
	    });
    }
}

function pushNotificationSubmitResult(data, textStatus, jqXHR) {
	updateLoadingIndicator(-1);
    if (!validateResponse(data)) {
    }
    else if (data.success) {
    	setPushNotificationSetNeedsSave(false);
    	hidePushNotificationPane();
    	alert('Push notification sent');
    }
    else {
        alert('Unable to send push notification');
    }
}

function pushNotificationSubmitError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('pushNotificationSubmitError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}

/* user name suggestion */
function showPushNotificationUserSuggestionPane() {
	$('#pusNotificationUserContainer').fadeIn(0);
}

function hidePushNotificationUserSuggestionPane() {
	$('#pusNotificationUserContainer').fadeOut(0);
}

/* list all users */
function refreshPushNotificationUserList() {
	if (!validateSession())
		return;

    updateLoadingIndicator(1);
    if (__DEBUG__) {
    	var json = jsonManageUsers_listUsers;
    	listPushNotificationUserResult(json, '', null);
    	console.warn("DEBUG refreshPushNotificationUserList");
    }
    else {
		var url = urlBase + USER_MANAGEMENT_SERVICE_PATH;
	    $.ajax(
	    {
	        type : 'GET',
	        url : url,
	        data : {
	        	'authToken': getAuthToken(),
	        	'action': LIST_USER_SERVICE
	        },
	        success : listPushNotificationUserResult,
	        error: listPushNotificationUserError,
	        dataType : "json"
	    });
    }
}

function listPushNotificationUserResult(data, textStatus, jqXHR) {
    if (!validateResponse(data)) {
    	pushNotificationUserJson = [];
    }
    else if (data.success) {
    	pushNotificationUserJson = data.items;
    	refreshPushNotificationGroupList();
    	return;
    }
    else {
        alert('Unable to retrieve users info');
    }
    updateLoadingIndicator(-1);
}

function listPushNotificationUserError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('listPushNotificationUserError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}

/* list all groups */
function refreshPushNotificationGroupList() {
    if (__DEBUG__) {
    	var json = jsonManageUsers_listGroups;
    	listPushNotificationGroupResult(json, '', null);
    	console.warn("DEBUG refreshPushNotificationGroupList");
    }
    else {
		var url = urlBase + GROUP_MANAGEMENT_SERVICE_PATH;
	    $.ajax(
	    {
	        type : 'GET',
	        url : url,
	        data : {
	        	'authToken': getAuthToken(),
	        	'action': LIST_GROUP_SERVICE
	        },
	        success : listPushNotificationGroupResult,
	        error: listPushNotificationGroupError,
	        dataType : "json"
	    });
    }
}

function listPushNotificationGroupResult(data, textStatus, jqXHR) {
    if (!validateResponse(data)) {
    	pushNotificationGroupJson = [];
    }
    else if (data.success) {
    	pushNotificationGroupJson = data.items;
    	refreshPushNotificationUserTable();
    }
    else {
        alert(LIST_GROUP_ERROR);
    }
    updateLoadingIndicator(-1);
}

function listPushNotificationGroupError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('listPushNotificationUserError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}

function refreshPushNotificationUserTable() {
	var json = pushNotificationCombineUserGroupLists();
	if (json == null)
		return false;

	var table = document.createElement('table');
    table.id = 'pushNotificationUserSuggestionTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    if (json != null) {
	    for(i = 0; i < json.length; i++) {
	        var row = document.createElement('tr');
	        json[i].row = row;
	        row.setAttribute('name', json[i].name);
	        if (json[i].objId != null)
	        	row.setAttribute('objId', json[i].objId);
	        row.onclick = selectPushNotificationUser;
	        tbody.appendChild(row);

	        var displayText = getPushNotificationUserCellDisplayHtml(json[i].name, json[i].objId);
	        cell = createTableData(row, displayText);
	    }
    }

	$('#pusNotificationUserContainer').html('');
    $('#pusNotificationUserContainer').append(table);
    
    return true;
}

function getPushNotificationUserCellDisplayHtml(name, id) {
	if (id == null)
		return name;
	return '"' + name + '" &lt;' + id + '&gt;';
}

function getPushNotificationUserCellDisplayText(name, id) {
	if (id == null)
		return name;
	return '"' + name + '" <' + id + '>';
}

function pushNotificationCombineUserGroupLists() {
	var list = [];
	
	if (pushNotificationUserJson != null) {
		var json = pushNotificationUserJson;
		for(i = 0; i < json.length; i++) {
			list.push({
				'name': json[i].name,
				'objId': json[i].id
			});
		}
	}
	
	if (pushNotificationGroupJson != null) {
		var json = pushNotificationGroupJson;
		for(i = 0; i < json.length; i++) {
			list.push({
				'name': json[i].name,
				'objId': json[i].id
			});
		}
	}
	
	return list;
}

function selectPushNotificationUser(e) {
	hidePushNotificationUserSuggestionPane();

	var name = $(this).attr('name');
	var id = $(this).attr('objId');
	var user = getPushNotificationUserCellDisplayText(name, id);
	$('#pushNotificationSendToInput').addTag(user,{focus:true,unique:true});
}

/*
 * Filtering
 */
function updatePushNotificationUserFilter() {
	var keyword = getPushNotificationUserKeyword();
	
	if (keyword == null || keyword.length == 0) {
		hidePushNotificationUserSuggestionPane();
		return;
	}

	var showAll = keyword == '*';
	var found = showAll;
	//keyword = keyword.toLowerCase();
	$('#pushNotificationUserSuggestionTable').find('tr').each(function() {
		var name = $(this).attr('name');
		var id = $(this).attr('objId');
		var match = false;
		var displayText = getPushNotificationUserCellDisplayHtml(name, id);
		var child = $(this).children()[0];
		child.innerText = displayText;

		if (showAll) {
			match = true;
		}
		else {
			var regex = RegExp(keyword, 'ig');
			var newName = name.replace(regex, "<span class='highlight'>$&</span>");
			if (newName != name) {
				child.innerHTML = getPushNotificationUserCellDisplayHtml(newName, id);
				match = true;
			}
		}

		if (match) {
			$(this).css('display', '');
			found = true;
		}
		else {
			$(this).css('display', 'none');
		}
	});
	
	if (found)
		showPushNotificationUserSuggestionPane();
	else
		hidePushNotificationUserSuggestionPane();
}

function getPushNotificationUserKeyword() {
	var user = $('#pushNotificationSendToInput_tag').val().trim();
	return user;
}
