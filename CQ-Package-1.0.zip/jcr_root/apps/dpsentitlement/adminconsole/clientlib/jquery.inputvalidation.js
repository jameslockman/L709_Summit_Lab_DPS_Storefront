/*
 * jQuery Input Validation Plugin 1.0.0
 */

(function($) {
	var form_settings = new Array();

	$.fn.inputValidation = function(options) {
		var id = $(this).attr('id');
		if (!id || form_settings[$(this).attr('id')]) {
			id = $(this).attr('id', 'tags' + new Date().getTime()).attr('id');
		}

		var settings = jQuery.extend({
			rules: '',
			defaultText: '',
			onResult: function(obj, result) {},
			onModified: function(obj) {},
			onChanged: function(obj) {},
		}, options);
		form_settings[id] = settings;

		for(var elemName in settings.rules) {
			var elem = $('#' + elemName);
			var elemRules = eval('settings.rules.' + elemName);
			elem.attr('data-form-name', id);
			elem.attr('data-group', elemRules.group);

			elem.on('keyup change paste', function() {
				var id = $(this).attr('data-form-name');
				var group = $(this).attr('data-group');
				if (group) {
					$('#' + id).find('[data-group=' + group + ']').each(function() {
						$.fn.inputValidation.setModified($(this));
					});
				}
				else
					$.fn.inputValidation.setModified($(this));
				$.fn.inputValidation.validate($('#' + id));
			});

			elem.on('focus', function() {
				var id = $(this).attr('data-form-name');
				var defaultText = $(this).attr('data-default');
				if (defaultText && $(this).val() == defaultText) {
					var group = $(this).attr('data-group');
					if (group) {
						$('#' + id).find('[data-group=' + group + '][data-modified=no]').each(function() {
							$(this).val('');
						});
					}
					else {
						$(this).val('');
					}
					$.fn.inputValidation.validate($('#' + id));
				}
			});

			elem.on('blur', function() {
				var id = $(this).attr('data-form-name');
				if ('no' == $(this).attr('data-modified')) {
					var group = $(this).attr('data-group');
					if (group) {
						$('#' + id).find('[data-group=' + group + '][data-modified=no]').each(function() {
//							$(this).val($(this).attr('data-default'));
							$.fn.inputValidation.restoreDefault($(this));
						});
					}
					else {
//						$(this).val($(this).attr('data-default'));
						$.fn.inputValidation.restoreDefault($(this));
					}
					$.fn.inputValidation.validate($('#' + id));
				}
			});
		}
		$('#' + id).setDefaultText(settings);
	};

	//
	// Set default text
	//
	// Syntax:
	// $('#form_name').setDefaultText({
	//	input_id: 'text',
	//	input_2_id: 'text'
	//	});
	//
	$.fn.setDefaultText = function(settings) {
		var id = $(this).attr('id');
		for(var elemName in settings) {
			var elem = $('#' + id).find('#' + elemName);
			var text = eval('settings.' + elemName);
			elem.attr('data-default', text);
			$.fn.inputValidation.clearModified(elem);
			elem.val(text);
		}
		form_settings[id].defaultText = settings;
		$.fn.inputValidation.validate($('#' + id));
	};

	// Set value will clear the default text
	$.fn.setValue = function(settings) {
		var id = $(this).attr('id');
		for(var elemName in settings) {
			var text = eval('settings.' + elemName);
			var elem = $('#' + id).find('#' + elemName);
			if (elem.is('input')) {
				elem.removeAttr('data-default');
				elem.val(text);
			}
			else if (elem.is('select')) {
				elem.find('option').each(function() {
					var selected = $(this).val() === '' + text; 
					$(this).prop('selected', selected);
				});
			}
			$.fn.inputValidation.clearModified(elem);
		}
		form_settings[id].defaultText = '';
		$.fn.inputValidation.validate($('#' + id));
	};
	
	$.fn.inputValidation.setGroupAttr = function(form, group, attr, value) {
		var id = $(form).attr('id');
		$('#' + id).find('[data-group=' + group + ']').each(function() {
			$(this).attr(attr, value);
		});
	}
	
	$.fn.inputValidation.validateInput = function(element, settings) {
		var ok = true;
		for(var rule in settings) {
			var properties = eval('settings.' + rule);

			if (typeof properties != 'object')
				continue;

			switch(rule.toLowerCase()) {
			case 'required':
				if (properties.value)
					ok = ok && element.val().length > 0;
				break;
			case 'callback':
				var callback = properties.value;
				ok = ok && callback.call(this, element);
				break;
			case 'minlength':
				ok = ok && element.val().length >= properties.value;
				break;
			case 'equalto':
				var compareElem = $(properties.value);
				if (compareElem) {
					ok = ok && element.val() == compareElem.val();
				}
			}
			if (!ok) {
				if (settings.label) {
					if (properties.message)
						$(settings.label).html(properties.message);
					$(settings.label).css('display', ok ? 'none' : '');
				}
				break;
			}
		}
		if (ok && settings.label)
			$(settings.label).css('display', 'none');

		return ok;
	}

	// elements: space delimited string
	$.fn.inputValidation.validate = function(obj, elements) { 
		var id = $(obj).attr('id');
		var formSettings = form_settings[id];
		var isValidOrigVal = $('#' + id).attr('data-valid');
		var ok = true;
		var elemArr = elements ? elements.split(' ') : [];

		for(var elemName in formSettings.rules) {
			var elem = $('#' + elemName);
			if (!elements || elemArr.hasObject(elem)) {
				var settings = eval('formSettings.rules.' + elemName);
				var elemOk = $.fn.inputValidation.validateInput(elem, settings);
				ok = ok && elemOk;
			}
		}

		$('#' + id).attr('data-valid', ok);
		if (isValidOrigVal != '' + ok)
			formSettings.onResult.call($('#' + id), ok);
		return ok;
	};
	
	$.fn.isModified = function() {
		var id = $(this).attr('id');
		var modified = $('#' + id).find('[data-modified=yes]').length > 0 || 
			$('#' + id).attr('data-modified') === 'yes';
		return modified;
	}
	
	$.fn.isValid = function() { 
		var id = $(this).attr('id');
		var valid = $('#' + id).attr('data-valid') == 'true';
		return valid;
	}

	// obj - input control
	$.fn.inputValidation.setModified = function(obj) {
		var id = obj.attr('data-form-name');
		var formSettings = form_settings[id];
		formSettings.onChanged.call($('#' + id));

		var orig = obj.attr('data-modified');
		obj.attr('data-modified', 'yes');
		if (orig != 'yes') {
			formSettings.onModified.call($('#' + id));
			return true;
		}
		return false;
	}
	
	$.fn.inputValidation.clearModified = function(obj) {
		obj.attr('data-modified', 'no');
	}
	
	$.fn.inputValidation.restoreDefault = function(obj) {
		var dataDefault = obj.attr('data-default');
		if (dataDefault)
			obj.val(dataDefault);
	}

	Array.prototype.hasObject = (
		!Array.indexOf ? function(o) {
			var l = this.length + 1;
		    while (l -= 1) {
		    	if (this[l - 1] === o) {
		        	return true;
		        }
		    }
		    return false;
		} : function (o) {
			return (this.indexOf(o) !== -1);
		}
	);
})(jQuery);