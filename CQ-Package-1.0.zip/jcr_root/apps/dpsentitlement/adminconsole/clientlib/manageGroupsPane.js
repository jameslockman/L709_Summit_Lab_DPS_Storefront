/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * manageGroupsPane 
 */
var dpsGroupsJson = null;
var manageGroupLastSelectedRow = null;
var autoScrollToGroupId = null;
var manageGroupSelectedGroup;
var groupDetailUserList = null;

function initManageGroupsPane() {
	groupDetailUserList = new PagedList('groupDetailUsersContainer', 'groupDetailUsersContainerTable', null, 'user', userNameOnlyRenderer, toggleGroupDetailUsersTableRow, onGroupDetailUserDataLoaded);

	resizePane($('#dpsAllGroupsFolioTableContainer'),72);
	$('#manageGroupEditGroup').click(function() {
		if (groupDetailUserList.isAllLoaded())
			manageGroupSelectedGroup.users = groupDetailUserList.items;
		showEditGroupPane(manageGroupSelectedGroup);
		resizePane($('#dpsEditGroup'),-13);
	});

	$('#manageGroupDeleteGroup').click(function() {
		manageGroupDeleteGroup();
	});
	
	$('#manageGroupDeleteMultiGroups').click(function() {
		manageGroupDeleteGroup();
	});
}

function showManageGroupsPane(scrollToGroup) {
	if (!dpsPageBlurHandler())
		return;
	resizePane($('#dpsAllGroupsFolioTableContainer'),-4);
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

	$('#dpsManageGroups').fadeIn(kTransitionDuration);
	$('#showUsersConsoleButton').removeClass('active');
	$('#showGroupsConsoleButton').addClass('active');
	$('#dpsManageUsers').fadeOut(0);

	userManagementAddEditUserGroupButtonVisibility(true);
	userManagementUserConsoleSelected = false; // managing groups
	$('#dpsUserManagementSearchInput').val(''); // reset the search field empty
	
	$('#userLoadedPrompt').text('');
	refreshAllGroupsFolio(scrollToGroup);
	hideUserFolio();
	hideGroupFolio();
}

function hideManageGroupsPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;
	$('#dpsManageGroups').fadeOut(0);
}

function getGroupId(json) {
	if (json.id == null)
		return json.name;
	return json.id;
}

function toggleAllGroupsRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (manageGroupLastSelectedRow != null) {
			var lastIndex = getItemIndex($('#allGroupsFolioTable'), manageGroupLastSelectedRow);
			var index = getItemIndex($('#allGroupsFolioTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}

			$('#allGroupsFolioTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#allGroupsFolioTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		$('#allGroupsFolioTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).toggleClass("dpsSelected");
	}
	manageGroupLastSelectedRow = this;

	refreshGroupsFolioDetail();
}

function getGroupById(id) {
	var group = null;
	if (dpsGroupsJson == null)
		return null;
	
	$(dpsGroupsJson).each(function() {
		if (this.id === id) {
			group = this;
			return;
		}
	});
	return group;
}

function hideGroupFolio() {
	$("#singleGroupFolioSelected").fadeOut(kTransitionDuration);
    $("#multipleGroupsFolioSelected").fadeOut(kTransitionDuration);
    hideAddGroupPane();
    hideEditGroupPane();
}

function refreshGroupsFolioDetail(){
    var selected = $('#allGroupsFolioTable').find('.dpsSelected');
    var count = selected.length;
    if (count == 0) {
        $("#singleGroupFolioSelected").fadeOut(kTransitionDuration);
        $("#multipleGroupsFolioSelected").fadeOut(kTransitionDuration);
    }
    else if (count == 1) {
    	showSingleGroupFolioForId($(selected).attr('objId'));
    }
    else {
    	showMultiGroupsFolio();
    }
}

function showSingleGroupFolioForId(id) {
	var group = getGroupById(id);
	if (group != null)
		$("#selectedGroupNameLabel").html(group.name);

	$("#groupFolioGroupNameInput").val('');
	$("#groupFolioGroupDescriptionInput").val('');

	$("#singleGroupFolioSelected").fadeIn(kTransitionDuration);
    $("#multipleGroupsFolioSelected").fadeOut(0);

	refreshGroupDetail(id);
}

function showMultiGroupsFolio() {
	$("#singleGroupFolioSelected").fadeOut(0);
    $("#multipleGroupsFolioSelected").fadeIn(kTransitionDuration);
    
    var nameList = selectedReadOnlyGroups();
    if (nameList.length > 0) {
    	$("#manageGroupDeleteMultiGroups").hide();
    	$("#manageGroupDeleteMultiGroupsWarning").show();
    	$("#readOnlyGroups").show();
    	$("#readOnlyGroups").text(nameList.join(", "));
    } else {
    	$("#manageGroupDeleteMultiGroups").show();
    	$("#manageGroupDeleteMultiGroupsWarning").hide();
    	$("#readOnlyGroups").hide();
    }
}

function selectedReadOnlyGroups() {
	var selected = $('#allGroupsFolioTable').find('.dpsSelected');
	var nameList = new Array();
	for (i = 0; i < selected.length; i++) {
		var group = getGroupById(selected[i].getAttribute('objId'));
		if (group.isReadOnly) {
			nameList.push(group.name);
		}
	}
	return nameList;
}

function refreshAllGroupsFolio(scrollToGroup) {
	autoScrollToGroupId = scrollToGroup;
    if (__DEBUG__) {
    	var json = jsonManageGroups_listGroups;
    	listAllGroupsFolioResult(json, '', null);
    	console.warn("DEBUG refreshAllGroupsFolio");
    }
    else {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_GROUP_SERVICE);
	    ajaxGet(url, listAllGroupsFolioResult);
    }
}

function listAllGroupsFolioResult(data) {
    if (data.success) {
    	refreshAllGroupsFolioTable(data.data);
    }
    else {
    	refreshAllGroupsFolioTable([]);
        alert(data.message);
    }
}

function refreshAllGroupsFolioTable(json) {
	dpsGroupsJson = json;

	var table = document.createElement('table');
    table.id = 'allGroupsFolioTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    if (json != null) {
	    for(i = 0; i < json.length; i++) {
	        var row = document.createElement('tr');
	        json[i].row = row;
	        row.setAttribute('objId', getGroupId(json[i]));
	        row.setAttribute('objName', json[i].name);
	        row.onclick = toggleAllGroupsRow;
	        tbody.appendChild(row);
	
	        if (json[i].isReadOnly) {
	        	var cell = createTableData(row, json[i].source.toUpperCase());
	        	cell.innerHTML="<p>" + json[i].source.toUpperCase() + "</p><span>" + json[i].source.toUpperCase() + " groups are not editable or removable</span>";
	        	cell.className = 'ldapGroupLabel';
	        }else {
	        	var cell = createTableData(row, "");
	        }
	        
	        createTableData(row, json[i].name);
	    }
    }

	$('#dpsAllGroupsFolioTableContainer').html('');
    $('#dpsAllGroupsFolioTableContainer').append(table);
    
    if (autoScrollToGroupId != null) {
    	$(json).each(function(){
    		if (this.id === autoScrollToGroupId) {
    			var howMuchToScroll = $(this.row).offset().top - $('#allGroupsFolioTable').offset().top - $(this.row).height();
    	    	$('#dpsAllGoupsFolioTableContainer').scrollTop(howMuchToScroll);
    	    	$(this.row).addClass('dpsSelected');
    	    	showSingleGroupFolioForId(autoScrollToGroupId);
    	    	return;
            }    		
    	});
    	autoScrollToGroupId = null;
    }
}

/*
 * Get group detail
 */
function toggleGroupDetailUsersTableRow() {
    $(this).toggleClass("dpsSelected");
}

function refreshGroupDetail(groupId) {
    if (__DEBUG__) {
    	var json = jsonManageGroups_getGroupDetail;
    	getGroupDetailResult(json, '', null);
    	console.warn("DEBUG getGroupDetail");
    }
    else {
    	var group = getGroupById(groupId);
    	refreshGroupDetailUserTable(group);
    }
}

function refreshGroupDetailUserTable(group) {
	manageGroupSelectedGroup = group;
	$('#groupDetailGroupsContainer').html('');
	$('#groupDetailUsersContainer').html('');
	if (group == null) {
		$('#manageGroupEditGroup').hide();
		$('#manageGroupDeleteGroup').hide();
		$("#selectedGroupNameLabel").html('');
		$("#groupFolioGroupNameInput").val('');
		$("#groupFolioGroupDescriptionInput").val('');
	}
	else {
		if (getUserPrivilege() === 'READ_WRITE' && !group.isReadOnly) {
			$('#manageGroupEditGroup').show();
			$('#manageGroupDeleteGroup').show();
		}
		else {
			$('#manageGroupEditGroup').hide();
			$('#manageGroupDeleteGroup').hide();
		}
			
		if (group.isReadOnly) {
			$("#selectedGroupNameLabel").html('<span>' + group.source.toUpperCase() + '</span> ' + group.name);
		} 
		else {
			$("#selectedGroupNameLabel").html(group.name);
		}
		$("#groupFolioGroupNameInput").val(group.name);
		$("#groupFolioGroupDescriptionInput").val(group.description);
	
		$('#groupDetailGroupsContainer').html('');
		$('#groupDetailUsersContainer').html('');
		
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'listGroupsInGroup') + "&group=" + group.id;
	    ajaxGet(url, listGroupsInGroupResult);
	    url = getActionUrl(USER_MANAGEMENT_SERVICE, 'listUsersInGroup') + "&group=" + group.id;
	    groupDetailUserList.url = url;
	    groupDetailUserList.showList(0);
	}
}

function listGroupsInGroupResult(data) {
	if (data.success) {
		manageGroupSelectedGroup.groups = data.data;
		updateGroupChildren("groupDetailGroupsContainer", manageGroupSelectedGroup.groups);
	}
	else {
		manageGroupSelectedGroup.groups = [];
		alert(data.message);
	}
}

function updateGroupChildren(container, items) {
	var table = document.createElement('table');
	table.id = container + "table";

	var tbody = document.createElement('tbody');
	table.appendChild(tbody);

	for(i = 0; i < items.length; i++) {
	    var row = document.createElement('tr');
	    row.setAttribute('objId', items[i].id || '');
	    tbody.appendChild(row);

     	createTableData(row, items[i].name || '');
	}

    $("#" + container).append(table);
}

/* delete group */
function manageGroupDeleteGroup() {
	var count = 0;
	var groupList = '';
	var selected = $('#allGroupsFolioTable').find('.dpsSelected').each(function() {
		if (groupList.length > 0)
			groupList += ',';
		groupList += $(this).attr('objId');
		count++;
	});
	
	var confirmMsg = DELETE_GROUP_CONFIRMATION;
	var answer = confirm(confirmMsg);
	if (!answer)
		return;

	if (__DEBUG__) {
    	var json = jsonManageGroups_deleteGroup;
    	manageGroupDeleteGroupResult(json, '', null);
    	console.warn("DEBUG manageGroupDeleteGroup");
    }
    else {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'deleteGroups') + '&ids=' + groupList;
	    ajaxGet(url, manageGroupDeleteGroupResult);
    }
}

function manageGroupDeleteGroupResult(data) {
    if (!data.success)
        alert(data.message);

    hideGroupFolio();
    refreshAllGroupsFolio();
}

function refreshSearchedGroupsFolioTable(searchValue) {
	if (dpsGroupsJson == null)
		return;
	
	if (searchValue == "") {
		refreshAllGroupsFolioTable(dpsGroupsJson);
	} else {
		var table = document.createElement('table');
	    table.id = 'allGroupsFolioTable';
	    
	    var tbody = document.createElement('tbody');
	    table.appendChild(tbody);
	    
	    // find out the json that meet the search criteria
	    var searchResult = new Array();
	    var j = 0;
	    for (var i=0; i<dpsGroupsJson.length; i++) {
	    	if (dpsGroupsJson[i].name.toLowerCase().indexOf(searchValue.toLowerCase()) != -1) {
	    		searchResult[j] = dpsGroupsJson[i];
	    		j++;
	    	}
	    }
	    console.log(searchResult);
	    
	    if (searchResult != null) {
		    for(i = 0; i < searchResult.length; i++) {
		    	var row = document.createElement('tr');
		    	searchResult[i].row = row;
		        row.setAttribute('objId', getGroupId(searchResult[i]));
		        row.setAttribute('objName', searchResult[i].name);
		        row.onclick = toggleAllGroupsRow;
		        tbody.appendChild(row);
		
		        if (searchResult[i].isReadOnly) {
		        	var cell = createTableData(row, "LDAP");
		        	cell.innerHTML="<p>LDAP</p><span>LDAP groups are not editable or removable</span>";
		        	cell.className = 'ldapGroupLabel';
		        }else {
		        	var cell = createTableData(row, "");
		        }
		        
		        createTableData(row, searchResult[i].name);
		    }
	    }

	    $('#dpsAllGroupsFolioTableContainer').html('');
	    $('#dpsAllGroupsFolioTableContainer').append(table);
	}

}

function onGroupDetailUserDataLoaded() {
	if (groupDetailUserList.items.length > groupDetailUserList.pageSize) {
		$('#groupDetailUsersLoadedPrompt').text('Total: ' + groupDetailUserList.items.length + ', Loaded: ' + groupDetailUserList.numOfLoaded);
		$('#groupDetailUsersLoadedPrompt').show();
	}
	else {
		$('#groupDetailUsersLoadedPrompt').text('');
		$('#groupDetailUsersLoadedPrompt').hide();
	}
}