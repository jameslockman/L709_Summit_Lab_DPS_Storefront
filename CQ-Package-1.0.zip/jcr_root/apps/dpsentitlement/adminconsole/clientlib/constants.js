/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* General */
var DISCARD_CHANGES = 'Are you sure you want to leave this page? All changes will be lost. Click OK to Continue or Cancel to remain on this page.';
var DISCARD_PUSH_NOTIFICATION_MESSAGE = 'Discard current message?';

/* UDID */
var DELETE_UDID_CONFIRMATION = 'Delete selected UDID?';
var LIST_UDID_BLACKLIST_ERROR = 'Unable to retrieve UDID and Blacklist';
var ADD_UDID_ERROR = 'Unable to add UDID';
var DELETE_UDID_ERROR = 'Unable to delete UDID';
var ADD_UDID_BLACKLIST_ERROR = 'Unable to add UDID to blacklist';
var DELETE_UDID_BLACKLIST_ERROR = 'Unable to remove UDID from blacklist';

/* User */
var DELETE_USER_CONFIRMATION = 'Delete selected user(s)?';
var DELETE_USER_ERROR = 'Unable to delete selected user(s)';
var LIST_USER_ERROR = 'Unable to retrieve users info';
var ADD_USER_ERROR = 'Unable to add new user';

/* Group */
var DELETE_GROUP_CONFIRMATION = 'Delete selected group(s)?';
var DELETE_GROUP_ERROR = 'Unable to delete selected group(s)';
var LIST_GROUP_ERROR = 'Unable to retrieve group info';
var ADD_GROUP_ERROR = 'Unable to add new group';
var UPDATE_GROUP_ERROR = 'Unable to save group info';

/* Settings */
var VERIFY_ADOBE_ID_ERROR = 'Unable to verify the Adobe ID';
var SAVE_ADOBE_ID_ERROR = 'Unable to save selected Adobe ID';


/**
 * Service paths - UDIDs
 */
var UDID_SERVICE_PATH = '/UdidService';
var LIST_UDID_SERVICE = 'listUdid';
var NEW_UDID_SERVICE = 'newUdid';
var REMOVE_UDID_SERVICE = 'deleteUdid';
var ADD_UDID_BLACKLIST_SERVICE = 'addToUdidBlackList';
var DELETE_UDID_BLACKLIST_SERVICE = 'removeFromUdidBlackList';

/**
 * Service paths - Users
 */
var USER_MANAGEMENT_SERVICE_PATH = '/UserManagementService';
var LIST_USER_SERVICE = 'listUsers';

/**
 * Service paths - Groups
 */
var GROUP_MANAGEMENT_SERVICE_PATH = '/UserManagementService';
var LIST_GROUP_SERVICE = 'listGroups';

/**
 * Service paths - Settings
 */
var SETTINGS_SERVICE_PATH = '/SettingsService';
var LIST_SETTINGS_SERVICE = 'listDetails';
var RETRIEVE_FULFILLMENT_ID = 'retrieveFulfillmentId';
var UPDATE_SELECTED_ADOBE_ID = 'updateSelectedAdobeId';
var ADD_ADOBE_ID_SERVICE = 'addAdobeId';
var SET_ADOBE_ID_OR_GUID_SERVICE = 'setFulfillmentId';

var COMPANY_MANAGEMENT_SERVICE = 'CompanyManagementService';
var UDID_SERVICE = 'UdidService';
var USER_MANAGEMENT_SERVICE = 'UserManagementService';
var FOLIO_PERMISSIONS_SERVICE = 'FolioPermissionsService';
var SETTINGS_SERVICE = 'SettingsService';

var FOLIO_TAB_INDEX = 1;
var USER_TAB_INDEX = 2;
var UDID_TAB_INDEX = 3;
var SETTING_TAB_INDEX = 99;