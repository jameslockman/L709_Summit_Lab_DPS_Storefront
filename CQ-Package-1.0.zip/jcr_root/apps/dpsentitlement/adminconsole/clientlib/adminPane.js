/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/**
 * adminPane
 */

function initAdminPane() {
	$("#adminSettings").click(function() {
	    var tabs = $('#dpsTabs').find('li');
	    if (tabs != null && tabs.length > 0) {
	    	tabs[tabs.length - 1].onclick();
	    }
		return false;
	});

	$("#adminLogout").click(function() {
		logout();
	});
	
	$("#adminNotification").click(function() {
		
	});
}

function logout() {
	signOut = true;
	cleanCompanyManagement();
	if (dpsPageBlurHandler())
		signout();
	return false;
}

function refreshManagementTabVisibility() {
	$("li.dpsTabActiveHeader").removeClass("dpsTabActiveHeader");
	hideAllTabContents();
	
	$('#dpsTabHeader_1').css('display', getProductPrivilege() != "DENY" ? '' : 'none');
	$('#dpsTabHeader_2').css('display', getUserPrivilege() != "DENY" ? '' : 'none');
	$('#adminCompanyBox').css('display', getCompanyPrivilege() != "DENY" && isCompanyModuleEnabled() ? '' : 'none');
	$('#dpsTabHeader_3').css('display', getUdidPrivilege() != "DENY" && isUdidModuleEnabled() ? '' : 'none');
	$('#adminSettings').css('display', getSettingPrivilege() != "DENY" ? '' : 'none');
	$('#adminNotification').css('display', getNotificationPrivilege() != "DENY" && isNotificationModuleEnabled() ? '' : 'none');
	
	if ($('#adminCompanyBox').css('display') != "none")
		showCompanySelector();
	
	if (window.location.hash == "#folioManagement" && isTabVisible(FOLIO_TAB_INDEX)) {
		selectTab(FOLIO_TAB_INDEX);
	}
	else if (window.location.hash == "#userManagement" && isTabVisible(USER_TAB_INDEX)) {
		selectTab(USER_TAB_INDEX);
	}
	else if (window.location.hash == "#udidBlacklist" && isTabVisible(UDID_TAB_INDEX)) {
		selectTab(UDID_TAB_INDEX);
	}
	else if (window.location.hash == "#settingsManagement" && isTabVisible(SETTING_TAB_INDEX)) {
		selectTab(SETTING_TAB_INDEX);
	}
	else {
		if (isTabVisible(FOLIO_TAB_INDEX)) {
			window.location.hash = "#folioManagement";
			selectTab(FOLIO_TAB_INDEX);
		}
		else if (isTabVisible(USER_TAB_INDEX)) {
			window.location.hash = "#userManagement";
			selectTab(USER_TAB_INDEX);
		}
		else if (isTabVisible(UDID_TAB_INDEX)) {
			window.location.hash = "#udidBlacklist";
			selectTab(UDID_TAB_INDEX);
		}
		else
			window.location.hash = "#";
	}
}

/* 
 * Table helper functions 
 */
function createTableRowContent(rowObject, data, cellType) {
    var cell = document.createElement(cellType);
    var cellContent = document.createTextNode(data);
    cell.appendChild(cellContent);
    rowObject.appendChild(cell);
    return cell;
}

function createTableData(rowObject, data) {
    return createTableRowContent(rowObject, data, 'td');
}

function createTableHeader(rowObject, data) {
    return createTableRowContent(rowObject, data, 'th');
}

function createTableCheckbox(rowObject, objId) {
	var cell = document.createElement('td');
    cell.innerHTML = '<input type="checkbox" objId="' + objId +'"/>';
    rowObject.appendChild(cell);
    return cell;
}

function createAccessDenyTable(tableId, containerId, onclickCallback, json, editable, type) {
    if (json == null) 
    	json = [];

    var table = document.createElement('table');
    table.id = tableId;
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    if (json != null) {
	    for(i = 0; i < json.length; i++) {
	        var row = document.createElement('tr');
	        row.class = "pickerListItem";
	       	row.setAttribute('objId', json[i].id);
	    	row.setAttribute('objType', type);
	        if (editable)
	        	row.onclick = onclickCallback;

	        tbody.appendChild(row);
	        
	        generateTableCell(row, json[i]);
	    }
    }
    
//    sortTableBody(tbody);
    document.getElementById(containerId).innerHTML = '';
    document.getElementById(containerId).appendChild(table);
}

function generateTableCell(row, json) {
	if (json == null)
		json = {};
	
	var name = json.name || '';
    var cell = createTableData(row, name);
    if (name == '') {
	    cell.style.backgroundColor = 'transparent';
	    cell.style.cursor = 'default';
    }
	return cell;
}

function sortTableBody(tbody){
	var users =  $(tbody).children('tr').detach();
    for(i=0;i<users.length;i++){
    	var temp;
    	for(j=0;j<users.length-1-i;j++){
    		var t = users[j];
    		var t2 = users[j].innerHTML.replace(/<\/?([a-z][a-z0-9]*)\b[^>]*>?/gi, '').toLowerCase();
    		if (users[j].innerHTML.replace(/<\/?([a-z][a-z0-9]*)\b[^>]*>?/gi, '').toLowerCase()>users[j+1].innerHTML.replace(/<\/?([a-z][a-z0-9]*)\b[^>]*>?/gi, '').toLowerCase()){
    			temp=users[j];
    			users[j]=users[j+1];
    			users[j+1]=temp;
    		}
    	}
    }   
    for(i=0;i<users.length;i++){
    	$(tbody).append(users[i]);
    }
}

/*
 * Detect Scrollbar Width with JavaScript
 * http://davidwalsh.name/detect-scrollbar-width 
 */
function getScrollbarWidth() {
	// Create the measurement node
	var scrollDiv = document.createElement("div");
	scrollDiv.className = "scrollbar-measure";
	document.body.appendChild(scrollDiv);
	
	// Get the scrollbar width
	var scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
	//console.warn(scrollbarWidth); // Mac:  15
	
	// Delete the DIV
	document.body.removeChild(scrollDiv);
	return scrollbarWidth;
}

function refreshProductsList() {
}

function refreshCurrentPage() {
	var ui = $("li.dpsTabActiveHeader").get(0);
	$("li.dpsTabActiveHeader").removeClass("dpsTabActiveHeader");
	displayPage.call(ui);
}

function isTabVisible(index) {
	return $('#dpsTabHeader_' + index).css('display') != "none";
}

function selectTab(index) {
	$('#dpsTabHeader_' + index).click();
}
