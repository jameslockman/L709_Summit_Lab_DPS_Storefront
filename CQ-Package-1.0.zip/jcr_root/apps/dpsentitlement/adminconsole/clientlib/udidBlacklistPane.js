/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
//
// udidBlacklistPane
//
var dpsUdidBlacklistJson = null;
var udidBlacklistLastSelectedRow = null;
var udidBlacklistDenyAccessLastSelectedRow = null;
var udidElementToBeRemoved = null;

var addUdidUserJson = [];
var addUdidNeedsSave = false;

function initUdidBlacklistPane() {
	resizePane($('#udidBlackListContainer'),-46);
	resizePane($('#udidBlackListDenyAccessContainer'),-46);
	$('#udidBlacklistAddUserInput').change(function() {
		refreshUdidAddUdidValidationStatus();
	});
	$('#udidBlacklistAddUdidInput').on('change keyup paste focus', function() {
		refreshUdidAddUdidValidationStatus();
	});
	$('#udidBlacklistAddButton').click(function() {
		udidNewUdid();
	});
}

function setUdidBlacklistNeedsSave(status) {
	udidBlacklistNeedsSave = status;
	refreshUdidBlacklistValidationStatus();
}

function udidBlacklistPageBlurHandler() {
	if (udidBlacklistNeedsSave) {
		if (confirm(DISCARD_CHANGES) == false)
			return false;
	}
	hideUdidBlacklistPane();
	return true;
}

function showUdidBlacklistPane() {
	if (!dpsPageBlurHandler())
		return;
	resizePane($('#udidBlackListContainer'),-122);
	resizePane($('#udidBlackListDenyAccessContainer'),-122);
	setUdidBlacklistNeedsSave(false);
	dpsPageBlurHandler = udidBlacklistPageBlurHandler;
    $('#addPublisherIdInput').val('');
    $('#addPublisherPasswordInput').val('');
    clearUdidAddUdidInputs();
    refreshAddUdidUserList();
    refreshUdidBlacklist();
}

function hideUdidBlacklistPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;
}

function clearUdidAddUdidInputs() {
	$('#udidBlacklistAddUserInput').val('');
    $('#udidBlacklistAddUdidInput').val('');
    udidValidateUserAndUdid('', '');
}

function refreshUdidBlacklistValidationStatus() {
}

/* 
 * AJAX calls 
 */
function refreshUdidBlacklist() {
	if (!validateSession())
		return;

    updateLoadingIndicator(1);

	var url = urlBase + UDID_SERVICE_PATH;
    $.ajax(
    {
        type : 'GET',
        url : url,
        data : {
        	'authToken': getAuthToken(),
        	'action': LIST_UDID_SERVICE
        },
        success : listUdidBlacklistResult,
        error: listUdidBlacklistError,
        dataType : "json"
    });
}

function listUdidBlacklistResult(data, textStatus, jqXHR) {
    if (!validateResponse(data)) {
    	refreshUdidBlacklistTable(null);
    	refreshUdidBlacklistDenyAccessTable(null);
    }
    else if (data.success) {
    	dpsUdidBlacklistJson = data;
    	refreshUdidBlacklistTable(data.udids);
    	refreshUdidBlacklistDenyAccessTable(data.blacklist);
    }
    else {
        alert(LIST_UDID_BLACKLIST_ERROR);
    }
    updateLoadingIndicator(-1);
}

function listUdidBlacklistError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('listUdidBlacklistError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}

function createBlacklistTableRowContent(rowObject, udid, name) {
    var cell = document.createElement('td');
    cell.innerHTML = '<div class="blacklistItemUdid">' + udid + '</div><div class="blackListItemName">' + name + '</div>';
    rowObject.appendChild(cell);
    return cell;
}

function createBlacklistTableRowContentWithRemove(rowObject, udid, name) {
    var cell = document.createElement('td');
    cell.innerHTML = '<div style="position: relative"><div class="blacklistItemUdid">' + udid + '</div><div class="blackListItemName">' + name + '</div><div class="blacklistItemUdidRemove" onclick="return udidRemoveBlacklist(this)"></div></div>';
    rowObject.appendChild(cell);
    return cell;
}

function createBlacklistTableSearchRowContent(rowObject, inputId) {
    var cell = document.createElement('td');
    cell.innerHTML = '<input type="text" id="' + inputId + '" name="' + inputId + '" class="inputSearch" placeholder="Search">';
    rowObject.appendChild(cell);
    return cell;
}

function getUdidItemIndex(list, item) {
	var index = -1;
	var i = 0;
	$(list).find('td').each(function() {
		if (this == item) {
			index = i;
			return;
		}
		i++;
	});
	return index;
}


/* search filter */
function udidUpdateSearchFilter(keyword, tableId) {
	keyword = keyword.toLowerCase();
	$(tableId).find('td').each(function() {
		var name = $(this).attr('name');
		var id = $(this).attr('objId');
		if (name != null && id != null) {
			var display = name.toLowerCase().indexOf(keyword) >= 0 || id.toLowerCase().indexOf(keyword) >= 0;
			if (!display)
				$(this).removeClass("dpsSelected");
			$(this).css('display', display ? '' : 'none');
		}
	});

	// Update arrow buttons
	udidUpdateUdidArrowButton();
	udidUpdateBlacklistDenyArrowButton();
}


/* all UDIDs */
function refreshUdidBlacklistTable(json) {
	var search = $('#udidBlacklistSearchUdidKeyword').val();

	var table = document.createElement('table');
    table.id = 'tableUdidBlacklist';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    // Add search input
    var searchRow = document.createElement('tr');
    var cell = createBlacklistTableSearchRowContent(searchRow, 'udidBlacklistSearchUdidKeyword');
    tbody.appendChild(searchRow);
    
    if (json != null) {
        for(i = 0; i < json.length; i++) {
            var row = document.createElement('tr');
            row.setAttribute('class', 'pickerListItem');
            tbody.appendChild(row);
            var name = json[i].id.split(';')[0];
            var email = json[i].id.split(';')[1];

            cell = createBlacklistTableRowContentWithRemove(row, json[i].udid, getDisplayName(name, email));
            cell.onclick = toggleUdidBlacklist;
            cell.setAttribute('objId', json[i].udid);
            cell.setAttribute('name', name);
            cell.class = 'dpsEnabled';
        }
    }

    $('#udidBlackList').html('');
    $('#udidBlackList').append(table);
    
    $('#udidBlacklistSearchUdidKeyword').on('change paste keyup', function() {
    	udidUpdateSearchFilter($(this).val(), '#tableUdidBlacklist');
    });
    $('#udidBlacklistSearchUdidKeyword').val(search);
    $('#udidBlacklistSearchUdidKeyword').change();
    udidUpdateUdidArrowButton();
}

function toggleUdidBlacklist(e) {
	if (udidElementToBeRemoved != null && udidElementToBeRemoved[0] == $(this).children()[0])
		return;

	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (udidBlacklistLastSelectedRow != null) {
			var lastIndex = getUdidItemIndex($('#tableUdidBlacklist'), udidBlacklistLastSelectedRow);
			var index = getUdidItemIndex($('#tableUdidBlacklist'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}

			$('#tableUdidBlacklist').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#tableUdidBlacklist').find('td').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#tableUdidBlacklist').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";

		$('#tableUdidBlacklist').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}
	udidBlacklistLastSelectedRow = this;
	udidUpdateUdidArrowButton();
}


function udidUpdateUdidArrowButton() {
	var count = $('#tableUdidBlacklist').find('.dpsSelected').length;
    if (count > 0) {
        $("#addUdidBlackListButton").addClass("dpsEnabled");
    }
    else {
        $("#addUdidBlackListButton").removeClass("dpsEnabled");
    }
}

function udidRemoveBlacklist(element) {
	var $div = $(element).parent();
	udidElementToBeRemoved = $div;

	if (!confirm(DELETE_UDID_CONFIRMATION)) {
		udidElementToBeRemoved = null;
		return false;
	}

	var $td = $($div.parent());
	var udid = $td.attr('objId');
	removeUdid(udid);
	return false;
}


/* blacklist UDIDs */
function refreshUdidBlacklistDenyAccessTable(json) {
	var search = $('#udidBlacklistSearchBlacklistKeyword').val();

	var table = document.createElement('table');
    table.id = 'tableUdidBlacklistDenyAccess';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    // Add search input
    var searchRow = document.createElement('tr');
    var cell = createBlacklistTableSearchRowContent(searchRow, 'udidBlacklistSearchBlacklistKeyword');
    tbody.appendChild(searchRow);

    if (json != null) {
        for(i = 0; i < json.length; i++) {
            var row = document.createElement('tr');
            row.setAttribute('class', 'pickerListItem');
            tbody.appendChild(row);

            var name = json[i].id.split(';')[0];
            var email = json[i].id.split(';')[1];
            
//            var cell = createBlacklistTableRowContent(row, json[i].udid, getDisplayName(json[i].name, json[i].id));
//            cell.onclick = toggleUdidBlacklistDenyAccess;
//            cell.setAttribute('objId', json[i].udid);
//            cell.setAttribute('name', json[i].name);
//            cell.class = 'dpsEnabled';
            
            cell = createBlacklistTableRowContentWithRemove(row, json[i].udid, getDisplayName(name, email));
            cell.onclick = toggleUdidBlacklistDenyAccess;
            cell.setAttribute('objId', json[i].udid);
            cell.setAttribute('name', name);
            cell.class = 'dpsEnabled';
        }
    }

    $('#udidBlackListDenyAccess').html('');
    $('#udidBlackListDenyAccess').append(table);
    
    $('#udidBlacklistSearchBlacklistKeyword').on('change paste keyup', function() {
    	udidUpdateSearchFilter($(this).val(), '#tableUdidBlacklistDenyAccess');
    });
    $('#udidBlacklistSearchBlacklistKeyword').val(search);
    $('#udidBlacklistSearchBlacklistKeyword').change();
    udidUpdateBlacklistDenyArrowButton();
}

function toggleUdidBlacklistDenyAccess(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (udidBlacklistDenyAccessLastSelectedRow != null) {
			var lastIndex = getUdidItemIndex($('#tableUdidBlacklistDenyAccess'), udidBlacklistDenyAccessLastSelectedRow);
			var index = getUdidItemIndex($('#tableUdidBlacklistDenyAccess'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}

			$('#tableUdidBlacklistDenyAccess').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#tableUdidBlacklistDenyAccess').find('td').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#tableUdidBlacklistDenyAccess').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";

		$('#tableUdidBlacklistDenyAccess').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}
	
	udidBlacklistDenyAccessLastSelectedRow = this;
	udidUpdateBlacklistDenyArrowButton();
}

function udidUpdateBlacklistDenyArrowButton() {
	var count = $('#tableUdidBlacklistDenyAccess').find('.dpsSelected').length;
    if (count > 0) {
        $("#removeUdidBlackListButton").addClass("dpsEnabled");
    }
    else {
        $("#removeUdidBlackListButton").removeClass("dpsEnabled");
    }
}

/* Add UDID to blacklist */
function addUdidBlackList() {
	if (!validateSession())
		return;
	
	var udidList = [];
	var selected = $('#tableUdidBlacklist').find('.dpsSelected').each(function() {
		udidList.push($(this).attr('objId'));
	});
	
	if (udidList.length == 0)
		return;
	
	updateLoadingIndicator(1);
	if (__DEBUG__) {
    	var json = jsonUdidBlacklist_addUdid;
    	udisBlackListAddResult(json, '', null);
    	console.warn("DEBUG addUdidBlackList");
    }
    else {
		var url = urlBase + UDID_SERVICE_PATH;
	    $.ajax(
	    {
	        type : 'POST',
	        url : url,
	        data : {
	        	'authToken': getAuthToken(),
	        	'action': ADD_UDID_BLACKLIST_SERVICE,
	        	'udids' : udidList
	        },
	        success : udisBlackListAddResult,
	        error: udisBlackListAddError,
	        dataType : "json"
	    });
    }
}

function udisBlackListAddResult(data, textStatus, jqXHR) {
    if (!validateResponse(data)) {
    }
    else if (data.success) {
    	refreshUdidBlacklist();
    }
    else {
        alert(ADD_UDID_BLACKLIST_ERROR);
        updateLoadingIndicator(-1);
        return;
    }

    updateLoadingIndicator(-1);
}

function udisBlackListAddError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('udisBlackListAddError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}

/* Remove UDID from blacklist */
function removeUdidBlackList() {
	if (!validateSession())
		return;
	
	var udidList = [];
	var selected = $('#tableUdidBlacklistDenyAccess').find('.dpsSelected').each(function() {
		udidList.push($(this).attr('objId'));
	});
	
	if (udidList.length == 0)
		return;
	
	updateLoadingIndicator(1);
	if (__DEBUG__) {
    	var json = jsonUdidBlacklist_removeUdid;
    	udidBlackListRemoveResult(json, '', null);
    	console.warn("DEBUG removeUdidBlackList");
    }
    else {
		var url = urlBase + UDID_SERVICE_PATH;
	    $.ajax(
	    {
	        type : 'POST',
	        url : url,
	        data : {
	        	'authToken': getAuthToken(),
	        	'action': DELETE_UDID_BLACKLIST_SERVICE,
	        	'udids' : udidList
	        },
	        success : udidBlackListRemoveResult,
	        error: udidBlackListRemoveError,
	        dataType : "json"
	    });
    }
}

function udidBlackListRemoveResult(data, textStatus, jqXHR) {
    if (!validateResponse(data)) {
    }
    else if (data.success) {
    	refreshUdidBlacklist();
    }
    else {
        alert(DELETE_UDID_BLACKLIST_ERROR);
        updateLoadingIndicator(-1);
        return;
    }

    updateLoadingIndicator(-1);
}

function udidBlackListRemoveError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('udisBlackListRemoveError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}

function getDisplayName(name, userId) {
	return name + ' &lt;' + userId + '&gt;';
}

/*
 * Add new UDID 
 */

function udidNewUdid() {
	if (!validateSession())
		return;

	var id = $('#udidBlacklistAddUserInput').val();
	var udid = $('#udidBlacklistAddUdidInput').val();
    updateLoadingIndicator(1);
	var url = urlBase + UDID_SERVICE_PATH;
    $.ajax(
    {
        type : 'POST',
        url : url,
        data : {
        	'authToken': getAuthToken(),
        	'action': NEW_UDID_SERVICE,
        	'id' : id,
        	'udid' : udid
        },
        success : udidNewUdidResult,
        error: udidNewUdidError
    });
}

function udidNewUdidResult(data, textStatus, jqXHR) {
	if (!validateResponse(data)) {
		
	}
	else if (data.success) {
		refreshUdidBlacklist();
		clearUdidAddUdidInputs();
		refreshUdidAddUdidValidationStatus();
    }
    else {
        alert(ADD_UDID_ERROR);
    }
    updateLoadingIndicator(-1);
}

function udidNewUdidError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('udidNewUdidError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}


// Refresh the user list
function refreshAddUdidUserList() {
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_USER_SERVICE);
	loadAllItems(url, function(items) {
    	addUdidUserJson = items;
    	refreshAddUdidUserSelect();
	});
}

function refreshAddUdidUserSelect() {
	var json = addUdidUserJson;
	if (json == null)
		addUdidUserJson = [];

	var input = $('#udidBlacklistAddUserInput');
	input.html('<option value=""></option>');

    for(i = 0; i < json.length; i++) {
        var option = document.createElement('option');
        $(option).val(json[i].name + ';' + json[i].email);
        $(option).html(getDisplayName(json[i].name, json[i].email));
        input.append(option);
    }
}

function refreshUdidAddUdidValidationStatus() {
	var userId = $('#udidBlacklistAddUserInput').val().split(';')[1];
	var udid = $('#udidBlacklistAddUdidInput').val();
	var ok = userId != null && userId.length > 0 && udid.length > 0 && udidValidateUserAndUdid(userId, udid);
	$('#udidBlacklistAddButton').prop('disabled', ok ? '' : 'disabled');
}

function udidValidateUserAndUdid(userId, udid) {
	var exists;
	if (userId == null || udid == null)
		exists = false;
	else
		exists = udidFindUserAndUdid(userId, udid);
	$('#udidDuplicatedTooltip').css('display', exists ? '' : 'none');
	return !exists;
}

function udidFindUserAndUdid(userId, udid) {
	if (dpsUdidBlacklistJson == null || userId == null || udid == null)
		return false;
	
	var udids = dpsUdidBlacklistJson.udids;
	if (udids != null) {
		for (i = 0; i < udids.length; i++) {
			if (udids[i].udid == udid && udids[i].id == userId)
				return true;
		}
	}
	
	var blacklist = dpsUdidBlacklistJson.blacklist;
	if (blacklist != null) {
		for (i = 0; i < blacklist.length; i++) {
			if (blacklist[i].udid == udid && blacklist[i].id == userId)
				return true;
		}
	}

	// Not found
	return false;
}

/* Remove UDID */
function removeUdid(udid) {
	if (!validateSession())
		return;
	
	updateLoadingIndicator(1);
	var url = urlBase + UDID_SERVICE_PATH;
    $.ajax(
    {
        type : 'GET',
        url : url,
        data : {
        	'authToken': getAuthToken(),
        	'action': REMOVE_UDID_SERVICE,
        	'udid' : udid
        },
        success : udidBlackListRemoveUdidResult,
        error: udidBlackListRemoveUdidError,
        dataType : "json"
    });
}

function udidBlackListRemoveUdidResult(data, textStatus, jqXHR) {
    if (!validateResponse(data)) {
    }
    else if (data.success) {
    	udidElementToBeRemoved.fadeOut(0, function() {
        	var td = udidElementToBeRemoved.parent();
        	var tr = $(td).parent();
    		tr.remove();
    	});
    	udidUpdateUdidArrowButton();
    	udidUpdateBlacklistDenyArrowButton();
    }
    else {
        alert(DELETE_UDID_ERROR);
        updateLoadingIndicator(-1);
        return;
    }

    updateLoadingIndicator(-1);
}

function udidBlackListRemoveUdidError(jqXHR, textStatus, errorThrown) {
    updateLoadingIndicator(-1);
    console.log('udidBlackListRemoveUdidError: ' + jqXHR.status + ':' + jqXHR.responseText);
    alert(kInternalServerError);
}