/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * editGroupPane 
 */
var editGroupNeedsSave = false;
var editGroupJson = null;

var editGroupLastSelectedSoruceRow = null;
var editGroupLastSelectedTargetRow = null;

var editGroupLastSelectedSoruceGroupRow = null;
var editGroupLastSelectedTargetGroupRow = null;
var avaialbeGroupsForEditGroup = null;

var editGroupAddedUsers = null;
var editGroupAddedGroups = null;
var editGroupDeletedUsers = null;
var editGroupDeletedGroups = null;
var editGroupUserList = null;
var editGroupTimeout = null;

function addToIdList(list, id) {
	list.push(id);
}

function indexOfIdList(list, id) {
	for (var i = 0; i < list.length; ++i) {
		if (list[i] == id) {
			return i;
		}
	}
	return -1;
}

function deleteFromIdList(list, id) {
	var index = indexOfIdList(list, id);
	if (index >= 0) {
		list.splice(index, 1);
		return true;
	}
	else
		return false;
}

function idListToString(list) {
	var result = '';
	for (var i = 0; i < list.length; ++i) {
		if (i > 0)
			result += ',';
		result += list[i];
	}
	return result;
}

function initEditGroupPane() {
	editGroupUserList = new PagedList('editGroupSourceUsersContainer', 'editGroupSourceUsersTable', null, 'user', userNameOnlyRenderer, toggleEditGroupSourceUsersRow, onEditGroupUserDataLoaded);

	$('#saveEditGroupFolioButton').click(function() {
		editGroupSubmit();
	});

	addValidationNonEmpty($('#editGroupNameInput'), onEditGroupNameInputChangedNotEmpty);
	$('#editGroupDescriptionInput').on('keyup paste change', function() {
		setEditGroupNeedsSave(true);
		freshEditGroupValidationStatus();
	});

	$('#editGroupSearchUser').on('keyup paste change', function() {
		if (editGroupTimeout)
			clearTimeout(editGroupTimeout);
		editGroupTimeout = setTimeout(refreshEditGroupSourceUsersTableWithFilter, 250);
	});

	$('#editGroupSearchGroup').on('keyup paste change', function() {
		refreshEditGroupSourceGroupsTableWithFilter($(this).val());
	});
}

function setEditGroupNeedsSave(status) {
	editGroupNeedsSave = status;
}

function editGroupPageBlurHandler() {
	if (editGroupNeedsSave) {
		if (confirm(DISCARD_CHANGES) == false)
			return false;
	}
	hideEditGroupPane();
	return true;
}

function showEditGroupPane(json) {
	if (!dpsPageBlurHandler())
		return;
	dpsPageBlurHandler = editGroupPageBlurHandler;

	editGroupJson = json;
	editGroupAddedUsers = [];
	editGroupAddedGroups = [];
	editGroupDeletedUsers = [];
	editGroupDeletedGroups = [];
	
	$('#dpsEditGroup').fadeIn(kTransitionDuration);

	$('#dpsManageGroups').fadeOut(0);
	$('#dpsManageUsers').fadeOut(0);
	$('#showUsersConsoleButton').removeClass('active');
	$('#showGroupsConsoleButton').addClass('active');

	userManagementAddEditUserGroupButtonVisibility(false);
	
	if (json != null) {
		$('#editGroupIdInput').val(getGroupId(json));
		$('#editGroupNameInput').val(json.name);
		$('#editGroupDescriptionInput').val(json.description);
	}
	
	$('#editGroupNameInput').keyup();
	$('#editGroupDescriptionInput').keyup();

	$('#editGroupSearchUser').val('');
	
	if (editGroupJson.users)
		createEditGroupTargetUsersTable(editGroupJson.users);
	else {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'listUsersInGroup') + "&group=" + editGroupJson.id;
		loadAllItems(url, function(items) {
			editGroupJson.users = items;
			createEditGroupTargetUsersTable(items);
		});
	}
	
	refreshEditGroupSourceUsers();
	
	$('#editGroupSearchGroup').val('');
	refreshEditGroupSourceGroupsTable(null);
	refreshEditGroupSourceGroups();
	$('#editGroupTargetGroupsTable').html('');
	
	setEditGroupNeedsSave(false);
	refreshEditGroupArrows();
	refreshEditGroupGroupArrows();
	freshEditGroupValidationStatus();
}

function hideEditGroupPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

	$('#dpsEditGroup').fadeOut(0);
	if (userManagementUserConsoleSelected) {
		$('#dpsManageUsers').fadeIn(kTransitionDuration);
		$('#dpsManageGroups').fadeOut(0);
		$('#showUsersConsoleButton').addClass('active');
		$('#showGroupsConsoleButton').removeClass('active');
	}
	else {
		$('#dpsManageUsers').fadeOut(0);
		$('#dpsManageGroups').fadeIn(kTransitionDuration);
		$('#showUsersConsoleButton').removeClass('active');
		$('#showGroupsConsoleButton').addClass('active');
	}
	
	userManagementAddEditUserGroupButtonVisibility(true);
}

function onEditGroupNameInputChangedNotEmpty(result) {
	setEditGroupNeedsSave(true);
	freshEditGroupValidationStatus();
}

function freshEditGroupValidationStatus() {
	var ok = $('#editGroupNameInput').val().length > 0 && editGroupNeedsSave;
	$('#saveEditGroupFolioButton').prop('disabled', ok ? '' : 'disabled');
}

function editGroupGetUser(id) {
	var user = null;
	$(editGroupJson.users).each(function(){
		if (this.id == id) {
			user = this;
			return;
		}
	});
	return user;
}

function editGroupGetGroup(id) {
	var group = null;
	$(editGroupJson.groups).each(function(){
		if (this.id == id) {
			group = this;
			return;
		}
	});
	return group;
}

/*
 * Get users
 */
function refreshEditGroupArrows() {
	var sourceCount = $('#editGroupSourceUsersTable').find('.dpsSelected').length;
    if (sourceCount > 0) {
        $("#addEditGroupUsersToTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#addEditGroupUsersToTargetButton").removeClass("dpsEnabled");
    }
    
    var targetCount = $('#editGroupTargetUsersTable').find('.dpsSelected').length;
    if (targetCount > 0) {
        $("#removeEditGroupUsersFromTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#removeEditGroupUsersFromTargetButton").removeClass("dpsEnabled");
    }
}

function editGroupGetItemIndex(list, item) {
	var index = -1;
	var i = 0;
	$(list).find('tr').each(function() {
		if (this == item) {
			index = i;
			return;
		}
		i++;
	});
	return index;
}

function compareItemOrder(item1, item2) {
	var idx1 = editGroupGetItemIndex($('#editGroupSourceUsersTable'), item1);
	var idx2 = editGroupGetItemIndex($('#editGroupSourceUsersTable'), item2);
}

function toggleEditGroupSourceUsersRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (editGroupLastSelectedSoruceRow != null) {
			var lastIndex = editGroupGetItemIndex($('#editGroupSourceUsersTable'), editGroupLastSelectedSoruceRow);
			var index = editGroupGetItemIndex($('#editGroupSourceUsersTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#editGroupSourceUsersTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#editGroupSourceUsersTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#editGroupSourceUsersTable').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";

		$('#editGroupSourceUsersTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}

	editGroupLastSelectedSoruceRow = this;
	refreshEditGroupArrows();
}

function toogleEditGroupTargetUsersRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else if (GetShiftKeyState(e)) {
		if (editGroupLastSelectedTargetRow != null) {
			var lastIndex = editGroupGetItemIndex($('#editGroupTargetUsersTable'), editGroupLastSelectedTargetRow);
			var index = editGroupGetItemIndex($('#editGroupTargetUsersTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#editGroupTargetUsersTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#editGroupTargetUsersTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#editGroupTargetUsersTable').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";

		$('#editGroupTargetUsersTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}

	editGroupLastSelectedTargetRow = this;
	refreshEditGroupArrows();
}

function addEditGroupUsersToTarget() {
	var target = $('#editGroupTargetUsersTable');
	$('#editGroupSourceUsersTable').find('.dpsSelected').each(function() {
		var row = $(this).removeClass("dpsSelected").clone();
		row.click(toogleEditGroupTargetUsersRow);
		row.appendTo(target);
		setEditGroupNeedsSave(true);
		$(this).hide();

		var id = $(this).attr('objId');
		if (!deleteFromIdList(editGroupDeletedUsers, id))
			addToIdList(editGroupAddedUsers, id);
	});
	var users = $('#editGroupTargetUsersTable>tbody').children('tr').detach();
	var selectUserInserted = false;
	var currentUser;
	var selectedUser = users.last().text().toLowerCase();
	$(users).each(function(index) {
		currentUser = $(this).text().toLowerCase();
		if (selectUserInserted == true && index == users.length-1){
		}else if (selectUserInserted == false && currentUser >= selectedUser){
			$('#editGroupTargetUsersTable>tbody:last').append(users.last());
			selectUserInserted = true;
			$('#editGroupTargetUsersTable>tbody:last').append($(this));
		}else {
			$('#editGroupTargetUsersTable>tbody:last').append($(this));
		}
	});
	refreshEditGroupArrows();
	freshEditGroupValidationStatus();
}

function removeEditGroupUsersFromTarget() {
	var target = $('#editGroupSourceUsersTable');
	$('#editGroupTargetUsersTable').find('.dpsSelected').each(function() {
		var id = $(this).attr('objId');
		$(this).remove();
		target.find('[objId=' + id + ']').each(function() {
			$(this).show();
		});
		setEditGroupNeedsSave(true);
		if (!deleteFromIdList(editGroupAddedUsers, id))
			addToIdList(editGroupDeletedUsers, id);
	});
	refreshEditGroupArrows();
	freshEditGroupValidationStatus();
}

function refreshEditGroupSourceUsers(filter) {
    editGroupLastSelectedSoruceRow = null;
	editGroupLastSelectedTargetRow = null;
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_USER_SERVICE) + (filter ? '&filter=' + filter : '');
	editGroupUserList.url = url;
	editGroupUserList.showList(0);
}

function createEditGroupTargetUsersTable(json) {
	var table = document.createElement('table');
    table.id = 'editGroupTargetUsersTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    if (json != null) {
	    for(i = 0; i < json.length; i++) {
	        var row = document.createElement('tr');
	        row.setAttribute('objId', json[i].id);
	        createTableData(row, json[i].name);
	
	        tbody.appendChild(row);
	        row.onclick = toogleEditGroupTargetUsersRow;
	    }
    }

	$('#editGroupTargetUsersContainer').html('');
    $('#editGroupTargetUsersContainer').append(table);
}

function editGroupUserIsSelected(userId) {
	var selected = false;
	$('#editGroupTargetUsersTable').find('tr').each(function() {
		if ($(this).attr("objId") === userId) {
			selected = true;
			return;
		}
	});
	return selected;
}

function refreshEditGroupSourceUsersTableWithFilter() {
	editGroupTimeout = null;
	refreshEditGroupSourceUsers($('#editGroupSearchUser').val());
}

/*
 * Get groups
 */
function refreshEditGroupGroupArrows() {
	var sourceCount = $('#editGroupSourceGroupsTable').find('.dpsSelected').length;
    if (sourceCount > 0) {
        $("#addEditGroupGroupsToTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#addEditGroupGroupsToTargetButton").removeClass("dpsEnabled");
    }
    
    var targetCount = $('#editGroupTargetGroupsTable').find('.dpsSelected').length;
    if (targetCount > 0) {
        $("#removeEditGroupGroupsFromTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#removeEditGroupGroupsFromTargetButton").removeClass("dpsEnabled");
    }
}

function toggleEditGroupSourceGroupsRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (editGroupLastSelectedSoruceGroupRow != null) {
			var lastIndex = editGroupGetItemIndex($('#editGroupSourceGroupsTable'), editGroupLastSelectedSoruceGroupRow);
			var index = editGroupGetItemIndex($('#editGroupSourceGroupsTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#editGroupSourceGroupsTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#editGroupSourceGroupsTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#editGroupSourceGroupsTable').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";

		$('#editGroupSourceGroupsTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}

	editGroupLastSelectedSoruceGroupRow = this;
	refreshEditGroupGroupArrows();
}

function toogleEditGroupTargetGroupsRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (editGroupLastSelectedTargetGroupRow != null) {
			var lastIndex = editGroupGetItemIndex($('#editGroupTargetGroupsTable'), editGroupLastSelectedTargetGroupRow);
			var index = editGroupGetItemIndex($('#editGroupTargetGroupsTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#editGroupTargetGroupsTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#editGroupTargetGroupsTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#editGroupTargetGroupsTable').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";

		$('#editGroupTargetGroupsTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}

	editGroupLastSelectedTargetGroupRow = this;
	refreshEditGroupGroupArrows();
}

function addEditGroupGroupsToTarget() {
	var target = $('#editGroupTargetGroupsTable');
	$('#editGroupSourceGroupsTable').find('.dpsSelected').each(function() {
		$(this).removeClass("dpsSelected").appendTo(target);
		this.onclick = toogleEditGroupTargetGroupsRow;
		setEditGroupNeedsSave(true);
		var id = $(this).attr('objId');
		if (!deleteFromIdList(editGroupDeletedGroups, id))
			addToIdList(editGroupAddedGroups, id);
	});
	var groups = $('#editGroupTargetGroupsTable>tbody').children('tr').detach();
	var selectGroupInserted = false;
	var currentGroup;
	var selectedGroup = groups.last().text().toLowerCase();
	$(groups).each(function(index) {
		currentGroup = $(this).text().toLowerCase();
		if (selectGroupInserted == true && index == groups.length-1){
		}else if (selectGroupInserted == false && currentGroup >= selectedGroup){
			$('#editGroupTargetGroupsTable>tbody:last').append(groups.last());
			selectGroupInserted = true;
			$('#editGroupTargetGroupsTable>tbody:last').append($(this));
		}else {
			$('#editGroupTargetGroupsTable>tbody:last').append($(this));
		}
	});
	refreshEditGroupGroupArrows();
	freshEditGroupValidationStatus();
}

function removeEditGroupGroupsFromTarget() {
	var target = $('#editGroupSourceGroupsTable');
	$('#editGroupTargetGroupsTable').find('.dpsSelected').each(function() {
		$(this).removeClass("dpsSelected").appendTo(target);
		this.onclick = toggleEditGroupSourceGroupsRow;
		setEditGroupNeedsSave(true);
		var id = $(this).attr('objId');
		if (!deleteFromIdList(editGroupAddedGroups, id))
			addToIdList(editGroupDeletedGroups, id);
	});
	var groups = $('#editGroupSourceGroupsTable>tbody').children('tr').detach();
	var selectGroupInserted = false;
	var currentGroup;
	var selectedGroup = groups.last().text().toLowerCase();
	$(groups).each(function(index) {
		currentGroup = $(this).text().toLowerCase();
		if (selectGroupInserted == true && index == groups.length-1){
		}else if (selectGroupInserted == false && currentGroup >= selectedGroup){
			$('#editGroupSourceGroupsTable>tbody:last').append(groups.last());
			selectGroupInserted = true;
			$('#editGroupSourceGroupsTable>tbody:last').append($(this));
		}else {
			$('#editGroupSourceGroupsTable>tbody:last').append($(this));
		}
	});
	refreshEditGroupGroupArrows();
	freshEditGroupValidationStatus();
}

function refreshEditGroupSourceGroups() {
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_GROUP_SERVICE);
    ajaxGet(url, refreshEditGroupSourceGroupsResult);
}

function refreshEditGroupSourceGroupsResult(data) {
    if (data.success) {
    	refreshEditGroupSourceGroupsTable(data.data);
    }
    else {
    	refreshEditGroupSourceGroupsTable(null);
        alert(data.message);
    }
}

function refreshEditGroupSourceGroupsTable(json) {
	avaialbeGroupsForEditGroup = json;

	var table = document.createElement('table');
    table.id = 'editGroupSourceGroupsTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    if (json != null && editGroupJson != null) {
	    for(i = 0; i < json.length; i++) {
	    	if (editGroupJson.id === json[i].id)
    			continue;

	        var row = document.createElement('tr');
	        row.setAttribute('objId', json[i].id);
	        createTableData(row, json[i].name);
	
	        if (editGroupGetGroup(json[i].id) != null) {
	        	// Group belongs to this group
	        	$('#editGroupTargetGroupsTable').append(row);
	        	row.onclick = toogleEditGroupTargetGroupsRow;
	        }
	        else {
	        	row.onclick = toggleEditGroupSourceGroupsRow;
	            tbody.appendChild(row);
	        }
	    }
    }

	$('#editGroupSourceGroupsContainer').html('');
    $('#editGroupSourceGroupsContainer').append(table);
    editGroupLastSelectedSoruceGroupRow = null;
	editGroupLastSelectedTargetGroupRow = null;
}

function editGroupGroupIsSelected(memberId) {
	var selected = false;
	$('#editGroupTargetGroupsTable').find('tr').each(function() {
		if ($(this).attr("objId") === memberId) {
			selected = true;
			return;
		}
	});
	return selected;
}

function refreshEditGroupSourceGroupsTableWithFilter(keyword) {
	var table = document.createElement('table');
    table.id = 'editGroupSourceGroupsTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);
    
    if (avaialbeGroupsForEditGroup != null) {
    	keyword = keyword.toLowerCase();
	    for(i = 0; i < avaialbeGroupsForEditGroup.length; i++) {
	    	if (editGroupJson.id === avaialbeGroupsForEditGroup[i].id)
    			continue;

	    	if (avaialbeGroupsForEditGroup[i].name.toLowerCase().indexOf(keyword) != -1) {
	    		
	    		// ignore if alrady on the target list
	    		if (!editGroupGroupIsSelected(avaialbeGroupsForEditGroup[i].id)) {
			        var row = document.createElement('tr');
			        row.setAttribute('objId', avaialbeGroupsForEditGroup[i].id);
			        row.onclick = toggleEditGroupSourceGroupsRow;
			        tbody.appendChild(row);
			        createTableData(row, avaialbeGroupsForEditGroup[i].name);
	    		}
		    }
	    }
    }

	$('#editGroupSourceGroupsContainer').html('');
    $('#editGroupSourceGroupsContainer').append(table);
	editGroupLastSelectedSoruceGroupRow = null;
	editGroupLastSelectedTargetGroupRow = null;
}

/* submittion */
function editGroupGetUserSelection() {
	var users = '';
	$('#editGroupTargetUsersTable').find('tr').each(function() {
		if (users.length > 0)
			users += ',';
		users += $(this).attr('objId');
	});
	return users;
}

function editGroupGetGroupSelection() {
	var groups = '';
	$('#editGroupTargetGroupsTable').find('tr').each(function() {
		if (groups.length > 0)
			groups += ',';
		groups += $(this).attr('objId');
	});
	return groups;
}

function editGroupGetMemberSelection() {
	var members = '';

	$('#editGroupTargetGroupsTable').find('tr').each(function() {
		if (members.length > 0)
			members += ',';
		members += $(this).attr('objId');
	});
	
	$('#editGroupTargetUsersTable').find('tr').each(function() {
		if (members.length > 0)
			members += ',';
		members += $(this).attr('objId');
	});

	return members;
}

function editGroupSubmit() {
	if (editGroupJson.name != $('#editGroupNameInput').val() || editGroupJson.description != $('#editGroupDescriptionInput').val()) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'updateGroup');
		ajaxPost(url,
			{
				'id' : editGroupJson.id,
				'name' : $('#editGroupNameInput').val(),
				'description' : $('#editGroupDescriptionInput').val()
			}, function(data) {
				if (data.success) {
					editGroupJson.name = $('#editGroupNameInput').val();
					editGroupJson.description = $('#editGroupDescriptionInput').val();
					saveAddedUsers();
				}
				else
					alert(data.message);
			});
	}
	else
		saveAddedUsers();
}

function saveAddedUsers() {
	if (editGroupAddedUsers.length > 0) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'addUsersToGroup');
		ajaxPost(url,
			{
				'group' : editGroupJson.id,
				'users' : idListToString(editGroupAddedUsers)
			}, function(data) {
				if (data.success) {
					editGroupAddedUsers = [];
					saveDeletedUsers();
				}
				else
					alert(data.message);
			});
	}
	else
		saveDeletedUsers();
}

function saveDeletedUsers() {
	if (editGroupDeletedUsers.length > 0) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'deleteUsersFromGroup');
		ajaxPost(url,
			{
				'group' : editGroupJson.id,
				'users' : idListToString(editGroupDeletedUsers)
			}, function(data) {
				if (data.success) {
					editGroupDeletedUsers = [];
					saveAddedGroups();
				}
				else
					alert(data.message);
			});
	}
	else
		saveAddedGroups();
}

function saveAddedGroups() {
	if (editGroupAddedGroups.length > 0) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'addGroupsToGroup');
		ajaxPost(url,
			{
				'group' : editGroupJson.id,
				'groups' : idListToString(editGroupAddedGroups)
			}, function(data) {
				if (data.success) {
					editGroupAddedGroups = [];
					saveDeletedGroups();
				}
				else
					alert(data.message);
			});
	}
	else
		saveDeletedGroups();
}

function saveDeletedGroups() {
	if (editGroupDeletedGroups.length > 0) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'deleteGroupsFromGroup');
		ajaxPost(url,
			{
				'group' : editGroupJson.id,
				'groups' : idListToString(editGroupDeletedGroups)
			}, function(data) {
				if (data.success) {
					editGroupDeletedGroups = [];
					editGroupSubmitDone();
				}
				else
					alert(data.message);
			});
	}
	else 
		editGroupSubmitDone();
}

function editGroupSubmitDone() {
	hideEditGroupPane();
	refreshAllGroupsFolio(editGroupJson.id);
}

function onEditGroupUserDataLoaded() {
	if (editGroupUserList.items.length > editGroupUserList.pageSize) {
		$('#editGroupUserLoadedPrompt').text('Total: ' + editGroupUserList.items.length + ', Loaded: ' + editGroupUserList.numOfLoaded);
		$('#editGroupUserLoadedPrompt').show();
	}
	else {
		$('#editGroupUserLoadedPrompt').text('');
		$('#editGroupUserLoadedPrompt').hide();
	}
	
    var selectedIds = [];
    $('#editGroupTargetUsersTable').find('tr').each(function() {
    	selectedIds.push($(this).attr("objId"));
    });
	$('#editGroupSourceUsersTable').find('tr').each(function() {
		var id = $(this).attr("objId");
		for (var i = 0; i < selectedIds.length; ++i) {
			if (selectedIds[i] == id) {
				$(this).hide();
				break;
			}
		}
	});
	if ($('#editGroupSourceUsersContainer').get(0).scrollHeight <= $('#editGroupSourceUsersContainer').get(0).clientHeight && !editGroupUserList.isAllLoaded())
		editGroupUserList.onScroll();
}
