/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
var kInternalServerError = 'Internal Server Error';
var kSessionExpired = 'Session expired. Please sign-in again';
var kAccessDenied = 'Access denied';
var kInsufficientPrivilege = 'Insufficient Privilege';
var kUnableToAuthorize = 'Invalid email and/or password';
var kInvalidPassword = 'Invalid password';