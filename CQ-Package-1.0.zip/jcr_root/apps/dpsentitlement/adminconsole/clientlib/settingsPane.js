/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
//
// settingsPane
//
var selectedAdobeId = null;
var settingsBackPage = null;
var settingsMessageHtmlExtra = "<span class='input-validation-arrow-right'></span>";
var settingsAddIdMessageHtmlExtra = "<span class='input-validation-arrow-bottom'></span>";
var dpsModules = null;
var systemSettings = null;

function initSettingsPane() {
	$('#dpsPublisherUrlInput').val('http://edge.adobe-dcfs.com/ddp/issueServer/issues');
}

function isDirty() {
	if (dpsModules == null)
		return false;
	var dirty = false;
	$.each(dpsModules, function(index, module) {
		if (module.dirty)
			dirty = true;
	});
	return dirty;
}

function settingsPageBlurHandler() {
	if (isDirty()) {
		if (confirm(DISCARD_CHANGES) == false)
			return false;
	}
	hideSettingsPane();
	return true;
}

function showSettingsPane() {
	if (!dpsPageBlurHandler())
		return;
	
	dpsPageBlurHandler = settingsPageBlurHandler;
	refreshSystemSettings();
	refreshModuleSettings();
	refreshPublishers();
}

function hideSettingsPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;
	if (settingsBackPage != null)
		settingsBackPage.onclick();
}

function refreshSettings() {
}

function refreshSystemSettings() {
	systemSettings = null;
	$('#dpsSettingsSystemSaveButton').attr('disabled', 'disabled');
	var url = getActionUrl(SETTINGS_SERVICE, 'getSystemConfig');
	ajaxGet(url, function(data) {
	    if (data.success) {
	    	systemSettings = data.data;
	    	$('#dpsSessionTimeout').val(data.data.sessionTimeout);
	    	$('#deviceSessionTimeout').val(data.data.deviceSessionTimeout);
	    	if (data.data.authenticationTTL >= 0) {
	    		$('#authenticationTTL').val(data.data.authenticationTTL);
	    	} else {
	    		$('#authenticationTTL').val('');
	    	}
	    	if (data.data.entitlementsTTL >= 0) {
	    		$('#entitlementsTTL').val(data.data.entitlementsTTL);
	    	} else {
	    		$('#entitlementsTTL').val('');
	    	}
	    	$('#newFolioTimeout').val(data.data.newFolioTimeout);
	    	if (data.data.caseInsensitiveProductID)
	    		$('#dpsCaseInsensitiveProductID').attr('checked', 'checked');
	    	else
	    		$('#dpsCaseInsensitiveProductID').removeAttr('checked');
	    }
	    else
	        alert(data.message);
	});
}

function getUpperCaseModuleName(index) {
	return dpsModules[index].name.toUpperCase();
}

function refreshModuleSettings() {
	$('#dpsSettingsModuleContainer').empty();
	dpsModules = [];
	dpsModules.push({name:'smtp', displayName:'SMTP', enabled:true, isAuthenticatorImplemented: false, isEntitlementImplemented: false, isSyncImplemented: false});
	var url = getActionUrl(SETTINGS_SERVICE, 'listModules');
	ajaxGet(url, function(data) {
	    if (data.success) {
	    	dpsModules = dpsModules.concat(data.data);
	    }
	    else
	        alert(data.message);

	    var html = '';
    	for (var i = 0; i < dpsModules.length; ++i) {
    		if (dpsModules[i].enabled) {
    			html += '<div class="horzDivider"></div><div id="dpsSettings' + getUpperCaseModuleName(i) + 'Container">';
    			html += '<a id="dpsSettings' + getUpperCaseModuleName(i) + 'Header" class="flatButton icon sort-down" href="#" style="margin-left: -8px" ';
    			html += 'onclick="onDpsSettingsModuleClick(this, ' + i + ')"><span class="headerLabel">' + dpsModules[i].displayName + '</span></a>';
    			html += '</div>';
    		}
    	}
    	$('#dpsSettingsModuleContainer').html(html);
	});
}

function getModuleTableId(index) {
	return 'dpsSettings' + getUpperCaseModuleName(index) + 'Table';
}

function onDpsSettingsSystemChange() {
	if (systemSettings && systemSettings.sessionTimeout == parseInt($('#dpsSessionTimeout').val()) && 
			systemSettings.caseInsensitiveProductID == $('#dpsCaseInsensitiveProductID').is(':checked') && 
			systemSettings.deviceSessionTimeout == parseInt($('#deviceSessionTimeout').val()) &&
			((systemSettings.authenticationTTL == -1 && $('#authenticationTTL').val() == '') || systemSettings.authenticationTTL == parseInt($('#authenticationTTL').val())) &&
			((systemSettings.entitlementsTTL == -1 && $('#entitlementsTTL').val() == '') || systemSettings.entitlementsTTL == parseInt($('#entitlementsTTL').val())) &&
			systemSettings.newFolioTimeout == parseInt($('#newFolioTimeout').val()))
		
		$('#dpsSettingsSystemSaveButton').attr('disabled', 'disabled');
	else
		$('#dpsSettingsSystemSaveButton').removeAttr('disabled');
}

function onDpsSettingsSystemSaveButtonClick() {
	var url = getActionUrl(SETTINGS_SERVICE, 'setSystemConfig');
	var data = {
		sessionTimeout: parseInt($('#dpsSessionTimeout').val()),
		deviceSessionTimeout: parseInt($('#deviceSessionTimeout').val()),
		authenticationTTL: $('#authenticationTTL').val() == '' ? $('#authenticationTTL').val() : parseInt($('#authenticationTTL').val()),
		entitlementsTTL: $('#entitlementsTTL').val() == '' ? $('#entitlementsTTL').val() : parseInt($('#entitlementsTTL').val()),
		newFolioTimeout: parseInt($('#newFolioTimeout').val()),
		caseInsensitiveProductID: $('#dpsCaseInsensitiveProductID').is(':checked')
	}
	ajaxPost(url, data, function(data) {
	    if (data.success) {
	    	$('#dpsSettingsSystemSaveButton').attr('disabled', 'disabled');
	    	systemSettings.sessionTimeout = data.sessionTimeout;
	    	systemSettings.deviceSessionTimeout = data.deviceSessionTimeout;
	    	systemSettings.authenticationTTL = data.authenticationTTL;
	    	systemSettings.entitlementsTTL = data.entitlementsTTL;
	    	systemSettings.newFolioTimeout = data.newFolioTimeout;
	    	systemSettings.caseInsensitiveProductID = data.caseInsensitiveProductID;
	    } else 
	        alert(data.message);
	});
}

function onDpsSettingsModuleChange(index) {
	dpsModules[index].dirty = genarateSubmitString(index) != dpsModules[index].originalStringValue;
	var tableId = getModuleTableId(index);
	var saveButtonId = tableId + 'SaveButton';
	var syncButtonId = tableId + 'SyncButton';
	if (dpsModules[index].dirty) {
		$('#' + saveButtonId).removeAttr('disabled');
		$('#' + syncButtonId).attr('disabled', 'disabled');
	}
	else {
		$('#' + syncButtonId).removeAttr('disabled');
		$('#' + saveButtonId).attr('disabled', 'disabled');
	}
}

function onDpsSettingsSaveButtonClick(index) {
	var values = genarateSubmitString(index);
	var action = index == 0 ? 'setSmtpConfig' : 'setModuleConfig';
	var params = index == 0 ? null : 'name=' + dpsModules[index].name;

	var url = getActionUrl(SETTINGS_SERVICE, action);
	if (params != null)
		url += "&" + params;
	ajaxPost(url, values, function(data) {
	    if (data.success) {
	    	dpsModules[index].originalStringValue = values;
	    	onDpsSettingsModuleChange(index);
	    }
	    else
	        alert(data.message);
	});
}

function onDpsSettingsModuleClick(header, index) {
	var tableId = getModuleTableId(index);
	var action = index == 0 ? 'getSmtpConfig' : 'getModuleConfig';
	var params = index == 0 ? null : 'name=' + dpsModules[index].name;
	
	if ($(header).hasClass('sort-down')) {
		if ($('#' + tableId).length > 0) {
			$('#' + tableId).show();
		}
		else {
			var url = getActionUrl(SETTINGS_SERVICE, action + "Layout");
			if (params != null)
				url += "&" + params;
			ajaxGet(url, onDpsSettingsLayoutResult);
		}
		$(header).removeClass('sort-down');
		$(header).addClass('sort-up');
	}
	else {
		$('#' + tableId).hide();
		$(header).removeClass('sort-up');
		$(header).addClass('sort-down');
	}

	function createInputItem(inputType, itemName) {
		return '<td><input type="' + inputType + '" id="' + tableId + '_' + itemName + '_input" onkeyup="onDpsSettingsModuleChange(' + index + ')" onchange="onDpsSettingsModuleChange(' + index + ')"/></td></tr>';
	}
	
	function onDpsSettingsLayoutResult(data) {
	    if (data.success) {
	    	var html = '<table id="' + tableId + '" style="padding-top:0">';
	    	var items = data.data;
	    	for (var i = 0; i < items.length; ++i) {
	    		if (items[i].items != null) {
		    		html += '<tr><td colspan="2"><div class="horzDivider"></div><div><span class="headerLabel">' + items[i].name + '</span></div></td></tr>';
		    		for (var j = 0; j < items[i].items.length; ++j) {
			    		html += '<tr><td>' + items[i].items[j].displayName + ':</td>';
			    		html += createInputItem(items[i].items[j].type, items[i].items[j].name);
		    		}
	    		}
	    		else {
		    		html += '<tr><td>' + items[i].displayName + ':</td>';
		    		html += createInputItem(items[i].type, items[i].name);
	    		}
	    	}
	    	html += '<tr><td></td><td><div style="margin:4px">';
	    	html += '<button type="button" id="' + tableId + 'SaveButton" style="float:left" disabled onclick="onDpsSettingsSaveButtonClick(' + index + ')">Save</button>';
	    	if (dpsModules[index].isSyncImplemented) {
	    		html += '<button type="button" id="' + tableId + 'SyncButton" onclick="onDpsSettingsSyncButtonClick(' + index + ')">Sync</button>';
	    	}
	    	html += '</div></td></tr>';
	    	html += '<tr><td colspan="2"><div id="dpsSettingsSyncProgress" style="display:none"><span id="dpsSettingsSyncLabel"></span><div id="dpsSettingsSyncLabelBar"></div></div></td></tr>';
	    	html += '</table>';
	    	$(header).parent().append(html);
			var url = getActionUrl(SETTINGS_SERVICE, action);
			if (params != null)
				url += "&" + params;
			ajaxGet(url, onDpsSettingsResult);
	    }
	    else
	        alert(data.message);
	}
	
	function onDpsSettingsResult(data) {
		dpsModules[index].original = null;
		dpsModules[index].dirty = false;
	    if (data.success) {
	    	dpsModules[index].original = data.data;
	    	$.each(data.data, function(name, value) {
	    		var itemId = tableId + '_' + name + '_input';
	    		if ($('#' + itemId).attr('type') == 'checkbox') {
	    			if (value)
	    				$('#' + itemId).attr('checked', 'checked');
	    			else
	    				$('#' + itemId).removeAttr('checked');
	    		}
	    		else 
	    			$('#' + itemId).val(value);
	    	});
	    	dpsModules[index].originalStringValue = genarateSubmitString(index);
	    }
	    else
	        alert(data.message);
	}
}

function genarateSubmitString(index) {
	var newValue = {};
	$.each(dpsModules[index].original, function(name, value) {
		newValue[name] = value;
	});
	
	var tableId = getModuleTableId(index);
	$('#' + tableId + ' :input').each(function(index) {
		var idAttr = $(this).attr('id');
		if (idAttr != null) {
			var ids = idAttr.split('_');
			if (ids.length == 3 && ids[0] == tableId && ids[2] == 'input') {
				if ($(this).attr('type') == 'checkbox')
					newValue[ids[1]] = $(this).is(':checked');
				else
					newValue[ids[1]] = encodeURIComponent($(this).val());
			}
		}
	});
	
	var stringValue = '';
	$.each(newValue, function(name, value) {
		stringValue += name + '=' + value + '&';
	});
	
	if (stringValue.length > 0)
		stringValue = stringValue.substring(0, stringValue.length - 1);
	
	return stringValue;
}

function refreshPublishers() {
	var url = getActionUrl(SETTINGS_SERVICE, 'listPublisher');
	ajaxGet(url, function(data) {
	    if (data.success) {
	    	refreshViewIdTable(data.data);
	    }
	    else {
	    	refreshViewIdTable([]);
	        alert(data.message);
	    }
	});
}

function refreshViewIdTable(publishers) {
	selectedAdobeId = null;
	$('#dpsPublisherIdInput').val('');
	
	var readWrite = (getUserPrivilege() === 'READ_WRITE');
	var tdHtml;

	var table = document.createElement('table');
    table.id = 'dpsViewIdTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);
    
    for(i = 0; i < publishers.length; i++) {
        var row = document.createElement('tr');
        tbody.appendChild(row);
        
        var cell = document.createElement('td');
        row.appendChild(cell);
        if (publishers[i].active) {
        	selectedAdobeId = publishers[i].adobeId;
        	$('#dpsPublisherIdInput').val(selectedAdobeId);
        }
        
        $(cell).attr('objId', publishers[i].adobeId);
        
        tdHtml = '<div class="item">';
        tdHtml += '<input type="radio" name="dpsViewId" class=""' + (publishers[i].active ? ' checked="checked"' : '');
        tdHtml += readWrite ? ' onClick="onAdobeIdRadioClick(this, \'' + publishers[i].adobeId +'\')" />' : ' disabled />';
        tdHtml += '<div class="viewGroup">';
        tdHtml += '<div class="viewId adobeid">' + publishers[i].adobeId + '</div>';
        tdHtml += '<div class="viewId guid"><a target="_blank" href="http://edge.adobe-dcfs.com/ddp/issueServer/issues?accountId=' + publishers[i].guid + '">' + publishers[i].guid + '</a></div>';
        tdHtml += '</div>';
        if (readWrite)
        	tdHtml += '<a class="flatButton icon delete deletePublisherButton" href="#" onclick="deletePublisher(this); return false;">delete</a>'; 
        tdHtml += '</div><div class="horzDivider"></div>'
        
        // IE9 does not allow "td.innerHTML"
        cell.innerHTML = tdHtml;
    }

	$('#dpsViewIdTableContainer').html('');
    $('#dpsViewIdTableContainer').append(table);
}

function onAdobeIdRadioClick(sender, adobeId) {
	if (adobeId != selectedAdobeId) {
		var url = getActionUrl(SETTINGS_SERVICE, 'selectPublisher') + '&adobeId=' + adobeId;
		ajaxGet(url, function(data) {
		    if (data.success) {
		    	selectedAdobeId = adobeId;
		    	$('#dpsPublisherIdInput').val(selectedAdobeId);
		    }
		    else {
		    	var selected = null;
		    	$('#dpsViewIdTable td[objId="' + selectedAdobeId + '"]').find('input').attr('checked', 'checked');
		        alert(data.message);
		    }
		});
	}
}

function deletePublisher(sender) {
	var div = sender.parentNode;
	var td = div.parentNode;
	var tr = td.parentNode;

	var url = getActionUrl(SETTINGS_SERVICE, 'deletePublisher') + '&adobeId=' + $(td).attr('objId');
	ajaxGet(url, function(data) {
	    if (data.success) {
	    	var input = $(td).find('input')[0];
	    	if ($(input).is(':checked'))
	    		$('#dpsPublisherIdInput').val('');
	    	$(tr).remove();
	    }
	    else
	        alert(data.message);
	});
}

function deleteUnsavedViewID(sender) {
	var tr = sender.parentNode.parentNode;
	tr.parentNode.removeChild(tr);
}

function showAddPublisherPane() {
	$('#addAdobeIdAndGuidPopup').removeClass('hide');
	$('#settingsPopupOverlay').css('display', 'block');
	
	$('#addPublisherAdobeIdInput').val('');
	$('#addPublisherAdobeIdPasswordInput').val('');
	$('#addPublisherGuidInput').val('');
	$('#addPublisherGuidAdobeIdInput').val('');
	
	$('#addAdobeIdAndGuidButton').prop('disabled', true);
}

function hideAddPublisherPane() {
	$('#addAdobeIdAndGuidPopup').addClass('hide');
	$('#settingsPopupOverlay').css('display', 'none');
}

function onDpsSettingsAddPublisherChange() {
	if (($('#addPublisherAdobeIdInput').val() != '' && $('#addPublisherAdobeIdPasswordInput').val() != '') ||
			($('#addPublisherGuidAdobeIdInput').val() != '' && $('#addPublisherGuidInput').val() != ''))
		$('#addAdobeIdAndGuidButton').removeAttr('disabled');
	else
		$('#addAdobeIdAndGuidButton').attr('disabled', 'disabled');
}

function savePublisher() {
	var url = getActionUrl(SETTINGS_SERVICE, 'addPublisher');
	var values = null;
	
	if ($('#addPublisherGuidAdobeIdInput').val() != '' && $('#addPublisherGuidInput').val() != '')
		values = '&adobeId=' + $('#addPublisherGuidAdobeIdInput').val() + '&guid=' + $('#addPublisherGuidInput').val();
	else if ($('#addPublisherAdobeIdInput').val() != '' && $('#addPublisherAdobeIdPasswordInput').val() != '')
		values = '&adobeId=' + $('#addPublisherAdobeIdInput').val() + '&password=' + $('#addPublisherAdobeIdPasswordInput').val();
	
	if (values != null) {
		if ($('#dpsPublisherIdInput tr').length == 0)
			values += '&active=true';
		ajaxPost(url, values, function(data) {
		    if (data.success) {
		    	hideAddPublisherPane();
		    	refreshPublishers();
		    }
		    else
		        alert(data.message);
		});
	}
}

function onDpsSettingsSyncButtonClick(index) {
	$('#dpsSettingsSyncProgress').show();
	$('#dpsSettingsSyncLabelBar').width('0%');
	$('#dpsSettingsSyncLabel').html('Searching users ... ');
	syncUsers(function(userSyncResult){
		if (userSyncResult) {
			$('#dpsSettingsSyncLabelBar').width('0%');
			$('#dpsSettingsSyncLabel').html('Searching groups ... ');
			syncGroups(function(groupSyncResult){
				$('#dpsSettingsSyncProgress').hide();
				var prompt = 'User sync result:';
				prompt += '\n  Total: ' + userSyncResult.total + '\n  Added: ' + userSyncResult.added + '\n  Updated: ' + userSyncResult.updated;
				prompt += '\n  Deleted: ' + userSyncResult.deleted + '\n  Failed: ' + userSyncResult.failed + '\n  Ignored: ' + userSyncResult.ignored;
				if (groupSyncResult) {
					prompt += '\n\nGroup sync result:';
					prompt += '\n  Total: ' + groupSyncResult.total + '\n  Added: ' + groupSyncResult.added + '\n  Updated: ' + groupSyncResult.updated;
					prompt += '\n  Deleted: ' + groupSyncResult.deleted + '\n  Failed: ' + groupSyncResult.failed + '\n  Ignored: ' + groupSyncResult.ignored;
				}
				alert(prompt);
			});
		}
		else
			$('#dpsSettingsSyncProgress').hide();
	});

	function syncUsers(onDone) {
		var url = getActionUrl(SETTINGS_SERVICE, 'syncUsers') + "&name=" + dpsModules[index].name;
		ajaxGet(url, function(data) {
			if (data.success) {
				$('#dpsSettingsSyncLabel').text('Sync users ... ');
				checkSyncStatus(onDone);
			}
			else {
				alert(data.message);
				onDone(null);
			}
		});
	}
	
	function checkSyncStatus(onDone) {
		var url = getActionUrl(SETTINGS_SERVICE, 'getSyncStatus') + "&name=" + dpsModules[index].name;
		ajaxGet(url, function(data) {
			if (data.success) {
				var percent = Math.round(data.data.result.total * 100 / data.data.result.totalEstimate);
				$('#dpsSettingsSyncLabelBar').width(percent + '%');
				if (data.data.done)
					onDone(data.data.result);
				else {
					setTimeout(function() { checkSyncStatus(onDone); }, 1000);
				}
			}
			else {
				alert(data.message);
				onDone(null);
			}
		});
	}
	
	function syncGroups(onDone) {
		var url = getActionUrl(SETTINGS_SERVICE, 'syncGroups') + "&name=" + dpsModules[index].name;
		ajaxGet(url, function(data) {
			if (data.success) {
				$('#dpsSettingsSyncLabel').html('Sync groups ... ');
				checkSyncStatus(onDone);
			}
			else {
				alert(data.message);
				onDone(null);
			}
		});
	}
}

jQuery.fn.center = function(parent) {
    if (parent) {
        parent = this.parent();
    } else {
        parent = window;
    }
    this.css({
        "position": "absolute",
        "top": ((($(parent).height() - this.outerHeight()) / 4) + $(parent).scrollTop() + "px"),
        "left": ((($(parent).width() - this.outerWidth()) / 2) + $(parent).scrollLeft() + "px")
    });
    return this;
}