/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * validation functions
 */
function validateEmail(resultSuccess, resultError) {
	var a = $(this).val();
	var filter = /^[a-zA-Z0-9]+[a-zA-Z0-9_.-]+[a-zA-Z0-9_-]+@[a-zA-Z0-9]+[a-zA-Z0-9.-]+[a-zA-Z0-9]+.[a-z]{2,4}$/;

	// valid email?
	if(filter.test(a)) {
		resultSuccess();
		return true;
	}

	// invalid
	resultError();
	return false;
}

function validateNonEmpty(resultSuccess, resultError) {
	var a = $(this).val();

	if(a.length > 0) {
		resultSuccess();
		return true;
	}

	// invalid
	resultError();
	return false;
}

function validationHelper(element, result, errorMessage, onresult) {
	var tooltip = $('#' + element.attr('id') + 'Tooltip');
	if (result) {
		element.removeClass('dpsInvalidInput');
		tooltip.css({ "display": "none" });
		if (onresult != null)
			onresult(true);
	}
	else {
		element.addClass('dpsInvalidInput');
		tooltip.css({ "display": "inline-block" });
		tooltip.html(errorMessage + '<div class="arrow-right">');
		if (onresult != null)
			onresult(false);
	}
}

function addValidationNonEmpty(element, onresult) {
	var elementName = element.attr('id');
	var tooltipHtml = '<div class="tooltip-right" style="display:none" id="' + elementName + 
		'Tooltip"><div class="arrow-right"></div></div>';
	element.parent().append(tooltipHtml);
	
	element.on('keyup change paste focus click', function() {
		if ($(this).attr('readonly') != 'readonly')
			validationHelper($(this), $(this).val().length > 0, 'Required field', onresult);
	});
}

function addValidationEmail(element, onresult) {
	var elementName = element.attr('id');
	var tooltipHtml = '<div class="tooltip-right" style="display:none" id="' + elementName + 
		'Tooltip"><div class="arrow-right"></div></div>';
	element.parent().append(tooltipHtml);
	
	element.keyup(function() {
		var a = $(this).val();
		if (a.length > 0) {
			var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			validationHelper($(this), regex.test(a), 'Invalid email', onresult);
		}
		else
			validationHelper($(this), true, '', onresult);
	});
}

function addPasswordResetValidationEmail(element, onresult) {
	var elementName = element.attr('id');
	var tooltipHtml = '<div class="tooltip-right" style="display:none" id="' + elementName + 
		'Tooltip"><div class="arrow-right"></div></div>';
	element.parent().append(tooltipHtml);
	
	element.keyup(function() {
		var a = $(this).val();
		if (a.length == 0) {
			validationHelper($(this), true, '', onresult)
		}
		else {
			var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			validationHelper($(this), regex.test(a), 'Invalid email', onresult);
		}
	});
}

function addValidationNewPassword(element, onresult) {
	var elementName = element.attr('id');
	var tooltipHtml = '<div class="tooltip-right" style="display:none" id="' + elementName + 
		'Tooltip"><div class="arrow-right"></div></div>';
	element.parent().append(tooltipHtml);
	
	element.on('keyup change paste focus', function() {
		validationHelper($(this), $(this).val().length === 0 || $(this).val().length > 2, 'At least 3 characters', onresult);
	});
}

function addValidationConfirmPassword(element, onresult) {
	var elementName = element.attr('id');
	var tooltipHtml = '<div class="tooltip-right" style="display:none" id="' + elementName + 
		'Tooltip"><div class="arrow-right"></div></div>';
	element.parent().append(tooltipHtml);
	
	var source = $('#' + elementName.replace('Confirm', ''));
	source.on('keyup change paste focus click', function(){
		var elementName = $(this).attr('id');
		var target = $('#' + elementName + 'Confirm');
		validationHelper(target, $(this).val() === target.val(), 'Password does not match', onresult);
	});
	
	element.on('keyup change paste focus', function() {
		var elementName = $(this).attr('id');
		var target = $('#' + elementName.replace('Confirm', ''));
		validationHelper($(this), $(this).val() === target.val(), 'Password does not match', onresult);
	});
}

function validationHideTooltip(element) {
	var elementName = element.attr('id');
	var tooltip = $('#' + elementName + 'Tooltip');
	tooltip.css({ "display": "none" });
	element.removeClass('dpsInvalidInput');
}

function performValidation(element) {
	
}