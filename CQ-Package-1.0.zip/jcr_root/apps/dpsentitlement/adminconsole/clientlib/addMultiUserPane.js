/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * addMultiUserPane 
 */

var checkImportStatusTimer = null;

function initAddMultiUserPane() {
}

function uploadCSVSubmit() {
	$('#ldapUploadCSVFileProgressContainer').show();
	$('#ldapUploadCSVFileLabelBar').width('0%');
	$('#ldapUploadCSVFileLabel').html('Uploading users ... ');
	$('#ldapUploadCSVFileFormSubmitButton').attr('disabled', 'disabled');
	checkImportStatusTimer = null;
	$('#ldapUploadCSVFileForm').ajaxSubmit(
			{
				beforeSend : function() {
				},
				uploadProgress : function() {
				},
				success : function(data, textStatus, jqXHR) {
					checkResult(data, null);
					onUploadCSVDone(data);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					onUploadCSVDone({success: false, httpResponseCode: 403, message: kInternalServerError});
				}
			});
	return false;
}

function onUploadCSVDone(data) {
	if (data.success) {
		$('#ldapUploadCSVFileLabel').html('Importing users ... ');
		checkImportStatusTimer = null;
		checkImportStatus();
	}
	else {
		endUploadCSV();
		alert(data.message);
	}
}

function endUploadCSV() {
	$('#ldapUploadCSVFileFormSubmitButton').removeAttr('disabled');
	$('#ldapUploadCSVFileStopButton').removeAttr('disabled');
	$('#ldapUploadCSVFileProgressContainer').hide();
} 

function showUploadCSVResult(result) {
	var prompt = 'User import result:';
	prompt += '\n  Total: ' + result.total + '\n  Added: ' + result.added + '\n  Updated: ' + result.updated;
	prompt += '\n  Deleted: ' + result.deleted + '\n  Failed: ' + result.failed + '\n  Ignored: ' + result.ignored;
	alert(prompt);
}

function checkImportStatus() {
	var url = getActionUrl('UploadCSVFileService', 'getImportStatus');
	ajaxGet(url, function(data) {
		if (data.success) {
			var percent = Math.round(data.data.result.total * 100 / data.data.result.totalEstimate);
			$('#ldapUploadCSVFileLabelBar').width(percent + '%');
			if (data.data.done) {
				endUploadCSV();
				showUploadCSVResult(data.data.result);
			}
			else {
				checkImportStatusTimer = setTimeout(checkImportStatus, 1000);
			}
		}
		else {
			endUploadCSV();
			alert(data.message);
		}
	});
}

function onldapUploadCSVFileStopButtonClick() {
	if (checkImportStatusTimer != null) {
		clearTimeout(checkImportStatusTimer);
		checkImportStatusTimer = null;
	}
	$('#ldapUploadCSVFileStopButton').attr('disabled', 'disabled');
	var url = getActionUrl('UploadCSVFileService', 'cancelImport');
	ajaxGet(url, function(data) {
		endUploadCSV();
		if (data.success)
			showUploadCSVResult(data.data.result);
		else
			alert(data.message);
	});
}

function addMultiUserPageBlurHandler() {
	hideAddMultiUserPane();
	return true;
}

function showAddMultiUserPane() {
	if (!dpsPageBlurHandler())
		return;

	$('#dpsAddMultiUser').fadeIn(kTransitionDuration);
	$('#dpsManageUsers').fadeOut(0);
	$('#showUsersConsoleButton').addClass('active');
	$('#showGroupsConsoleButton').removeClass('active');
	$('#dpsManageGroups').fadeOut(0);
	
	userManagementAddEditUserGroupButtonVisibility(false);
	resizePane($('#dpsAddMultiUser'),-13);
	$('#CSVFileUploadAuthToken').val(getAuthToken());
}

function hideAddMultiUserPane() {
	$('#dpsAddMultiUser').fadeOut(0);
	if (userManagementUserConsoleSelected) {
		$('#dpsManageUsers').fadeIn(kTransitionDuration);
		$('#dpsManageGroups').fadeOut(0);
		$('#showUsersConsoleButton').addClass('active');
		$('#showGroupsConsoleButton').removeClass('active');
	}
	else {
		$('#dpsManageUsers').fadeOut(0);
		$('#dpsManageGroups').fadeIn(kTransitionDuration);
		$('#showUsersConsoleButton').removeClass('active');
		$('#showGroupsConsoleButton').addClass('active');
	}

	userManagementAddEditUserGroupButtonVisibility(true);
}
