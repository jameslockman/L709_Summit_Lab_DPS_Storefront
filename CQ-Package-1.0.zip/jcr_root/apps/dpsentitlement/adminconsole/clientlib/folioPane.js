/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * folioPane
 */
var dpsFolioJson = null;
var dpsFolioDateSortOrder = 0;	// 0:desc order, 1:ascending order

function initFolioPane() {
	resizePane($('#dpsFolioContainer'),-4);
	$("#modifyFolioPermissionButton").click(function() {
		showFolioPermissionPaneWithSelectedFolios();
	});
	
	$("#folioPermissionButton").click(function() {
		showFolioPermissionPaneWithSelectedFolios();
	});
	
	$('#searchFolioKeyword').keyup(function() {
		refreshFolioTableWithFilter($(this).val());
	});
	
	$('#sortFolioDate').click(function() {
		dpsFolioDateSortOrder = (dpsFolioDateSortOrder + 1) & 1;
		dpsFolioJson = sortFolio(dpsFolioJson, dpsFolioDateSortOrder);
		refreshFolioTable(dpsFolioJson);
	});
}

function showFolioPermissionPaneWithSelectedFolios() {
	var items = getSelectedFolio();
	if (items.length > 0)
		showFolioPermissionPane(items);
}

function resizePane(container, adjust) {
	var bodyWrapperHeight = $(window).height();
	var headerHeight = $('#dpsTopBar').height();
	var topBarHeight = $('#dpsFolio .topBar').height();
	var footerBarHeight = $('#dpsFolio .footerBar').height();
	container.height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight + adjust);
}

$(window).resize(function () {
	if($(window).height()>500){
		var bodyWrapperHeight = $(window).height();
		var headerHeight = $('#dpsTopBar').height();
		var topBarHeight = $('#dpsFolio .topBar').height();
		var footerBarHeight = $('#dpsFolio .footerBar').height();
		$('#dpsFolioContainer').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-4);
		$('#dpsAllUsersFolioTableContainer').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-4);
		$('#dpsAllGroupsFolioTableContainer').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-4);
		$('#udidBlackListContainer').height(bodyWrapperHeight - headerHeight - topBarHeight - 3*footerBarHeight-2);
		$('#udidBlackListDenyAccessContainer').height(bodyWrapperHeight - headerHeight - topBarHeight - 3*footerBarHeight-2);
		$('#dpsSettingsContainer').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight+126);
		$('#dpsAddUser').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-13);
        $('#dpsAddMultiUser').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-13);
        $('#dpsAddGroup').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-13);
        $('#dpsEditUser').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-13);
        $('#dpsEditGroup').height(bodyWrapperHeight - headerHeight - topBarHeight - footerBarHeight-13);
	}
	
})

function showFolioPane() {
	if (!dpsPageBlurHandler())
		return;

	$('#dpsModifyFolioPermission').addClass('dpsHidden');
	$('#dpsEditFolioPermission').addClass('dpsHidden');
	$('#dpsFolioPermission').addClass('dpsHidden');
	$('#dpsFolio').removeClass('dpsHidden');
	refreshFolio();
	refreshFolioPermissionButtons();
	selectFolioPermission(false);

	resizePane($('#dpsFolioContainer'),-4);
	$('#folioPermissionButton').html(
		getProductPrivilegeEditable() ? 'Modify Permissions' : 'View Permissions');
}

/*
 * folio check-box event handler 
 */
function refreshFolioPermissionButtons() {
	var selected = $('#folioTable').find('input:checked');
	var count = selected.length;
    if (count == 0) {
        $('#folioPermissionButton').attr('disabled', 'disabled');
    }
    else if (count > 1) {
    	if (getProductPrivilegeEditable())
    		$('#folioPermissionButton').removeAttr('disabled', 'disabled');
    	else
    		$('#folioPermissionButton').attr('disabled', 'disabled');
    }
    else {
    	$('#folioPermissionButton').removeAttr('disabled', 'disabled');
    }

    // Update the drop down menu
    var checked = count > 0 && count == $('#folioTable').find('tr').length;
    $('#selectFolioPermissionChkbox').prop('checked', checked);
}

function selectFolioPermission(selectAll) {
	var $tr = $(this).parent().parent();
    $tr.toggleClass("dpsFolioSelected");
    $('#folioTable').find('input:checkbox').each(function() {
    	if ($(this).attr('disabled') != 'disabled') {
	    	var row = $(this).parent().parent();
	    	if (row.css('display') != 'none')
	    		// Update filtered items only
	    		$(this).prop('checked', selectAll);
    	}
	});
    $('#selectFolioPermissionChkbox').prop('checked', selectAll);
    refreshFolioPermissionButtons();
}

function getSelectedFolio() {
	var items = [];
	$('#folioTable').find('input:checked').each(function() {
		var objId = this.attributes['objId'];
        if (objId != null) {
        	items.push(objId.value);
        }
	});
	return items;
}

/* 
 * AJAX calls 
 */
function refreshFolio() {
	var url = getActionUrl(SETTINGS_SERVICE, 'getSystemConfig');
	ajaxGet(url, function(data) {
	    if (data.success) {
	    	systemSettings = data.data;
	       	url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, "listProducts") + "&refresh=yes";
	       	ajaxGet(url, listFolioResult);
	    }
	    else
	        alert(data.message);
	});
}

function listFolioResult(result) {
    if (result.success) {
    	var list = sortFolio(result.data, dpsFolioDateSortOrder);

    	// Add date value to json
    	if (list != null) {
	    	for (i = 0; i < list.length; i++) {
	    		var dateVal = convertDateStringToInt(list[i].publicationDate);
	    		list[i].dateVal = dateVal;
	    	}
    	}
    	refreshFolioTable(list);
    }
    else {
        alert(result.message);
        refreshFolioTable(null);
    }
}

function refreshFolioTable(json) {
	var table = document.createElement('table');
    table.id = 'folioTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    if (json instanceof Array) {
    	var allowAccess = !getProductPrivilegeDeny();
    	var newFolioDate = (new Date()).getTime() - systemSettings.newFolioTimeout * 24 * 3600 * 1000;
	    for(i = 0; i < json.length; i++) {
	    	var moreIssue = json[i].issues.length-1;
	    	
	        var row = document.createElement('tr');
	        row.setAttribute('objId', json[i].id);
	        row.setAttribute('objName', json[i].name);
	        row.setAttribute('objIssue', json[i].issue);
	        row.setAttribute('objDesc', json[i].description);
	        row.setAttribute('objResolution', json[i].targetDimensions);
	        row.setAttribute('dateVal', convertDateStringToInt(json[i].publicationDate));
	        tbody.appendChild(row);
	
	        var chkboxCell = createTableCheckbox(row, json[i].id);
	        var chkbox = $(chkboxCell).children()[0]; 
	        chkbox.onclick = refreshFolioPermissionButtons;
	        chkbox.setAttribute('objId', json[i].id);
	        chkbox.setAttribute('objName', json[i].name);
	        if (json[i].brokers == 'noChargeStore') {
	        	chkbox.setAttribute('disabled', 'disabled');
	        }

	        var icon = document.createElement('div');
	        if (json[i].previewURL == null || json[i].previewURL.length == 0)
	        	icon.className = 'folioThumbnail';
	        else {
	        	icon.innerHTML = '<a href="' + json[i].previewURL + '" rel="lightbox"><img src="' + json[i].previewURL + '"></a>';
	        	icon.className = 'folioThumbnail';
	        	icon.style.background = '#fff';
	        }
	        chkboxCell.appendChild(icon);
	        
	        var idCell = createTableData(row, checkNullString(json[i].id));	
	        if ((new Date(json[i].publicationDate)).getTime() >= newFolioDate) {
	        	idCell.appendChild(document.createElement('br'));
	        	idCell.appendChild(document.createElement('br'));
	        	icon = document.createElement('img');
	        	icon.src = 'clientlib/images/folio-new.png';
		        idCell.appendChild(icon);
	        }
	        var descriptionIcon = document.createElement('span');
	        descriptionIcon.innerHTML = '<a href="#" class="desctooltip"><img src="'+urlBase+'/clientlib/images/description-info.png"><span>'+checkNullString(json[i].description)+'</span></a>&nbsp;&nbsp;&nbsp;';
	        var NameAndDescription = createTableData(row, checkNullString(json[i].name));
	        NameAndDescription.insertBefore(descriptionIcon, NameAndDescription.firstChild);
	        
	        createTableData(row, checkNullString(json[i].issue));
//	        createTableData(row, checkNullString(json[i].targetDimensions));
	        var dimentionCol = createTableData(row, checkNullString(json[i].targetDimensions));
	        if (moreIssue > 0) {
	        	var issueLabel = document.createElement('div');
	        	issueLabel.innerHTML = '(+' + moreIssue + ' more)';
	        	dimentionCol.appendChild(issueLabel);
	        }
	        createTableData(row, checkNullString(json[i].publicationDate));

	        var actionCell = createTableData(row, '');
	        if (allowAccess && json[i].brokers != 'noChargeStore') {
		        icon = document.createElement('div');
		        icon.className = 'folioAction';
		        icon.setAttribute('objId', json[i].id);
		        $(icon).click(function() {
		        	var items = [];
		        	items.push($(this).attr('objId'));
		        	showFolioPermissionPane(items);
		        });
		        actionCell.appendChild(icon);
	        }
	    }
	    dpsFolioJson = json;
    }

	$('#dpsFolioContainer').html('');
    $('#dpsFolioContainer').append(table);
    
    var container = document.getElementById("dpsFolioContainer");
    var row = document.getElementById("dpsFolioTableHeaderRow");
    var adjCell = row.getElementsByClassName("scrollbarAdjCell")[0];
    $(adjCell).width(scrollbarWidth);
    $(adjCell).css('display', container.clientHeight < container.scrollHeight ? '' : 'none');
    
    var keyword = $('#searchFolioKeyword').val();
    refreshFolioTableWithFilter(keyword);
    
    $('#sortFolioDate').removeClass('sort-up');
    $('#sortFolioDate').removeClass('sort-down');
    
    $('#sortFolioDate').addClass(dpsFolioDateSortOrder == 0 ? 'sort-up' : 'sort-down');
}

function refreshFolioTableWithFilter(keyword) {
	if (keyword == null || keyword.length == 0) {
		keyword == '*';
	}

	var showAll = keyword == '*';
	var found = showAll;
	//keyword = keyword.toLowerCase();
	$('#folioTable').find('tr').each(function() {
		
		var name = $(this).attr('objName');
		var desc = $(this).attr('objDesc');
		var descriptionIcon = document.createElement('span');
        descriptionIcon.innerHTML = '<a href="#" class="desctooltip"><img src="'+urlBase+'/clientlib/images/description-info.png"><span>'+desc+'</span></a>&nbsp;&nbsp;&nbsp;';
		
		var match = false;

		if (showAll) {
			match = true;
			$(this).children()[2].innerHTML = name;
//			$(this).children()[4].innerHTML = desc;
		}
		else {
			var regex = RegExp(keyword, 'ig');
			var newName = name.replace(regex, "<span class='highlight'>$&</span>");
//			var newDesc = desc.replace(regex, "<span class='highlight'>$&</span>");
			if (newName != name) {										// || newDesc != desc
				$(this).children()[2].innerHTML = newName;
//				$(this).children()[4].innerHTML = newDesc;
				match = true;
			}
			
			$(this).children()[2].insertBefore(descriptionIcon, $(this).children()[2].firstChild);
		}
		
		if (match) {
			$(this).css('display', '');
		}
		else {
			$(this).css('display', 'none');
		}
	});
}

function getFolioById(id) {
	if (dpsFolioJson != null) {
		for(i = 0; i < dpsFolioJson.length; i++) {
			if (dpsFolioJson[i].id === id)
				return dpsFolioJson[i];
		}
	}
}

function sortFolio(json, order)
{
	if (json != null)
		return json.sort(function(a,b) {
			var c1 = parseFloat(a.dateVal);
			var c2 = parseFloat(b.dateVal);
			return order == 0 ? c1 - c2 : c2 - c1;
		});
	else
		return null;
}

function convertDateStringToInt(dateString) {
	var yy = parseInt(dateString.substring(0, 4));
	var mm = parseInt(dateString.substring(5, 7));
	var dd = parseInt(dateString.substring(8, 10));
	return yy * 10000 + mm * 100 + dd;
}