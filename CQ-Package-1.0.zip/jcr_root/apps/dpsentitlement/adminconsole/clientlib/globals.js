/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
var __DEBUG__ = false;
var kTransitionDuration = 150;

function dpsDefaultPageBlurHandler() {
	return true;
}
var dpsPageBlurHandler = dpsDefaultPageBlurHandler;