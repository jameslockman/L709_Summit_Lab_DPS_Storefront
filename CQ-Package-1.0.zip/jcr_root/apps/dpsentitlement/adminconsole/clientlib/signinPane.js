/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * Sign-in
 */

var kSessionTimeout = 99999;
var loadingIndicatorRefCount = 0;
var redirectAfterSignIn = true;
var indicatorTimeout = null;

$(document).ready(function() {
	var type = window.location.hash.substr(1);
	if (type == "passwordReset") {
		showPasswordResetPane();
	} else if (type == "changePassword") {
		showChangePasswordPane();
	}
})

function updateLoadingIndicator(counter) {
    if (loadingIndicatorRefCount > 0)
    	indicatorTimeout = setTimeout(function() {
    		indicatorTimeout = null;
    		$('.dpsLoadingIndicator').show();
    	}, 500);
    else {
    	if (indicatorTimeout != null) {
    		clearTimeout(indicatorTimeout);
    		indicatorTimeout = null;
    	}
    	else
    		$('.dpsLoadingIndicator').hide();
    }
}

function setSignInMessage(msg) {
	$('#signInMessage').text(msg == null ? '' : msg);
}

function validateSession() {
	if (getAuthToken().length)
		return true;

	redirectAfterSignIn = false;
	setSignInMessage(kSessionExpired);
	showSignIn();
	return false;
}

function validateResponse(json) {
	if (json == null) {
		alert(kInternalServerError);
		return false;
	}

	if (json.success == true) {
		if (json.authToken != null) {
			setAuthToken(json.authToken);
		}
		return true;
	}

	if(json.httpResponseCode != null && json.httpResponseCode === 401) {
		setSignInMessage(kSessionExpired);
		cleanAllCookies();
		showSignIn();
		return false;
	}

	var message = json.message;
	if (message == null || message.length == 0)
		message = kAccessDenied;
	alert(message);

	return false;
}

function getAuthToken() {
	var token = checkNullString(getCookie('dpsAuthToken'));
	return token;
}

function getCurrentCompany() {
	var company = checkNullString(getCookie('dpsCurrentCompany'));
	return company;
}

function setAuthToken(token) {
	var trimmedToken = $.trim(token);
	trimmedToken = decodeURIComponent(trimmedToken.replace(/\+/g, ' '));
	setCookie('dpsAuthToken', trimmedToken, 0);
}

function setPrivilege(product, user, company, setting, notification, udid) {
	setCookie('dpsProductPrivilege', product, 0);
	setCookie('dpsUserPrivilege', user, 0);
	setCookie('dpsCompanyPrivilege', company, 0);
	setCookie('dpsSettingPrivilege', setting, 0);
	setCookie('dpsNotificationPrivilege', notification, 0);
	setCookie('dpsUdidPrivilege', udid, 0);
}

function setModuleStatus(companyEnabled, notificationEnabled, udidEnabled) {
	setCookie('dpsCompanyModuleEnabled', companyEnabled ? "true" : "false", 0);
	setCookie('dpsNotificationModuleEnabled', notificationEnabled ? "true" : "false", 0);
	setCookie('dpsUdidModuleEnabled', udidEnabled ? "true" : "false", 0);
}

function setCurrentCompany(company) {
	deleteCookie('dpsCurrentCompany');
	if (company != null && company.length > 0)
		setCookie('dpsCurrentCompany', company, 0);
}

function signout() {
	$('#dpsTabs').find('li').each(function() {
		$(this).attr('needsUpdate', 'yes');
	});

	redirectAfterSignIn = true;
	$('#folioTable').html('');
	cleanAllCookies();
	hideAllTabContents();
	showSignIn();
}

function showSignIn() {
	signOut = false;
	$('#dpsTabpage_1').show();
    $('.dpsSignInContainer').show();
    $('#dpsTopBarNav').hide();
    $('#passwordInput').val('');
    hidePushNotificationPane();
}

function hideSignIn() {
	$('.dpsSignInContainer').fadeOut(150);
	$('#dpsTopBarNav').show();
	hidePushNotificationPane();
}

function signin() {
    setSignInMessage('');

    if (__DEBUG__) {
	    var json = jsonSignIn;
	    signInResult(json, '', null);
    }
    else {
    	var email = document.getElementById("emailInput").value;
	    var password = document.getElementById("passwordInput").value;
	    var url = urlBase + "/AdminConsoleSignIn";
    	ajaxPost(url, 
	    	{
	            emailAddress: email,
	            password: password
	        }, signInResult);
    }
    return false;
}

function signInResult(data) {
	if (data.success) {
		setAuthToken(data.authToken);
		setPrivilege(data.productPrivilege, data.userPrivilege, data.companyPrivilege, data.settingPrivilege, data.notificationPrivilege, data.udidPrivilege);
		setModuleStatus(data.companyEnabled, data.notificationEnabled, data.udidEnabled);
		setCurrentCompany(data.company);
		if (redirectAfterSignIn) {
			redirectAfterSignIn = false;
			dpsPageBlurHandler = dpsDefaultPageBlurHandler;	// Reset default landing tab
		}
		hideSignIn();
		refreshManagementTabVisibility();
	}
	else
		alert(data.message);
}

/* User and Folio Management */
function getProductPrivilege() {
	return getCookie('dpsProductPrivilege');
}

function getProductPrivilegeEditable() {
	return getProductPrivilege() === 'READ_WRITE';
}

function getProductPrivilegeDeny() {
	return getProductPrivilege() === 'DENY';
}

function getUserPrivilege() {
	return getCookie('dpsUserPrivilege');
}

function getCompanyPrivilege() {
	return getCookie('dpsCompanyPrivilege');
}

function getSettingPrivilege() {
	return getCookie('dpsSettingPrivilege');
}

function getNotificationPrivilege() {
	return getCookie('dpsNotificationPrivilege');
}

function getUdidPrivilege() {
	return getCookie('dpsUdidPrivilege');
}

function isCompanyModuleEnabled() {
	return getCookie('dpsCompanyModuleEnabled') == "true";
}

function isNotificationModuleEnabled() {
	return getCookie('dpsNotificationModuleEnabled') == "true";
}

function isUdidModuleEnabled() {
	return getCookie('dpsUdidModuleEnabled') == "true";
}

function cleanAllCookies() {
	deleteCookie('dpsAuthToken');
	
	deleteCookie('dpsProductPrivilege');
	deleteCookie('dpsUserPrivilege');
	deleteCookie('dpsCompanyPrivilege');
	deleteCookie('dpsSettingPrivilege');
	deleteCookie('dpsNotificationPrivilege');
	deleteCookie('dpsUdidPrivilege');

	deleteCookie('dpsCompanyModuleEnabled');
	deleteCookie('dpsNotificationModuleEnabled');
	deleteCookie('dpsUdidModuleEnabled');
}