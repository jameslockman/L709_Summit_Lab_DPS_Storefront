/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
function PagedList(containerId, tableId, url, objType, rowRenderer, onClick, onDataUpdated, scrollContainerId) {
	this.scrollContainerId = scrollContainerId || containerId;
	this.containerId = containerId;
	this.tableId = tableId; 
	this.url = url;
	this.objType = objType;
	this.rowRenderer = rowRenderer;
	this.onClick = onClick;
	this.onDataUpdated = onDataUpdated;
	this.pageSize = 1000;
	this.numOfLoaded = 0;
	
	var oThis = this;
	$('#' + this.scrollContainerId).scroll(function() { 
		oThis.onScroll(); 
	});
}

PagedList.prototype.onScroll = function() {
	var oThis = this;
	if (this.invalidBottomRow && !this.bottomLoading) {
		var rowTop = $(this.invalidBottomRow).offset().top - $('#' + this.tableId).offset().top;
		if (rowTop < $('#' + this.scrollContainerId).scrollTop() + $('#' + this.scrollContainerId).height()) {
			this.bottomLoading = true;
			var start = $(this.invalidBottomRow).attr('objIndex');
			ajaxGet(this.url + '&start=' + start, function(data) { oThis.onBottomLoadingDone(data); });
		}
	}
	if (this.invalidTopRow && !this.topLoading) {
		var rowBottom = $(this.invalidTopRow).offset().top - $('#' + this.tableId).offset().top + $(this.invalidTopRow).height();
		if (rowBottom >= $('#' + this.scrollContainerId).scrollTop()) {
			this.topLoading = true;
			var start = $(this.invalidBottomRow).attr('objIndex') + 1;
			start -= this.pageSize;
			var size = this.pageSize;
			if (start < 0) {
				size += start;
				start = 0;
			}
			ajaxGet(this.url + '&start=' + start + '&size=' + size, function(data) { oThis.onTopLoadingDone(data); });
		}
	}
}

PagedList.prototype.onTopLoadingDone = function(data) {
	if (data.success) {
		this.numOfLoaded += data.data.items.length;
		var firstRow = $(this.invalidTopRow).next();
		
		$(this.invalidTopRow).remove();
		this.invalidTopRow = null;
		
		if (data.data.start > 0) {
			this.invalidTopRow = this.renderRow(data.data.start - 1, {});
			firstRow.before(this.invalidBottomRow);
		}
		
		for (var i = 0; i < data.data.items.length; ++i) {
			this.items[data.data.start + i] = data.data.items[i]; 
			firstRow.before(this.renderRow(data.data.start + i, data.data.items[i]));
		}
	
		this.topLoading = false;

		if (this.onDataUpdated)
			this.onDataUpdated();
	}
	else {
		this.topLoading = false;
		alert(data.message);
	}
}

PagedList.prototype.onBottomLoadingDone = function(data) {
	if (data.success) {
		this.numOfLoaded += data.data.items.length;
		$(this.invalidBottomRow).remove();
		this.invalidBottomRow = null;
		for (var i = 0; i < data.data.items.length; ++i) {
			this.items[data.data.start + i] = data.data.items[i]; 
			$('#' + this.tableId).append(this.renderRow(data.data.start + i, data.data.items[i]));
		}
		
		if (data.data.start + data.data.items.length < data.data.total) {
			this.invalidBottomRow = this.renderRow(data.data.start + data.data.items.length, {});
			$('#' + this.tableId).append(this.invalidBottomRow);
		}
	
		this.bottomLoading = false;

		if (this.onDataUpdated)
			this.onDataUpdated();
	}
	else {
		this.bottomLoading = false;
		alert(data.message);
	}
}

PagedList.prototype.clear = function() {
	this.items = [];
	this.invalidBottomRow = null;
	this.invalidTopRow = null;
	this.bottomLoading = false;
	this.topLoading = false;
	this.numOfLoaded = 0;
	
	var table = document.createElement('table');
    table.id = this.tableId;
    
    $('#' + this.containerId).html('');
    $('#' + this.containerId).append(table);
}

PagedList.prototype.showList = function(index) {
	var oThis = this;
	this.clear();
	ajaxGet(this.url + '&start=' + this.getStart(index), function(data) { oThis.onLoadingDone(data); });
}

PagedList.prototype.onLoadingDone = function(data) {
	if (data.success) {
		this.items = new Array(data.data.total);
		this.numOfLoaded += data.data.items.length;
		
		if (data.data.start > 0) {
			this.invalidTopRow = this.renderRow(data.data.start - 1, {});
		    $('#' + this.tableId).append(this.invalidTopRow);
		}
		
		for (var i = 0; i < data.data.items.length; ++i) {
			this.items[data.data.start + i] = data.data.items[i]; 
			$('#' + this.tableId).append(this.renderRow(data.data.start + i, data.data.items[i]));
		}
		
		if (data.data.start + data.data.items.length < data.data.total) {
			this.invalidBottomRow = this.renderRow(data.data.start + data.data.items.length, {});
			$('#' + this.tableId).append(this.invalidBottomRow);
		}
	
		if (this.onDataUpdated)
			this.onDataUpdated();
	}
	else
		alert(data.message);
}

PagedList.prototype.renderRow = function(index, item) {
    var row = document.createElement('tr');
    row.setAttribute('objId', item.id || '');
    row.setAttribute('objType', this.objType);
    row.setAttribute('objIndex', index);
    row.setAttribute('objName', item.name);
    row.setAttribute('objReadOnly', item.readOnly);
    row.onclick = this.onClick;
    
    if (this.rowRenderer)
    	this.rowRenderer(row, item);
    
    return row;
}

PagedList.prototype.getStart = function(index) {
	var result = index - this.pageSize / 2;
	if (result < 0)
		result = 0;
	return result;
}

PagedList.prototype.getRow = function(id) {
	$('#' + tableId + ' tr[objId="' + id + '"]').get(0);
}

PagedList.prototype.getItem = function(id) {
	for (var i = 0; i < this.items.length; ++i) {
		if (id == this.items[i].id)
			return this.items[i];
	}
	return null;
}

PagedList.prototype.isAllLoaded = function() {
	return !this.invalidBottomRow && !this.topBottomRow;
}

function loadAllItems(url, onDone) {
	var items = null;
	var numOfLoaded = 0;
	
	loadAllItemsImp(0);
	
	function loadAllItemsImp(start) {
		ajaxGet(url + '&start=' + start + '&size=1000', function(data) {
			if (data.success) {
				if (!items)
					items = new Array(data.data.total);
				
				numOfLoaded += data.data.items.length;
				
				for (var i = 0; i < data.data.items.length; ++i) {
					items[data.data.start + i] = data.data.items[i]; 
				}
				
				if (numOfLoaded >= items.length) {
					if (onDone)
						onDone(items);
				} else {
					loadAllItemsImp(numOfLoaded);
				}
			} else
				alert(data.message);
		});
	}
}