/*
 *http://css-tricks.com/bubble-point-tooltips-with-css3-jquery/
 */

// IIFE to ensure safe use of $
(function($) {
  // Create plugin
  $.fn.tooltips = function(el) {

    var $tooltip,
      $body = $('body'),
      $el;

    // Ensure chaining works
    return this.each(function(i, el) {
    
      $el = $(el).attr("data-tooltip", i);
      $elSpan = $el.parent();
      $elTd = $elSpan.parent();
      $elIcon = $el.children();

      // Make DIV and append to page 
      $tooltip = $('<div class="tooltip" data-tooltip="' + i + '">' + $el.attr('title') + '<div class="arrow"></div></div>').appendTo($elSpan);

      // Position right away, so first appearance is smooth
      var linkPosition = $elTd.position();
      linkPosition.left += $elTd.outerWidth() - $elIcon.width() * 2 - $tooltip.width();

      $tooltip.css({
        top: linkPosition.top - $elIcon.height() - 50, left: linkPosition.left
      });

      $el
      // Get rid of yellow box popup
      .removeAttr("title")

      // Mouseenter
      .hover(function() {

        $el = $(this);
        $elSpan = $el.parent();
        $elTd = $elSpan.parent();
        $elIcon = $el.children();

        $tooltip = $('div[data-tooltip=' + $el.data('tooltip') + ']');

        // Reposition tooltip, in case of page movement e.g. screen resize                        
        var linkPosition = $elTd.position();
        linkPosition.left += $elTd.outerWidth() - $elIcon.width() * 2 - $tooltip.width();

        $tooltip.css({
            top: linkPosition.top - $elIcon.height() * 2 - $tooltip.height(), left: linkPosition.left
        });

        // Adding class handles animation through CSS
        $tooltip.addClass("active");

        // Mouseleave
      }, function() {

        $el = $(this);

        // Temporary class for same-direction fadeout
        $tooltip = $('div[data-tooltip=' + $el.data('tooltip') + ']').addClass("out");

        // Remove all classes
        setTimeout(function() {
          $tooltip.removeClass("active").removeClass("out");
          }, 0);
        });
      });
    }

})(jQuery);