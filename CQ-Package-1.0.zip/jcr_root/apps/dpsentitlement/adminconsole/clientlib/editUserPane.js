/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * editUserPane 
 */
var editUserId = 0;
var editUserNeedsSave = false;
var validEditUserFName = false;
var validEditUserLName = false;
var validEditUserEmail = false;
var validEditUserLoginName = false;
var validEditUserPassword = false;
var validEditUserPasswordConfirm = false;

function initEditUserPane() {
	addValidationNonEmpty($('#editUserFNameInput'), onEditUserValidationFName);
	addValidationNonEmpty($('#editUserLNameInput'), onEditUserValidationLName);
	addValidationEmail($('#editUserEmailInput'), onEditUserValidationEmail);
	addValidationNewPassword($('#editUserNewPasswordInput'), onEditUserValidationPassword);
	addValidationConfirmPassword($('#editUserNewPasswordInputConfirm'), onEditUserValidationPasswordConfirm);

	$('#saveEditUserFolioButton').click(function() {
		editUserSubmit();
	});
	
	$('#editUserLoginNameInput').change(function() {
		setEditUserSetNeedsSave(true);
		freshEditUserValidationStatus();
	});
	$('#editUserFolioManagementPermission').change(function() {
		setEditUserSetNeedsSave(true);
		freshEditUserValidationStatus();
	});
	$('#editUserUserManagementPermission').change(function() {
		setEditUserSetNeedsSave(true);
		freshEditUserValidationStatus();
	});
	$('#editUserCompanyManagementPermission').change(function() {
		setEditUserSetNeedsSave(true);
		freshEditUserValidationStatus();
	});
	$('#editUserSettingManagementPermission').change(function() {
		setEditUserSetNeedsSave(true);
		freshEditUserValidationStatus();
	});
	$('#editUserNotificationManagementPermission').change(function() {
		setEditUserSetNeedsSave(true);
		freshEditUserValidationStatus();
	});
	$('#editUserUdidManagementPermission').change(function() {
		setEditUserSetNeedsSave(true);
		freshEditUserValidationStatus();
	});
	
	$.ajax({
		url: urlBase + UDID_SERVICE_PATH,
		statusCode: {
			200: function() {
				$('#editUserUdidManagementRow').show();
			}
		}
	});
	
	$.ajax({
		url: urlBase + "/SendPushNotificationService",
		statusCode: {
			200: function() {
				$('#editUserNotificationManagementRow').show();
			}
		}
	});
	
	$.ajax({
		url: urlBase + "/CompanyManagementService",
		statusCode: {
			200: function() {
				$('#editUserCompanyManagementRow').show();
			}
		}
	});
}

function setEditUserSetNeedsSave(status) {
	editUserNeedsSave = status;
}

function editUserPageBlurHandler() {
	if (editUserNeedsSave) {
		if (confirm(DISCARD_CHANGES) == false)
			return false;
	}
	hideEditUserPane();
	if (userList.getItem(manageUserSelectedUser.id).isReadOnly){
		$('#manageUserDeleteUser').hide();
	}
	return true;
}

function showEditUserPane() {
	validEditUserFName = true;
	validEditUserLName = true;
	validEditUserEmail = true;
	validEditUserLoginName = true;
	validEditUserPassword = true;
	validEditUserPasswordConfirm = true;
	
	if (!dpsPageBlurHandler())
		return;
	if (getCurrentCompany() != null && getCurrentCompany() != "") {
		$('#editUserCompanyManagementRow').hide();
	}
	
	setEditUserSetNeedsSave(false);
	dpsPageBlurHandler = editUserPageBlurHandler;

	$('#dpsAddUser').fadeOut(0);
	$('#dpsEditUser').fadeIn(kTransitionDuration);
	$('#dpsManageUsers').fadeOut(0);
	$('#showUsersConsoleButton').addClass('active');
	$('#showGroupsConsoleButton').removeClass('active');
	$('#dpsManageGroups').fadeOut(0);

	userManagementAddEditUserGroupButtonVisibility(false);
	freshEditUserValidationStatus();
}

function hideEditUserPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

	$('#dpsEditUser').fadeOut(0);
	if (userManagementUserConsoleSelected) {
		$('#dpsManageUsers').fadeIn(kTransitionDuration);
		$('#dpsManageGroups').fadeOut(0);
		$('#showUsersConsoleButton').addClass('active');
		$('#showGroupsConsoleButton').removeClass('active');
	}
	else {
		$('#dpsManageUsers').fadeOut(0);
		$('#dpsManageGroups').fadeIn(kTransitionDuration);
		$('#showUsersConsoleButton').removeClass('active');
		$('#showGroupsConsoleButton').addClass('active');
	}

	userManagementAddEditUserGroupButtonVisibility(true);
}

function setEditUserFolioFields(json) {
	editUserId = json.id;
	$('#editUserFNameInput').val(json.firstName);
	$('#editUserLNameInput').val(json.lastName);
	$('#editUserEmailInput').val(json.email);
	$('#editUserLoginNameInput').val(json.loginName);
	$('#editUserNewPasswordInput').val('');
	$('#editUserNewPasswordInputConfirm').val('');
	
	
	if(json.isReadOnly) {
		$('#editUserFNameInput').attr('readonly', 'readonly');
		$('#editUserLNameInput').attr('readonly', 'readonly');
		$('#editUserEmailInput').attr('readonly', 'readonly');
		$('#editUserNewPasswordRow').hide();
		$('#editUserNewPasswordConfirmRow').hide();
	}
	else {
		$('#editUserFNameInput').removeAttr('readonly');
		$('#editUserLNameInput').removeAttr('readonly');
		$('#editUserEmailInput').removeAttr('readonly');
		$('#editUserNewPasswordRow').show();
		$('#editUserNewPasswordConfirmRow').show();
	}
	
	$('#editUserFolioManagementPermission').find('option').each(function() {
		if ($(this).val() === json.productPrivilege) {
			$(this).prop('selected', true);
			return;
		}
	});
	
	$('#editUserUserManagementPermission').find('option').each(function() {
		if ($(this).val() === json.userPrivilege) {
			$(this).prop('selected', true);
			return;
		}
	});

	$('#editUserCompanyManagementPermission').find('option').each(function() {
		if ($(this).val() === json.companyPrivilege) {
			$(this).prop('selected', true);
			return;
		}
	});

	$('#editUserSettingManagementPermission').find('option').each(function() {
		if ($(this).val() === json.settingPrivilege) {
			$(this).prop('selected', true);
			return;
		}
	});

	$('#editUserNotificationManagementPermission').find('option').each(function() {
		if ($(this).val() === json.notificationPrivilege) {
			$(this).prop('selected', true);
			return;
		}
	});
	
	$('#editUserUdidManagementPermission').find('option').each(function() {
		if ($(this).val() === json.udidPrivilege) {
			$(this).prop('selected', true);
			return;
		}
	});
	
	$('#editUserFNameInput').keyup();
	$('#editUserLNameInput').keyup();
	$('#editUserEmailInput').keyup();
	$('#editUserLoginNameInput').keyup();
	$('#editUserNewPasswordInput').keyup();
	$('#editUserNewPasswordInputConfirm').keyup();
}

/* validation */
function onEditUserValidationFName(result) {
	validEditUserFName = result;
	setEditUserSetNeedsSave(true);
	freshEditUserValidationStatus();
}

function onEditUserValidationLName(result) {
	validEditUserLName = result;
	setEditUserSetNeedsSave(true);
	freshEditUserValidationStatus();
}

function onEditUserValidationEmail(result) {
	validEditUserEmail = result;
	setEditUserSetNeedsSave(true);
	freshEditUserValidationStatus();
}

function onEditUserValidationLoginName(result) {
	validEditUserLoginName = result;
	setEditUserSetNeedsSave(true);
	freshEditUserValidationStatus();
}

function onEditUserValidationPassword(result) {
	validEditUserPassword = result;
	setEditUserSetNeedsSave(true);
	freshEditUserValidationStatus();
}

function onEditUserValidationPasswordConfirm(result) {
	validEditUserPasswordConfirm = result;
	setEditUserSetNeedsSave(true);
	freshEditUserValidationStatus();
}

function getEditUserValidationResult() {
	return validEditUserFName && validEditUserLName;
}

function freshEditUserValidationStatus() {
	var ok = getEditUserValidationResult() && validEditUserEmail && editUserNeedsSave;
	var passwordOk = validEditUserPassword && validEditUserPasswordConfirm;
	var everythingOk = ok && passwordOk;
	$('#saveEditUserFolioButton').prop('disabled', everythingOk ? '' : 'disabled');
}

/* submittion */
function editUserSubmit() {
    if (__DEBUG__) {
	    var json = jsonEditUser_editUser;
	
	    editUserSubmitResult(json, '', null);
	    console.warn("DEBUG editUserSubmit");
	}
    else {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, "updateUser");
	    ajaxPost(url, 
	    	{
	        	'id' : editUserId,
	        	'firstName' : $('#editUserFNameInput').val(),
	        	'lastName' : $('#editUserLNameInput').val(),
	        	'email' : $('#editUserEmailInput').val(),
	        	'loginName' : $('#editUserLoginNameInput').val(),
	        	'password' : $('#editUserNewPasswordInput').val(),
	        	'productPrivilege' : $('#editUserFolioManagementPermission').val(),
	        	'userPrivilege' : $('#editUserUserManagementPermission').val(),
	        	'companyPrivilege' : $('#editUserCompanyManagementPermission').val(),
	        	'settingPrivilege' : $('#editUserSettingManagementPermission').val(),
	        	'notificationPrivilege' : $('#editUserNotificationManagementPermission').val(),
	        	'udidPrivilege' : $('#editUserUdidManagementPermission').val()
	        },
	        editUserSubmitResult);
    }
}

function editUserSubmitResult(data) {
    if (data.success) {
    	hideEditUserPane();
    	refreshAllUsersFolio(editUserId);
    }
    else {
        alert(data.message);
    }
}