/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
// holding current user privilege info
var signedInUserSession;

/* user */
function signedInUserUserPrivilege() {
	if (signedInUserSession != null) {
		if (signedInUserSession.userPrivilege === 'READONLY' ||
			signedInUserSession.userPrivilege === 'readOnly')
			return 'READ_ONLY';
		
		if (signedInUserSession.userPrivilege === 'READ_WRITE' ||
			signedInUserSession.userPrivilege === 'readWrite')
	return 'READ_WRITE';
	}	
	return 'DENY';
}

function signedInUserUserPrivilegeIsDeny() {
	return signedInUserUserPrivilege() === 'DENY';
}

function signedInUserUserPrivilegeIsReadOnly() {
	return signedInUserUserPrivilege() === 'READ_ONLY';
}

function signedInUserUserPrivilegeIsReadWrite() {
	return signedInUserUserPrivilege() === 'READ_WRITE';
}

/* product */
function signedInUserProductPrivilege() {
	if (signedInUserSession != null) {
		if (signedInUserSession.productPrivilege === 'READONLY' ||
			signedInUserSession.productPrivilege === 'readOnly')
			return 'READ_ONLY';
		
		if (signedInUserSession.productPrivilege === 'READ_WRITE' ||
			signedInUserSession.productPrivilege === 'readWrite')
			return 'READ_WRITE';
	}
	return 'DENY';
}

function signedInUserProductPrivilegeIsDeny() {
	var result = signedInUserProductPrivilege() === 'DENY'; 
	return result;
}

function signedInUserProductPrivilegeIsReadOnly() {
	var result = signedInUserProductPrivilege() === 'READ_ONLY';
	return result;
}

function signedInUserProductPrivilegeIsReadWrite() {
	var result = signedInUserProductPrivilege() === 'READ_WRITE';
	return result;
}

/*
 * UI stuffs
 */

function dpsRefreshPrivilege() {
	//$('#dpsTabHeader_2').css('display', 
		//signedInUserUserPrivilegeIsDeny() ? '' : 'none');
}
