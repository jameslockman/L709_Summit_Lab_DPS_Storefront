/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * http://www.my-html-codes.com/HTML5_tutorials/pure-javascript-html-tabs/index.php
 */ 
function initTabs() {
    if (inEditMode)
        return;
    
    dpsPageBlurHandler = dpsDefaultPageBlurHandler;

    // get tab container
    var container = document.getElementById("dpsTabContainer");
    
    //this adds click event to tabs
    var tabs = container.getElementsByClassName("dpsTabItem");
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].onclick = displayPage;
    }
    hideAllTabContents();
}

function hideAllTabContents() {
    var tabcon = document.getElementById("dpsTabsContent");
    var pages = tabcon.getElementsByClassName("dpsTabpage");
    for (var i = 0; i < pages.length; i++) {
        pages.item(i).style.display="none";
    };
}

// on click of one of tabs
function displayPage() {
	if ($(this).attr('class') === 'dpsTabActiveHeader')
		return;

	if (!dpsPageBlurHandler())
		return;
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

    var current = this.parentNode.getAttribute("data-current");
    if (current != null && current.length > 0) {
	    //remove class of activetabheader and hide old contents
	    document.getElementById("dpsTabHeader_" + current).removeAttribute("class");
	    document.getElementById("dpsTabpage_" + current).style.display="none";
    }
    
    var ident = this.id.split("_")[1];
    //add class of activetabheader to new active tab and show contents
    this.setAttribute("class","dpsTabActiveHeader");
    document.getElementById("dpsTabpage_" + ident).style.display="block";
    this.parentNode.setAttribute("data-current",ident);
    
    var needsUpdate = this.getAttribute("needsUpdate");
    var nodeType = this.getAttribute("nodeType");
    if (nodeType === "userManagement") {
        window.location.hash = "#userManagement";
//        if (needsUpdate == null) {
        showManageUsersPane();
//        }
    } else if (nodeType === "settingsManagement") {
    	window.location.hash = "#settingsManagement";
    	showSettingsPane();
    } else if (nodeType === "folioManagement") {
    	window.location.hash = "#folioManagement";
   		showFolioPane();
    } else if (nodeType == "udidBlacklist") {
    	window.location.hash = "#udidBlacklist";
    	showUdidBlacklistPane();
    }

    this.removeAttribute("needsUpdate");
}
