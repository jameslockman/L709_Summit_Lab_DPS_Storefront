/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/**
 * companyManagement
 */
var allCompanies = [];
var operatingCompanyIndex = -1;
var companyManagementPopupClickCount = 0;

function initCompanyManagement() {
	$("#currentCompanyInput").click(function() {
		if ($("#companyManagementPopup").hasClass("hide"))
			showCompanyManagement();
		else
			hideCompanyManagement();

		companyManagementPopupClickCount = 1;
	});
	$("#companyManagementPopup").click(function() {
		companyManagementPopupClickCount = 1;
	});
	$(document).click(function(event) {
		if (companyManagementPopupClickCount > 0) {
			companyManagementPopupClickCount--;
		}
		else {
		    if ($("#companyEditPopup").hasClass("hide") && $("#companyDeletePopup").hasClass("hide") && !$("#companyManagementPopup").hasClass("hide"))
		    	hideCompanyManagement();
		}
	});
}

function showCompanyManagement() {
	$("#companyManagementPopup").removeClass("hide");
	$("#companyManagementPopup").css({left:$("#currentCompanyInput").offset().left});
}

function hideCompanyManagement() {
	$("#companyManagementPopup").addClass("hide");
}

function cleanCompanyManagement() {
	$("#companyAddNameInput").val("");
	$("#companyAddUrlInput").val("");
	$("#companyAddAppIdInput").val("");

	$("#companyAddUrlInput").hide();
	$("#companyAddAppIdInput").hide();
	$("#companyAddAddButton").hide();
}

function showCompanySelector() {
	var url = urlBase + "/CompanyManagementService?authToken=" + getAuthToken() + "&action=listCompanies";
	ajaxGet(url, function(result) {
		if (result.success) {
			loadAllCompanies(result.data);
			
			var currentCompanyName = selectCompany(getCurrentCompany());
			$("#currentCompanyInput").val(currentCompanyName);
	
			if (getCompanyPrivilege() == "READ_WRITE")
				$("#companyAddNameInput").show();
		}
		else {
			loadAllCompanies(null);
			alert(result.message);
		}
	});
}

function loadAllCompanies(companies) {
	allCompanies = [];
	allCompanies.push({id:"", name:"Main", domain: ""});
	if (companies instanceof Array) { 
		for (var i = 0; i < companies.length; ++i) {
			allCompanies.push({id:companies[i].id, name:companies[i].name, domain:companies[i].domain, appId:companies[i].appId});
		}
	}
	renderAllCompanies();
}

function renderAllCompanies() {
	$("#companyList").empty();
	for (var i = 0; i < allCompanies.length; ++i) {
		var image1 = "<a class='flatButton icon cancel' href='#' onclick='onCompanyDeleteIconClick(" + i + ")' style='display:none'><span>&nbsp;</span></a>";
		var image2 = "<a class='flatButton icon edit' href='#' onclick='onCompanyEditIconClick(" + i + ")' style='display:none;margin-right:-10px'><span>&nbsp;</span></a>";
		$("<tr><td onclick='onCompanyClick(" + i + ")'>" + allCompanies[i].name + (i > 0 && getCompanyPrivilege() == "READ_WRITE" ? image1 + image2 : "") + "</td></tr>").appendTo("#companyList");
	}
	$("#companyList td").hover(
		function () {
			$(this).find("a").show();
		},
		function () {
			$(this).find("a").hide();
		}
	);	
}

function onCompanyClick(index) {
	if ($("#companyEditPopup").hasClass("hide") && $("#companyDeletePopup").hasClass("hide")) {
		var url = getActionUrl(COMPANY_MANAGEMENT_SERVICE, "selectCompany");
		url += "&id=" + allCompanies[index].id;
		ajaxGet(url, function(result) {
			if (result.success) {
				setCurrentCompany(result.data.id);
				hideCompanyManagement();
				showCompanySelector();
				refreshCurrentPage();
			}
			else
				alert(result.message);
		});
	}
}

function onCompanyDeleteIconClick(index) {
	operatingCompanyIndex = index;
	$("#companyDeletePrompt").html("Are you sure you want to delete <strong>" + allCompanies[index].name + "</strong>?");

	$("#companyDeletePopup").removeClass("hide");
	$('#pushNotificationOverlay').css('display', 'block');
	$("#companyDeletePopup").center(false);
}

function onCompanyDeleteYesButtonClick() {
	var url = getActionUrl(COMPANY_MANAGEMENT_SERVICE, "deleteCompany");
	url += "&id=" + allCompanies[operatingCompanyIndex].id;
	
	ajaxGet(url, function(result) {
		if (result.success) {
			$("#companyDeletePopup").addClass("hide");
			$('#pushNotificationOverlay').css('display', 'none');

			if (allCompanies[operatingCompanyIndex].id == getCurrentCompany())
				onCompanyClick(0);
			else 
				showCompanySelector();
		}
		else
			alert(result.message);
	});	
	companyManagementPopupClickCount = 1;
}

function onCompanyDeleteNoButtonClick() {
	$("#companyDeletePopup").addClass("hide");
	$('#pushNotificationOverlay').css('display', 'none');
	operatingCompanyIndex = -1;
	companyManagementPopupClickCount = 1;
}

function onCompanyEditIconClick(index) {
	operatingCompanyIndex = index;
	$("#companyEditPrompt").html("You are editing <strong>" + allCompanies[index].name + "</strong>");
	$("#companyEditNameInput").val(allCompanies[index].name);
	$("#companyEditUrlInput").val(allCompanies[index].domain);
	$("#companyEditAppIdInput").val(allCompanies[index].appId);

	$("#companyEditPopup").removeClass("hide");
	$('#pushNotificationOverlay').css('display', 'block');
	$("#companyEditPopup").center(false);
}

function onCompanyEditOKButtonClick() {
	var url = getActionUrl(COMPANY_MANAGEMENT_SERVICE, "updateCompany");
	ajaxPost(url, 
		{
			id: allCompanies[operatingCompanyIndex].id,
			name: $("#companyEditNameInput").val(),
			domain: $("#companyEditUrlInput").val(),
			appId: $("#companyEditAppIdInput").val()
		},
		function(result) {
			if (result.success) {
				$("#companyEditOKButton").attr("disabled", "disabled");
				$("#companyEditPopup").addClass("hide");
				$('#pushNotificationOverlay').css('display', 'none');

				showCompanySelector();
			}
			else
				alert(result.message);
		});	
	companyManagementPopupClickCount = 1;
}

function onCompanyEditCancelButtonClick() {
	$("#companyEditOKButton").attr("disabled", "disabled");
	$("#companyEditPopup").addClass("hide");
	$('#pushNotificationOverlay').css('display', 'none');
	operatingCompanyIndex = -1;
	companyManagementPopupClickCount = 1;
}

function selectCompany(company) {
	var selected = -1;
	if (company == null || company.length == 0)
		selected = 0;
	else {
		for (var i = 0; i < allCompanies.length; ++i) {
			if (allCompanies[i].id == company) {
				selected = i;
				break;
			}
		}
	}
	if (selected >= 0) {
		$("#companyList td:eq(" + selected + ")").addClass("selected");
		return allCompanies[selected].name;
	}
	else
		return "";
}

function onCompanyAddInputChange() {
	if ($("#companyAddNameInput").val().length > 0) {
		$("#companyAddUrlInput").show();
		$("#companyAddAppIdInput").show();
		$("#companyAddAddButton").show();
		if ($("#companyAddUrlInput").val().length > 0 || $("#companyAddAppIdInput").val().length > 0)
			$("#companyAddAddButton").removeAttr('disabled');
		else
			$("#companyAddAddButton").attr("disabled", "disabled");
	}
	else {
		if ($("#companyAddUrlInput").val().length == 0 && $("#companyAddAppIdInput").val().length == 0) {
			$("#companyAddUrlInput").hide();
			$("#companyAddAppIdInput").hide();
			$("#companyAddAddButton").hide();
		}
	}
}

function onCompanyEditInputChange() {
	if ($("#companyEditNameInput").val().length > 0 && ($("#companyEditUrlInput").val().length > 0 || $("#companyEditAppIdInput").val().length > 0))
		$("#companyEditOKButton").removeAttr('disabled');
	else
		$("#companyEditOKButton").attr("disabled", "disabled");
}

function onCompanyAddButtonClick() {
	createCompany();
}

function createCompany() {
	var url = getActionUrl(COMPANY_MANAGEMENT_SERVICE, "addCompany");
	ajaxPost(url, 
		{
			name: $("#companyAddNameInput").val(),
			domain: $("#companyAddUrlInput").val(),
			appId: $("#companyAddAppIdInput").val()
		}, 
		function(result) {
			if (result.success) {
				$("#companyAddNameInput").val("");
				$("#companyAddUrlInput").val("");
				$("#companyAddAppIdInput").val("");
	
				$("#companyAddUrlInput").hide();
				$("#companyAddAppIdInput").hide();
				$("#companyAddAddButton").hide();
				
				showCompanySelector();
			}
			else
				alert(result.message);
		});	
}