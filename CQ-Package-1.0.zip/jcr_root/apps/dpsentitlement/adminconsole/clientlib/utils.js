/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * Utils
 */
function checkNullString(data) {
	if (data == null)
		data = '';
	return data;
}

function checkNullArray(array) {
	if (array == null)
		array = [];
	return array;
}

function GetCtrlKeyState(event) {
    if (event.ctrlKey)
        return true;
    return false;
}

function GetShiftKeyState(event) {
    if (event.shiftKey)
        return true;
    return false;
}

function setCaretPosition(elemId, caretPos) {
    var elem = document.getElementById(elemId);

    if(elem != null) {
        if(elem.createTextRange) {
            var range = elem.createTextRange();
            range.move('character', caretPos);
            range.select();
        }
        else {
            if(elem.selectionStart) {
                elem.focus();
                elem.setSelectionRange(caretPos, caretPos);
            }
            else
                elem.focus();
        }
    }
}

function ajaxGet(url, onResult) {
	ajaxCall(url, "GET", null, onResult);
}

function ajaxPost(url, data, onResult) {
	ajaxCall(url, "POST", data, onResult);
}

function ajaxCall(url, method, data, onResult) {
	updateLoadingIndicator(1);
    $.ajax(
	    {
	        type : method,
	        url : url,
	        data : data,
	        cache: false,
	        success : function(json, textStatus, jqXHR) {
        		updateLoadingIndicator(-1);
	        	checkResult(json, onResult);
	        },
	        error: function(jqXHR, textStatus, errorThrown) {
        		updateLoadingIndicator(-1);
	        	var json = {success: false, httpResponseCode: 403, message: kInternalServerError};
	        	if (onResult)
	        		onResult(json);
	        	else
	        		alert(json.message);
	        },
	        dataType : "json"
	    });
}

function checkResult(json, onResult) {
	if (json == null)
		json = {success: false, httpResponseCode: 403, message: kInternalServerError};

	if (json.httpResponseCode == 401) {
		setSignInMessage(json.message && json.message.length > 0 ? json.message : kSessionExpired);
		logout();
	}
	else {
		if (!json.success && (!json.message || json.message.length == 0))
			json.message = kAccessDenied;
			
		if (onResult)
			onResult(json);
	}
}

function getActionUrl(service, action) {
	return urlBase + "/" + service + "?authToken=" + getAuthToken() + "&action=" + action; 
}