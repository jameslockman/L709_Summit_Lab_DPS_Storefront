/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * Change-Password
 */
var validNewPassword = false;
var validNewPasswordConfirmed = false;
var settingsAddIdMessageHtmlExtra = "<span class='input-validation-arrow-bottom'></span>";

function initChangePasswordPane() {
	addValidationNonEmpty($('#changePwdNewPasswordInput'), onChangePwdNewPassword);
	addValidationConfirmPassword($('#changePwdNewPasswordInputConfirm'), onChangePwdValidationPasswordConfirm);
}

function showChangePasswordPane() {
	//window.location.hash = '#changePassword';
	$('.dpsChangePasswordContainer').show();
}

function hideChangePasswordPane() {
	// clear the information field
	$('#changePasswordEmailInput').val('');
	$('#changePwdCurrentPasswordInput').val('');
	$('#changePwdNewPasswordInput').val('');
	$('#changePwdNewPasswordInputConfirm').val('');
	
	// hid the change password pane
	window.location.hash = '#';
	$('.dpsChangePasswordContainer').hide();
}

function onChangePwdNewPassword(result) {
	validNewPassword = result;
}

function onChangePwdValidationPasswordConfirm(result) {
	validNewPasswordConfirmed = result;
}

function changePassword() {
	var email = document.getElementById("changePasswordEmailInput").value;
	var currPassword = document.getElementById("changePwdCurrentPasswordInput").value;
	var newPassword = document.getElementById("changePwdNewPasswordInput").value;

	updateLoadingIndicator(1);

    var url = urlBase + "/ChangePassword";

    $.ajax(
    {
    	type : 'POST',
    	url : url,
    	data : {
    		emailAddress: email,
    		currPassword: currPassword,
    		newPassword: newPassword
    	},
    	success : changePasswordResult,
    	error : changePasswordError,
    	dataType : "json"
    });
	    
    return false;
}

function changePasswordResult(data, textStatus, jqXHR) {
	updateLoadingIndicator(-1);
	if (data.success) {
		alert("Password has been changed, please log in again with password.");
	} else {
		var errStr = "Password cannot be changed. Reason: " + data.message;
		alert(errStr);
	}
	hideChangePasswordPane();
}

function changePasswordError(jqXHR, textStatus, errorThrown) {
	updateLoadingIndicator(-1);
	alert("Password cannot be changed. Please try again.");
}