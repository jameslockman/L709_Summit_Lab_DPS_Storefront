/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * userManagementPane 
 */
var userManagementUserConsoleSelected = true;

function initUserManagementPane() {
	$("#showUsersConsoleButton").click(function() {
		showManageUsersPane();
	});
	$("#showGroupsConsoleButton").click(function() {
		showManageGroupsPane();
	});
}

function userManagementTabVisibility(visible) {
	if (getUserPrivilege() == 'DENY')
		visible = false;
	$('#dpsTabHeader_2').css('display', visible ? '' : 'none');
	$('#dpsUserManagement').css('display', visible ? '' : 'none');
	
	if (visible) {
		// refresh user folio page
		var selectedUser = $('#allUsersFolioTable').find('.dpsSelected');
		if (selectedUser.length == 0)
			refreshAllUsersFolio();
		else if (selectedUser.length == 1)
			refreshUsersFolioDetail();
		
		// refresh group folio page
		var selectedGroup = $('#allGroupsFolioTable').find('.dpsSelected');
		if (selectedGroup.length == 0)
			refreshAllGroupsFolio();
		else if (selectedGroup.length == 1)
			refreshGroupsFolioDetail();
	}
	return visible;
}

function userManagementAddEditUserGroupButtonVisibility(visible) {
	if (getUserPrivilege() === 'READ_WRITE') {
	}
	else
		visible = false;

	// Add User/Group
	$('#addNewUserButton').css('display', visible ? '' : 'none');
	$('#addNewMultiUserButton').css('display', visible ? '' : 'none');
	$('#addNewGroupButton').css('display', visible ? '' : 'none');
	
	// Edit User
	$('#manageUserEditUser').css('display', visible ? '' : 'none');
	$('#manageUserDeleteUser').css('display', visible ? '' : 'none');

	// Edit Group
	$('#manageGroupEditGroup').css('display', visible ? '' : 'none');
	$('#manageGroupDeleteGroup').css('display', visible ? '' : 'none');
}

function doSearch() {
	var searchValue = document.getElementById("dpsUserManagementSearchInput").value;
	console.log(searchValue);
	if (userManagementUserConsoleSelected) {
		refreshSearchedUsersFolioTable(searchValue);
	} else {
		refreshSearchedGroupsFolioTable(searchValue);
	}
}
