/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/*
 * folioPermissionPane
 */

var folioPermissionUsersLastSelectedRow = null;
var folioPermissionGroupsLastSelectedRow = null;
var folioPermissionGrantLastSelectedRow = null;
var folioPermissionDenyLastSelectedRow = null;
var initUserAndGroupTable = null;
var grantedUsers = null;
var grantedGroups = null;
var deniedUsers = null;
var deniedGroups = null;
var selectedFolios = null;
var dpsFolioPermissionUserList = null;
var dpsFolioPermissionTimeout = null;

function initFolioPermissionPane() {
	dpsFolioPermissionUserList = new PagedList('productAvailableUsers', 'tableProductAvailableUsers', null, 'user', userNameOnlyRenderer, toggleSelection, null, 'usersAndGroupsContainer');

	resizePane($('#dpsFolioPermissionContainer'),8);
	$('#folioExpiryDatePicker').datepicker({
	    format: 'MM-dd-yyyy',
	    autoclose: true,
	    clearBtn: true
	}).on('changeDate', function(e){
		setProductExpirationDate(e.date);
    }).on('clearDate', function(e){
		setProductExpirationDate(null);
    });
	$('#folioExpiryDatePicker').datepicker('startDate', new Date());
	$('#searchUserGroupKeyword').keyup(function() {
		if (dpsFolioPermissionTimeout)
			clearTimeout(dpsFolioPermissionTimeout);
		dpsFolioPermissionTimeout = setTimeout(refreshFolioSummaryTableWithFilter, 250);
	});
}

function showFolioPermissionPane(folios) {
	if (!dpsPageBlurHandler())
		return;
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

	$('#dpsFolio').addClass('dpsHidden');
	$('#dpsFolioPermission').removeClass('dpsHidden');
	
	var arrowCSS = getProductPrivilegeEditable() ? '' : 'none';
	$('#addProductsPermittedButton').css('display', arrowCSS);
	$('#removeProductsPermittedButton').css('display', arrowCSS);
	$('#addProductsDenyButton').css('display', arrowCSS);
	$('#removeProductsDenyButton').css('display', arrowCSS);
	$('#folioExpiryDatePicker').val('');

	selectedFolios = folios;
    selectedProduct = "";
    for (var i = 0; i < selectedFolios.length; ++i)
    	selectedProduct += selectedFolios[i] + ",";
    selectedProduct = selectedProduct.substring(0, selectedProduct.length - 1);
    
	if (selectedFolios.length > 1) {
		refreshMultiFolios();
		$('#expirationDateContainer').hide();
		$('#dpsFolioPermissionSummaryContainer').hide();
		$('#dpsFolioPermissionMultiFoliosContainer').show();
	}
	else {
		var json = getFolioById(selectedFolios[0]);
		refreshFolioSummaryTable(json);
		$('#expirationDateContainer').show();
		$('#dpsFolioPermissionSummaryContainer').show();
		$('#dpsFolioPermissionMultiFoliosContainer').hide();
	}
	
	listFolioForProduct();
}

function refreshMultiFolios() {
    var checkedCount = selectedFolios.length;
    var cancelIconHtml = checkedCount > 1 ? ' icon cancel' : '';
    var cancelActionHtml = checkedCount > 1 ? 'removeModifyFolioFromSelection(this);' : '';

    var ul = document.createElement('ul');
	$('#dpsFolioPermissionMultiFoliosContainer').html('');
    $('#dpsFolioPermissionMultiFoliosContainer').append(ul);
    for (var i = 0; i < selectedFolios.length; ++i) {
    	var json = getFolioById(selectedFolios[i]);
		var folioId = json.id;
		var folioName = json.name;
		var li = document.createElement('li');
		var html = '<a objId="' + folioId + '" id="removeModifyFolioFromListButton" class="flatButton' + cancelIconHtml + 
			'" href="#" onclick="' + cancelActionHtml + 'return false;"><span>' + folioName + '</span></a>';
		ul.appendChild(li);
		li.innerHTML = html;
	}
}

function removeModifyFolioFromSelection(sender) {
	var id = $(sender).attr('objId');
	var ul = $(sender).parent().parent();
	$(sender).parent().remove();

	for (var i = 0; i < selectedFolios.length; ++i) {
		if (selectedFolios[i] == id) {
			selectedFolios.splice(i, 1);
			showFolioPermissionPane(selectedFolios);
			return;
		}
	}
}

function refreshFolioSummaryTable(json) {
	var table = document.createElement('table');
    table.id = 'dpsFolioPermissionSummaryTable';
    
    var header = document.createElement('thead');
    table.appendChild(header);

    var cell = createTableData(header, '');
    var icon = document.createElement('div');
    if (json.previewURL == null || json.previewURL.length == 0)
    	icon.className = 'folioThumbnail';
    else {
    	icon.innerHTML = '<a href="' + json.previewURL + '" rel="lightbox"><img src="' + json.previewURL + '"></a>';
    	icon.className = 'folioThumbnail';
    	icon.style.background = '#fff';
    }
    cell.appendChild(icon);
    
    createTableData(header, 'Product Id');
    createTableData(header, 'Publication Name');
    createTableData(header, 'Folio Number');
    createTableData(header, 'Target Resolution');
    createTableData(header, 'Description');
    createTableData(header, 'Date Created');

    if (json != null) {
	    var row = document.createElement('tr');
	    row.style.paddingTop = "5px";
	    table.appendChild(row);
	
	    createTableData(row, '');
	    createTableData(row, json.id);
	    
//	    pubNameMargin = createTableData(row, json.name);
//		createTableData(row, json.issue);
//		createTableData(row, json.targetDimensions);
//		createTableData(row, json.description);
//		createTableData(row, json.publicationDate);
		
		
	    for(i = 0; i < json.issues.length; i++) {
	    	if (i > 0) {
	    		var row = document.createElement('tr');
			    table.appendChild(row);
			    createTableData(row, '');
	    		var productIdDivider = createTableData(row, '');
	    	}
		    var pubNameMargin = createTableData(row, json.issues[i].name);
		    createTableData(row, json.issues[i].issue);
		    createTableData(row, json.issues[i].targetDimensions);
		    createTableData(row, json.issues[i].description);
		    createTableData(row, json.issues[i].publicationDate);
	    }
	}

    $('#dpsFolioPermissionSummaryContainer').html('');
    $('#dpsFolioPermissionSummaryContainer').append(table);
}

function refreshFolioSummaryTableWithFilter() {
	dpsFolioPermissionTimeout = null;
	getAllUsers(null, $('#searchUserGroupKeyword').val());
}

function toggleSelection(e) {
	if (e == null)
		return;
	
	var table = $('#' + $(this).closest('table').attr('id'));
	var index = $(this).get(0).rowIndex;
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else {
		if (GetShiftKeyState(e)) {
			var lastIndex = table.attr('lastSelectedIndex');
			if (lastIndex != null) {
				var fm = index;
				var to = lastIndex;
				if (fm > to) {
					to = index;
					fm = lastIndex;
				}
	
				table.find('.dpsSelected').each(function() {
					$(this).removeClass("dpsSelected");
				});
	
				var i = 0;
				table.find('tr').each(function() {
					if (i >= fm && i <= to && $(this).css('display') != 'none')
						$(this).addClass("dpsSelected");
					i++;
				});
			}
		}
		else {
			table.find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});
			$(this).toggleClass("dpsSelected");
		}
	}
	table.attr('lastSelectedIndex', index);
	
	refreshProductsArrowButtons();
}

function refreshProductsArrowButtons() {
    var numUsers = $('#tableProductAvailableUsers').find('.dpsSelected').length;
    var numGroups = $('#tableProductAvailableGroups').find('.dpsSelected').length;
    if (numUsers > 0 || numGroups) {
        $("#addProductsPermittedButton").addClass("dpsEnabled");
        $("#addProductsDenyButton").addClass("dpsEnabled");
    }
    else {
        $("#addProductsPermittedButton").removeClass("dpsEnabled");
        $("#addProductsDenyButton").removeClass("dpsEnabled");
    }
    var numGrantedUsers = $('#tableProductGrantAccessUsers').find('.dpsSelected').length;
    var numGrantedGroups = $('#tableProductGrantAccessGroups').find('.dpsSelected').length;
    var numDeniedUsers = $('#tableProductDenyAccessUsers').find('.dpsSelected').length;
    var numDeniedGroups = $('#tableProductDenyAccessGroups').find('.dpsSelected').length;
    
    if (numGrantedUsers > 0 || numGrantedGroups > 0 || numDeniedUsers > 0 || numDeniedGroups > 0) {
        $("#removeProductsPermittedButton").addClass("dpsEnabled");
        $("#removeProductsDenyButton").addClass("dpsEnabled");
    }
    else {
        $("#removeProductsPermittedButton").removeClass("dpsEnabled");
        $("#removeProductsDenyButton").removeClass("dpsEnabled");
    }
}

/*
 * Handle grant/deny access update 
 */
function performProductsAction(addOrDelete, grantOrDeny, product) {
	var selectedUsers = '';
	var elementId = '#tableProduct' + (addOrDelete == "add" ? "Available" : (grantOrDeny + "Access")) + "Users"; 
    $(elementId).find('.dpsSelected').each(function() {
        var objId = this.attributes['objId'];
        if (objId != null)
       		selectedUsers += objId.value + ",";
    });
	var selectedGroups = '';
	elementId = '#tableProduct' + (addOrDelete == "add" ? "Available" : (grantOrDeny + "Access")) + "Groups"; 
    $(elementId).find('.dpsSelected').each(function() {
        var objId = this.attributes['objId'];
        if (objId != null)
       		selectedGroups += objId.value + ",";
    });

    if (selectedUsers.length > 0)
    	performProductsActionUsers();
    else if (selectedGroups.length > 0)
		performProductsActionGroups();
    
    function performProductsActionUsers() {
    	var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, addOrDelete + "Users" + (addOrDelete == "add" ? "To" : "From") + grantOrDeny + "List");
    	ajaxPost(url,
    		{
    			'products': product,
    			'users' : selectedUsers.substring(0, selectedUsers.length)
    		}, 
    		performProductsActionUsersDone);
    }
    
    function performProductsActionUsersDone(data) {
		if (data.success) {
	    	if (selectedGroups.length > 0)
	    		performProductsActionGroups();
	    	else
	    		performProductsActionAllDone();
		}
		else
			alert(data.message);
    }
    
    function performProductsActionGroups() {
		var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, addOrDelete + "Groups" + (addOrDelete == "add" ? "To" : "From") + grantOrDeny + "List");
    	ajaxPost(url,
    		{
    			'products': product,
    			'groups' : selectedGroups.substring(0, selectedGroups.length)
    		}, 
    		performProductsActionGroupsDone);
    }

    function performProductsActionGroupsDone(data) {
		if (!data.success)
			alert(data.message);
		performProductsActionAllDone();
    }
    
    function performProductsActionAllDone() {
    	getGrantAndDenyList();
    }
}

function addProductsPermitted() {
    performProductsAction('add', 'Grant', selectedProduct);
}

function removeProductsPermitted() {
    performProductsAction('delete', 'Grant', selectedProduct);
}

function addProductsDeny() {
    performProductsAction('add', 'Deny', selectedProduct);
}

function removeProductsDeny() {
    performProductsAction('delete', 'Deny', selectedProduct);
}

/* 
 * products folio
 */
function listFolioForProduct() {
	$('#productAvailableUsers').html('');
	$('#productAvailableGroups').html('');
	$('#productGrantAccessUsers').html('');
	$('#productGrantAccessGroups').html('');
	$('#productDenyAccessUsers').html('');
	$('#productDenyAccessUsers').html('');
	
	refreshProductsArrowButtons();

	$('.nullProduct').remove();

	var counter = 6;
	
	getAllUsers(onDone);
	getAllGroups(onDone);
	getGrantedUsers(onDone);
	getGrantedGroups(onDone);
	getDeniedUsers(onDone);
	getDeniedGroups(onDone);
	
	if (selectedFolios.length == 1)
		getProductExpirationDate();
    
    function onDone() {
    	counter--;
    	if (counter <= 0) {
    		refreshAvailableUsersAndGroups();
    	}
    }
}

function getGrantAndDenyList() {
	var counter = 4;
	
	getGrantedUsers(onDone);
	getGrantedGroups(onDone);
	getDeniedUsers(onDone);
	getDeniedGroups(onDone);
	
    function onDone() {
    	counter--;
    	if (counter <= 0) {
    		refreshAvailableUsersAndGroups();
    		refreshProductsArrowButtons();
    	}
    }
}

function refreshAvailableUsersAndGroups() {
	refreshAvailableUsers();
	refreshAvailableGroups();
}

function refreshAvailableUsers() {
    $('#tableProductAvailableUsers').find('tr').each(function() {
    	$(this).removeClass("dpsSelected");
    	
       	var id = $(this).attr('objId');
       	for (var i = 0; i < grantedUsers.length; ++i) {
       		if (grantedUsers[i].id == id) {
       			$(this).hide();
       			return;
       		}
       	}
       	for (var i = 0; i < deniedUsers.length; ++i) {
       		if (deniedUsers[i].id == id) {
       			$(this).hide();
       			return;
       		}
       	}
       	$(this).show();
    });
}

function refreshAvailableGroups() {
	var filter = $('#searchUserGroupKeyword').val().toLowerCase();
	
    $('#tableProductAvailableGroups').find('tr').each(function() {
    	$(this).removeClass("dpsSelected");
       	var id = $(this).attr('objId');
       	for (var i = 0; i < grantedGroups.length; ++i) {
       		if (grantedGroups[i].id == id) {
       			$(this).hide();
       			return;
       		}
       	}
       	for (var i = 0; i < deniedGroups.length; ++i) {
       		if (deniedGroups[i].id == id) {
       			$(this).hide();
       			return;
       		}
       	}
       	var name = $(this).find('td').text();
       	if (name && filter.length > 0 && name.toLowerCase().indexOf(filter) < 0)
       		$(this).hide();
       	else
       		$(this).show();
    });
}

function getAllUsers(onDone, filter) {
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_USER_SERVICE) + (filter ? '&filter=' + filter : '');
	dpsFolioPermissionUserList.url = url;
	dpsFolioPermissionUserList.onDataUpdated = onDataUpdated;
	dpsFolioPermissionUserList.showList(0);

	function onDataUpdated() {
		onDpsFolioPermissionUserDataLoaded();
		if (onDone)
			onDone();
	}
}

function getAllGroups(onDone) {
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'listGroups');
	ajaxGet(url, function(data) {
		var groups = null;
		if (data.success)
			groups = data.data;
		else
			alert(data.message);

		var editable = getProductPrivilegeEditable();
    	createAccessDenyTable('tableProductAvailableGroups', 'productAvailableGroups', toggleSelection, groups, editable, 'group');
    	if (onDone)
    		onDone();
	});
}
 
function getGrantedUsers(onDone) {
	var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, 'listGrantedUsers') + '&products=' + selectedProduct;
    loadAllItems(url, function(items) {
    	grantedUsers = items;
    	var editable = getProductPrivilegeEditable();
    	createAccessDenyTable('tableProductGrantAccessUsers', 'productGrantAccessUsers', toggleSelection, grantedUsers, editable, 'user');
    	if (onDone)
    		onDone();
    });
}

function getGrantedGroups(onDone) {
	var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, 'listGrantedGroups') + '&products=' + selectedProduct;
	ajaxGet(url, function(data) {
		if (data.success)
			grantedGroups = data.data;
		else {
			grantedGroups = [];
			alert(data.message);
		}
    	var editable = getProductPrivilegeEditable();
    	createAccessDenyTable('tableProductGrantAccessGroups', 'productGrantAccessGroups', toggleSelection, grantedGroups, editable, 'group');
    	if (onDone)
    		onDone();
	});
}

function getDeniedUsers(onDone) {
	var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, 'listDeniedUsers') + '&products=' + selectedProduct;
	loadAllItems(url, function(items) {
   		deniedUsers = items; 
    	var editable = getProductPrivilegeEditable();
    	createAccessDenyTable('tableProductDenyAccessUsers', 'productDenyAccessUsers', toggleSelection, deniedUsers, editable, 'user');
    	if (onDone)
    		onDone();
    });
}

function getDeniedGroups(onDone) {
	var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, 'listDeniedGroups') + '&products=' + selectedProduct;
	ajaxGet(url, function(data) {
		if (data.success)
			deniedGroups = data.data;
		else {
			deniedGroups = [];
			alert(data.message);
		}
    	var editable = getProductPrivilegeEditable();
    	createAccessDenyTable('tableProductDenyAccessGroups', 'productDenyAccessGroups', toggleSelection, deniedGroups, editable, 'group');
    	if (onDone)
    		onDone();
	});
}
/* 
 * expiration date
 */
function setProductExpirationDate(date) {
	var expirationDate = date ? date.getTime() : 0;
    var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, 'setProductExpirationDate');
    ajaxPost(url, 
    	{
            'id': selectedProduct,
            'expirationDate': expirationDate 
        }, 
        setProductExpirationDateResult);
}

function setProductExpirationDateResult(data) {
    if (!data.success) {
    	alert(data.message);
    }
}

function getProductExpirationDate() {
    var url = getActionUrl(FOLIO_PERMISSIONS_SERVICE, 'getProductExpirationDate') + "&id=" + selectedProduct;
    ajaxGet(url, getProductExpirationDateResult);
}

function getProductExpirationDateResult(data) {
    if (data.success) {
    	var intVal;
    	if (data.data.expirationDate == null || data.data.expirationDate === '') {
    		$('#folioExpiryDatePicker').val('');
    	}
    	else if (isNaN(data.data.expirationDate)) {
    		$('#folioExpiryDatePicker').val('INVALID');
    	}
    	else {
    		var date = new Date(parseInt(data.data.expirationDate));
    		$('#folioExpiryDatePicker').datepicker('setDate', date);
    	}
    }
    else {
    	alert(data.message);
    }
}

function onDpsFolioPermissionUserDataLoaded() {
	if (dpsFolioPermissionUserList.items.length > dpsFolioPermissionUserList.pageSize)
		$('#dpsFolioPermissionUserLoadedPrompt').text('Total: ' + dpsFolioPermissionUserList.items.length + ', Loaded: ' + dpsFolioPermissionUserList.numOfLoaded);
	else
		$('#dpsFolioPermissionUserLoadedPrompt').text('');
	
    refreshAvailableUsersAndGroups();

    if ($('#usersAndGroupsContainer').get(0).scrollHeight <= $('#usersAndGroupsContainer').get(0).clientHeight && !dpsFolioPermissionUserList.isAllLoaded())
    	dpsFolioPermissionUserList.onScroll();
}
