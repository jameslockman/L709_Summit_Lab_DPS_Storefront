// jQuery plug-in
(function($) {

	var defaults = {
		columns: [],
		onInit: function(table) {},
		onCellSelected: function(table){},
		onRowCount: function(data) {},
		onTableCell: function(data) {}
	};

	var container;
	var table;
	var dataSource;
	var options;
	var methods = {
		init: function(opt) {
			options = $.extend(defaults, opt);
			
			return this.each(function() {
				var opt = options;

				//Assign current element to variable
		        var obj = $(this);
		        
		        var header = $('<table></table>').addClass('jtlHeader');
		        var headerRow = $('<tr></tr>');
		        $(opt.columns).each(function() {
		        	var td = $('<td></td>').css('width', '' + 100 / opt.columns.length + '\%');
		        	td.html('' + this);
		        	headerRow.append(td);
		        });
		        
		        header.append(headerRow);
		        obj.append(header);

		        container = $('<div></div>').addClass('jtlTableContainer');
		        obj.append(container);

		        table = $('<table></table>').addClass('jtl');
		        container.append(table);

		        opt.onInit(obj);
			});
		},

		reloadData: function(json) {
			dataSource = json;
			table.html('');
			
			var rowCount = 0;
			for (col = 0; col < options.columns.length; col++) {
				var length = options.onRowCount(json, col);
				if (rowCount < length)
					rowCount = length;
			}
			
			for (row = 0; row < rowCount; row++) {
				var tr = $('<tr></tr>');
				for (col = 0; col < options.columns.length; col++) {
					var rowCount = options.onRowCount(json, col);
					var td;
					if (row < rowCount) {
						td = options.onTableCell(json, col, row);
						td.addClass('dpsEnabled')
					}
					else {
						td = $('<td></td>').addClass('empty');
			            //td.style.backgroundColor = 'transparent';
			            //td.style.cursor = 'default';
					}
					td.css('width', '' + 100 / options.columns.length + '\%');
					tr.append(td);
				}
				table.append(tr);
			}
		}
	};

	$.fn.jTableList = function(method) {
		// Method calling logic
	    if (methods[method]) {
	    	return methods[method].apply( this, Array.prototype.slice.call(arguments, 1));
	    } else if (typeof method === 'object' || ! method) {
	    	return methods.init.apply(this, arguments);
	    } else {
	    	$.error('Method ' +  method + ' does not exist on jQuery.jTableList');
	    }   
	};

})(jQuery);