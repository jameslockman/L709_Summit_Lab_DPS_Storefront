/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * addGroupPane 
 */
var lastSelectedSoruceRow = null;
var lastSelectedTargetRow = null;

var lastSelectedSoruceGroupRow = null;
var lastSelectedTargetGroupRow = null;
var avaialbeGroupsForNewGroup = null;

var addedGroupId = null;
var addGroupUserList = null;
var addGroupTimeout = null;

function initAddGroupPane() {
	addGroupUserList = new PagedList('addGroupSourceUsersContainer', 'addGroupSourceUsersTable', null, 'user', userNameOnlyRenderer, toogleAddGroupSourceUsersRow, onAddGroupUserDataLoaded);
	
	addValidationNonEmpty($('#addGroupNameInput'), onAddGroupValidate);
	
	$('#saveAddGroupFolioButton').click(function() {
		addGroupSubmit();
	});
	
	$('#addGroupSearchUser').keyup(function() {
		if (addGroupTimeout)
			clearTimeout(addGroupTimeout);
		addGroupTimeout = setTimeout(refreshAddGroupSourceUsersTableWithFilter, 250);
	});

	$('#addGroupSearchGroup').keyup(function() {
		refreshAddGroupSourceGroupsTableWithFilter($(this).val());
	});
}

function setAddGroupNeedsSave(status) {
	addGroupNeedsSave = status;
}

function addGroupPageBlurHandler() {
	if (addGroupNeedsSave) {
		if (confirm(DISCARD_CHANGES) == false)
			return false;
	}
	hideAddGroupPane();
	return true;
}

function showAddGroupPane() {
	if (!dpsPageBlurHandler())
		return;

	// Need to clear and trigger validation routines before clear the NeedsSave flag...
	clearAddGroupFolioFields();

	setAddGroupNeedsSave(false);
	dpsPageBlurHandler = addGroupPageBlurHandler;
	
	$('#dpsAddGroup').fadeIn(kTransitionDuration);

	$('#dpsManageGroups').fadeOut(0);
	$('#dpsManageUsers').fadeOut(0);
	$('#showUsersConsoleButton').removeClass('active');
	$('#showGroupsConsoleButton').addClass('active');
	
	userManagementAddEditUserGroupButtonVisibility(false);
	$('#addGroupTargetUsersTable').html('');
	$('#addGroupTargetGroupsTable').html('');
	resizePane($('#dpsAddGroup'),-13);
}

function hideAddGroupPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

	$('#dpsAddGroup').fadeOut(0);
	if (userManagementUserConsoleSelected) {
		$('#dpsManageUsers').fadeIn(kTransitionDuration);
		$('#dpsManageGroups').fadeOut(0);
		$('#showUsersConsoleButton').addClass('active');
		$('#showGroupsConsoleButton').removeClass('active');
	}
	else {
		$('#dpsManageUsers').fadeOut(0);
		$('#dpsManageGroups').fadeIn(kTransitionDuration);
		$('#showUsersConsoleButton').removeClass('active');
		$('#showGroupsConsoleButton').addClass('active');
	}

	userManagementAddEditUserGroupButtonVisibility(true);
}

function clearAddGroupFolioFields() {
	$('#addGroupNameInput').val('');
	$('#addGroupDescriptionInput').val('');

	$('#addGroupNameInput').keyup();
	$('#addGroupDescriptionInput').keyup();

	refreshAddGroupSourceUsers();
	refreshAddGroupSourceGroups();
}

function onAddGroupValidate(result) {
	setAddGroupNeedsSave(true);
	$('#saveAddGroupFolioButton').prop('disabled', !result);
}

/*
 * Get users
 */
function refreshAddGroupArrows() {
	var sourceCount = $('#addGroupSourceUsersTable').find('.dpsSelected').length;
    if (sourceCount > 0) {
        $("#addAddGroupUsersToTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#addAddGroupUsersToTargetButton").removeClass("dpsEnabled");
    }
    
    var targetCount = $('#addGroupTargetUsersTable').find('.dpsSelected').length;
    if (targetCount > 0) {
        $("#removeAddGroupUsersFromTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#removeAddGroupUsersFromTargetButton").removeClass("dpsEnabled");
    }
}

function getItemIndex(list, item) {
	var index = -1;
	var i = 0;
	$(list).find('tr').each(function() {
		if (this == item) {
			index = i;
			return;
		}
		i++;
	});
	return index;
}

function compareItemOrder(item1, item2) {
	var idx1 = getItemIndex($('#addGroupSourceUsersTable'), item1);
	var idx2 = getItemIndex($('#addGroupSourceUsersTable'), item2);
}

function toogleAddGroupSourceUsersRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (lastSelectedSoruceRow != null) {
			var lastIndex = getItemIndex($('#addGroupSourceUsersTable'), lastSelectedSoruceRow);
			var index = getItemIndex($('#addGroupSourceUsersTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#addGroupSourceUsersTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#addGroupSourceUsersTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#addGroupSourceUsersTable').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";
		$('#addGroupSourceUsersTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}

	lastSelectedSoruceRow = this;
	refreshAddGroupArrows();
}

function toogleAddGroupTargetUsersRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (lastSelectedSoruceRow != null) {
			var lastIndex = getItemIndex($('#addGroupTargetUsersTable'), lastSelectedTargetRow);
			var index = getItemIndex($('#addGroupTargetUsersTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#addGroupTargetUsersTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#addGroupTargetUsersTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		$('#addGroupTargetUsersTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).toggleClass("dpsSelected");
	}

	lastSelectedTargetRow = this;
	refreshAddGroupArrows();
}

function addAddGroupUsersToTarget() {
	var target = $('#addGroupTargetUsersTable');
	$('#addGroupSourceUsersTable').find('.dpsSelected').each(function() {
		var row = $(this).removeClass("dpsSelected").clone();
		row.click(toogleAddGroupTargetUsersRow);
		row.appendTo(target);
		setAddGroupNeedsSave(true);
		$(this).hide();
	});
	var users = $('#addGroupTargetUsersTable>tbody').children('tr').detach();
	var selectUserInserted = false;
	var currentUser;
	var selectedUser = users.last().text().toLowerCase();
	$(users).each(function(index) {
		currentUser = $(this).text().toLowerCase();
		if (selectUserInserted == true && index == users.length-1){
		}else if (selectUserInserted == false && currentUser >= selectedUser){
			$('#addGroupTargetUsersTable>tbody:last').append(users.last());
			selectUserInserted = true;
			$('#addGroupTargetUsersTable>tbody:last').append($(this));
		}else {
			$('#addGroupTargetUsersTable>tbody:last').append($(this));
		}
	});
	refreshAddGroupArrows();
}

function removeAddGroupUsersFromTarget() {
	var target = $('#addGroupSourceUsersTable');
	$('#addGroupTargetUsersTable').find('.dpsSelected').each(function() {
		var id = $(this).attr('objId');
		$(this).remove();
		target.find('[objId=' + id + ']').each(function() {
			$(this).show();
		});
		setAddGroupNeedsSave(true);
	});
	refreshAddGroupArrows();
}

function refreshAddGroupSourceUsers(filter) {
    lastSelectedSoruceRow = null;
	lastSelectedTargetRow = null;
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_USER_SERVICE) + (filter ? '&filter=' + filter : '');
	addGroupUserList.url = url;
	addGroupUserList.showList(0);
}

function addGroupUserIsSelected(userId) {
	var selected = false;
	$('#addGroupTargetUsersTable').find('tr').each(function() {
		if ($(this).attr("objId") === userId) {
			selected = true;
			return;
		}
	});
	return selected;
}

function refreshAddGroupSourceUsersTableWithFilter() {
	addGroupTimeout = null;
	refreshAddGroupSourceUsers($('#addGroupSearchUser').val());
}

/*
 * Get groups
 */
function refreshAddGroupGroupArrows() {
	var sourceCount = $('#addGroupSourceGroupsTable').find('.dpsSelected').length;
    if (sourceCount > 0) {
        $("#addAddGroupGroupsToTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#addAddGroupGroupsToTargetButton").removeClass("dpsEnabled");
    }
    
    var targetCount = $('#addGroupTargetGroupsTable').find('.dpsSelected').length;
    if (targetCount > 0) {
        $("#removeAddGroupGroupsFromTargetButton").addClass("dpsEnabled");
    }
    else {
        $("#removeAddGroupGroupsFromTargetButton").removeClass("dpsEnabled");
    }
}

function toogleAddGroupSourceGroupsRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (lastSelectedSoruceGroupRow != null) {
			var lastIndex = getItemIndex($('#addGroupSourceGroupsTable'), lastSelectedSoruceGroupRow);
			var index = getItemIndex($('#addGroupSourceGroupsTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#addGroupSourceGroupsTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#addGroupSourceGroupsTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		$('#addGroupSourceGroupsTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).toggleClass("dpsSelected");
	}

	lastSelectedSoruceGroupRow = this;
	refreshAddGroupGroupArrows();
}

function toogleAddGroupTargetGroupsRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (lastSelectedSoruceGroupRow != null) {
			var lastIndex = getItemIndex($('#addGroupTargetGroupsTable'), lastSelectedTargetGroupRow);
			var index = getItemIndex($('#addGroupTargetGroupsTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}
			
			$('#addGroupTargetGroupsTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#addGroupTargetGroupsTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		var origClass = $(this).hasClass("dpsSelected") ? "dpsSelected" : "";
		var count = $('#addGroupTargetGroupsTable').find('.dpsSelected').length;
		if (count > 1)
			origClass = "";

		$('#addGroupTargetGroupsTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).addClass(origClass);
		$(this).toggleClass("dpsSelected");
	}

	lastSelectedTargetGroupRow = this;
	refreshAddGroupGroupArrows();
}

function addAddGroupGroupsToTarget() {
	var target = $('#addGroupTargetGroupsTable');
	$('#addGroupSourceGroupsTable').find('.dpsSelected').each(function() {
		$(this).removeClass("dpsSelected").appendTo(target);
		this.onclick = toogleAddGroupTargetGroupsRow;
		setAddGroupNeedsSave(true);
	});
	var groups = $('#addGroupTargetGroupsTable>tbody').children('tr').detach();
	var selectGroupInserted = false;
	var currentGroup;
	var selectedGroup = groups.last().text().toLowerCase();
	$(groups).each(function(index) {
		currentGroup = $(this).text().toLowerCase();
		if (selectGroupInserted == true && index == groups.length-1){
		}else if (selectGroupInserted == false && currentGroup >= selectedGroup){
			$('#addGroupTargetGroupsTable>tbody:last').append(groups.last());
			selectGroupInserted = true;
			$('#addGroupTargetGroupsTable>tbody:last').append($(this));
		}else {
			$('#addGroupTargetGroupsTable>tbody:last').append($(this));
		}
	});
	refreshAddGroupGroupArrows();
}

function removeAddGroupGroupsFromTarget() {
	var target = $('#addGroupSourceGroupsTable');
	$('#addGroupTargetGroupsTable').find('.dpsSelected').each(function() {
		$(this).removeClass("dpsSelected").appendTo(target);
		this.onclick = toogleAddGroupSourceGroupsRow;
		setAddGroupNeedsSave(true);
	});
	var groups = $('#addGroupSourceGroupsTable>tbody').children('tr').detach();
	var selectGroupInserted = false;
	var currentGroup;
	var selectedGroup = groups.last().text().toLowerCase();
	$(groups).each(function(index) {
		currentGroup = $(this).text().toLowerCase();
		if (selectGroupInserted == true && index == groups.length-1){
		}else if (selectGroupInserted == false && currentGroup >= selectedGroup){
			$('#addGroupSourceGroupsTable>tbody:last').append(groups.last());
			selectGroupInserted = true;
			$('#addGroupSourceGroupsTable>tbody:last').append($(this));
		}else {
			$('#addGroupSourceGroupsTable>tbody:last').append($(this));
		}
	});
	refreshAddGroupGroupArrows();
}

function refreshAddGroupSourceGroups() {
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_GROUP_SERVICE);
    ajaxGet(url, refreshAddGroupSourceGroupsResult);
}

function refreshAddGroupSourceGroupsResult(data) {
    if (data.success) {
    	refreshAddGroupSourceGroupsTable(data.data);
    }
    else {
    	refreshAddGroupSourceGroupsTable(null);
        alert(data.message);
    }
}

function refreshAddGroupSourceGroupsTable(json) {
	avaialbeGroupsForNewGroup = json;
	
	var table = document.createElement('table');
    table.id = 'addGroupSourceGroupsTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    if (json != null) {
	    for(i = 0; i < json.length; i++) {
			if (!addGroupGroupIsSelected(json[i].id)) {
		        var row = document.createElement('tr');
		        row.setAttribute('objId', json[i].id);
		        row.onclick = toogleAddGroupSourceGroupsRow;
		        tbody.appendChild(row);
		        createTableData(row, json[i].name);
			}
	    }
    }

	$('#addGroupSourceGroupsContainer').html('');
    $('#addGroupSourceGroupsContainer').append(table);
    lastSelectedSoruceGroupRow = null;
	lastSelectedTargetGroupRow = null;
}

function addGroupGroupIsSelected(memberId) {
	var selected = false;
	$('#addGroupTargetGroupsTable').find('tr').each(function() {
		if ($(this).attr("objId") === memberId) {
			selected = true;
			return;
		}
	});
	return selected;
}

function refreshAddGroupSourceGroupsTableWithFilter(keyword) {
	var table = document.createElement('table');
    table.id = 'addGroupSourceGroupsTable';
    
    var tbody = document.createElement('tbody');
    table.appendChild(tbody);
    
    if (avaialbeGroupsForNewGroup != null) {
    	keyword = keyword.toLowerCase();
    	var json = avaialbeGroupsForNewGroup;
    	if (json != null) {
		    for(i = 0; i < json.length; i++) {
		    	if (json[i].name.toLowerCase().indexOf(keyword) != -1) {
		    		
		    		// ignore if alrady on the target list
		    		if (!addGroupGroupIsSelected(json[i].id)) {
				        var row = document.createElement('tr');
				        row.setAttribute('objId', json[i].id);
				        row.onclick = toogleAddGroupSourceGroupsRow;
				        tbody.appendChild(row);
				        createTableData(row, json[i].name);
		    		}
			    }
		    }
    	}
    }

	$('#addGroupSourceGroupsContainer').html('');
    $('#addGroupSourceGroupsContainer').append(table);
	lastSelectedSoruceGroupRow = null;
	lastSelectedTargetGroupRow = null;
}

function addGroupGetSelectedUsers() {
	var members = '';

	$('#addGroupTargetUsersTable').find('tr').each(function() {
		if (members.length > 0)
			members += ',';
		members += $(this).attr('objId');
	});

	return members;
}

function addGroupGetSelectedGroups() {
	var members = '';

	$('#addGroupTargetGroupsTable').find('tr').each(function() {
		if (members.length > 0)
			members += ',';
		members += $(this).attr('objId');
	});
	
	return members;
}

function addGroupSubmit() {
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'addGroup');
    ajaxPost(url, 
        {
        	'name' : $('#addGroupNameInput').val(),
        	'description' : $('#addGroupDescriptionInput').val()
        },
        addGroupSubmitResult);
}

function addGroupSubmitResult(data) {
    if (data.success) {
    	addedGroupId = data.data.id;
    	addGroupSaveAddedUsers();
    }
    else {
        alert(data.message);
    }
}

function addGroupSaveAddedUsers() {
	var editGroupAddedUsers = addGroupGetSelectedUsers();
	if (editGroupAddedUsers.length > 0) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'addUsersToGroup');
		ajaxPost(url,
			{
				'group' : addedGroupId,
				'users' : editGroupAddedUsers
			}, function(data) {
				if (data.success)
					addGroupSaveAddedGroups();
				else
					alert(data.message);
			});
	}
	else
		addGroupSaveAddedGroups();
}

function addGroupSaveAddedGroups() {
	var editGroupAddedGroups = addGroupGetSelectedGroups();
	if (editGroupAddedGroups.length > 0) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'addGroupsToGroup');
		ajaxPost(url,
			{
				'group' : addedGroupId,
				'groups' : editGroupAddedGroups
			}, function(data) {
				if (data.success)
					addGroupSubmitDone();
				else
					alert(data.message);
			});
	}
	else
		addGroupSubmitDone();
}

function addGroupSubmitDone() {
	hideAddGroupPane();
	hideManageUsersPane();
	showManageGroupsPane(addedGroupId);
}

function userNameOnlyRenderer(row, item) {
    createTableData(row, item.name || '');
}

function onAddGroupUserDataLoaded() {
	if (addGroupUserList.items.length > addGroupUserList.pageSize)
		$('#addGroupUserLoadedPrompt').text('Total: ' + addGroupUserList.items.length + ', Loaded: ' + addGroupUserList.numOfLoaded);
	else
		$('#addGroupUserLoadedPrompt').text('');
	
    var selectedIds = [];
    $('#addGroupTargetUsersTable').find('tr').each(function() {
    	selectedIds.push($(this).attr("objId"));
    });
	$('#addGroupSourceUsersTable').find('tr').each(function() {
		var id = $(this).attr("objId");
		for (var i = 0; i < selectedIds.length; ++i) {
			if (selectedIds[i] == id) {
				$(this).hide();
				break;
			}
		}
	});
}
