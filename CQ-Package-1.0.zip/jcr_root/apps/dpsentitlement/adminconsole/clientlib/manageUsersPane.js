/*******************************************************************************
 *  Copyright © 2015, Ensemble Systems Inc. ("Ensemble"). All rights reserved. 
 *  
 *  The copyright in this source code is owned by Ensemble and may only be used with the prior written permission of Ensemble. 
 *  
 *******************************************************************************/
/* 
 * manageUsersPane 
 */
var manageUserLastSelectedRow = null;
var autoScrollToUserId = null;
var manageUserSelectedUser;
var userList = null;

function initManageUsersPane() {
	userList = new PagedList('dpsAllUsersFolioTableContainer', 'allUsersFolioTable', null, 'user', userAndSourceRenderer, toggleAllUsersRow, onUserDataLoaded);
	
	resizePane($('#dpsAllUsersFolioTableContainer'),72);
	$('#manageUserEditUser').click(function() {
		setEditUserFolioFields(manageUserSelectedUser);
		if(userList.getItem(manageUserSelectedUser.id).isReadOnly){
		   	$('#editUserFNameInputTooltip').hide();
		    $('#editUserFNameInput').removeClass('dpsInvalidInput'); 
		}
		showEditUserPane();
		resizePane($('#dpsEditUser'),-13);
	});

	$('#manageUserDeleteUser').click(function() {
		manageUserDeleteUser();
	});
	
	$('#manageUserDeleteMultiUsers').click(function() {
		manageUserDeleteUser();
	});
	
	$.ajax({
		url: urlBase + "/SendPushNotificationService",
		statusCode: {
			200: function() {
				$('#userFolioDetailNotificationManagementRow').css('display', '' );
			}
		}
	});

	$.ajax({
		url: urlBase + UDID_SERVICE_PATH,
		statusCode: {
			200: function() {
				$('#userFolioDetailUdidManagementRow').css('display', '' );
			}
		}
	});
}

function showManageUsersPane(scrollToUser) {
	if (!dpsPageBlurHandler())
		return;
	resizePane($('#dpsAllUsersFolioTableContainer'),-4);
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;

	$('#dpsManageUsers').fadeIn(kTransitionDuration);
	$('#showUsersConsoleButton').addClass('active');
	$('#showGroupsConsoleButton').removeClass('active');
	$('#dpsManageGroups').fadeOut(0);

	userManagementAddEditUserGroupButtonVisibility(true);
	userManagementUserConsoleSelected = true;
	$('#dpsUserManagementSearchInput').val(''); // reset the search field empty

	refreshAllUsersFolio(scrollToUser);
	hideUserFolio();
	hideGroupFolio();
}

function hideManageUsersPane() {
	dpsPageBlurHandler = dpsDefaultPageBlurHandler;
	$('#dpsManageUsers').fadeOut(0);
}

function permissionToText(perm) {
	if (perm === 'READ_WRITE')
		return 'read/write';
	else if (perm === 'READ_ONLY')
		return 'read-only';
	else if (perm === 'DENY')
		return 'deny';
	
	return '';
}

function toggleAllUsersRow(e) {
	if (GetCtrlKeyState(e)) {
		$(this).toggleClass("dpsSelected");
	}
	else
	if (GetShiftKeyState(e)) {
		if (manageUserLastSelectedRow != null) {
			var lastIndex = getItemIndex($('#allUsersFolioTable'), manageUserLastSelectedRow);
			var index = getItemIndex($('#allUsersFolioTable'), this);
			var fm = index;
			var to = lastIndex;
			if (fm > to) {
				to = index;
				fm = lastIndex;
			}

			$('#allUsersFolioTable').find('.dpsSelected').each(function() {
				$(this).removeClass("dpsSelected");
			});

			var i = 0;
			$('#allUsersFolioTable').find('tr').each(function() {
				if (i >= fm && i <= to)
					$(this).addClass("dpsSelected");
				i++;
			});
		}
	}
	else {
		$('#allUsersFolioTable').find('.dpsSelected').each(function() {
			$(this).removeClass("dpsSelected");
		});
		$(this).toggleClass("dpsSelected");
	}
	manageUserLastSelectedRow = this;

	refreshUsersFolioDetail();
}

function hideUserFolio() {
	$('#SelectedSelf').fadeOut(kTransitionDuration);
	$("#singleUserFolioSelected").fadeOut(kTransitionDuration);
    $("#multipleUsersFolioSelected").fadeOut(kTransitionDuration);
    hideAddUserPane();
    hideAddMultiUserPane();
    hideEditUserPane();
}

function refreshUsersFolioDetail(){
    var selected = $('#allUsersFolioTable').find('.dpsSelected');
    var count = selected.length;
    if (count == 0) {
    	hideUserFolio();
    }
    else if (count == 1) {
    	showSingleUserFolioForId($(selected).attr('objId'));
    }
    else {
    	showMultiUsersFolio();
    }
}

function showSingleUserFolioForId(id) {
	refreshUserDetail(id);
}

function showMultiUsersFolio() {
	$("#singleUserFolioSelected").fadeOut(0);
    $("#multipleUsersFolioSelected").fadeIn(kTransitionDuration);
    
    refreshSelectedSelf(null);
    
    if (selectedReadOnlyUsers()) {
    	$("#manageUserDeleteMultiUsers").hide();
    	$("#manageUserDeleteMultiUsersWarning").show();
    	$("#readOnlyUsers").show();
    } else {
    	$("#manageUserDeleteMultiUsers").show();
    	$("#manageUserDeleteMultiUsersWarning").hide();
    	$("#readOnlyUsers").hide();
    }
}

function refreshSelectedSelf(json) {
	if (json != null && json.self)
		$("#SelectedSelf").fadeIn(kTransitionDuration);
	else
		$("#SelectedSelf").fadeOut(0);
}

function selectedReadOnlyUsers() {
	var selected = $('#allUsersFolioTable').find('.dpsSelected');
	var nameList = new Array();
	for (i = 0; i < selected.length; i++) {
		var user = userList.getItem(selected[i].getAttribute('objId'));
		if (user.isReadOnly) {
			nameList.push(user.name);
		}
	}
	$("#readOnlyUsers").text(nameList.join(", "));
	return nameList.length > 0;
}

function refreshAllUsersFolio(scrollToUser, filter) {
	hideUserFolio();
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, LIST_USER_SERVICE) + (filter ? '&filter=' + filter : '');
	userList.url = url;
	autoScrollToUserId = null;
	if (scrollToUser) {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, 'getUserIndex') + '&id=' + scrollToUser;
		ajaxGet(url, function(data) {
			if (data.success) {
				if (data.data.index >= 0) {
					autoScrollToUserId = scrollToUser;
					userList.showList(data.data.index);
				}
				else
					userList.showList(0);
			}
			else
				alert(data.message);
		});
	}
	else
		userList.showList(0);
}

function userAndSourceRenderer(row, item) {
    if (item.isReadOnly) {
    	var cell = createTableData(row, item.source.toUpperCase());
    	cell.innerHTML = '<p>' + item.source.toUpperCase() + '</p><span>' + item.source.toUpperCase() + ' users are not removable</sapn>';
    	cell.className = 'ldapUserLabel';
    }
    else
    	createTableData(row, '');

    createTableData(row, item.name || '');
}

function onUserDataLoaded() {
    if (autoScrollToUserId) {
    	var row = userList.getRow(autoScrollToUserId);
    	if (row != null) {
   			var howMuchToScroll = $(row).offset().top - $('#allUsersFolioTable').offset().top - $(row).height();
   	    	$('#dpsAllUsersFolioTableContainer').scrollTop(howMuchToScroll);
   	    	$(row).addClass('dpsSelected');
   	    	showSingleUserFolioForId(autoScrollToUserId);
    	}
    	autoScrollToUserId = null;
    }
    if (userList.items.length > userList.pageSize)
    	$('#userLoadedPrompt').text('Total: ' + userList.items.length + ', Loaded: ' + userList.numOfLoaded);
    else
    	$('#userLoadedPrompt').text('');
}

/*
 * Get user detail
 */
function refreshUserDetail(id) {
	hideUserFolio();
	var url = getActionUrl(USER_MANAGEMENT_SERVICE, "getUserDetail") + "&id=" + id;
   	ajaxGet(url, refreshUserDetailResult); 
}

function refreshUserDetailResult(data) {
    if (data.success) {
    	refreshUserDetailTable(data.data);
    }
    else {
    	refreshUserDetailTable(null);
        alert(data.message);
    }
}

function refreshUserDetailTable(json) {
	if (getCurrentCompany() != null && getCurrentCompany() != "")
		$('#userFolioDetailCompanyManagementRow').hide();
	else
		$('#userFolioDetailCompanyManagementRow').show();

	manageUserSelectedUser = json;
	if (json == null)
		hideUserFolio();
	else {
		refreshSelectedSelf(json);

		if (getUserPrivilege() === 'READ_WRITE' && !json.isReadOnly) {
			$('#manageUserDeleteUser').show();
		}
		else {
			$('#manageUserDeleteUser').hide();
		}

		if (json.isReadOnly) {
			$("#selectedUserNameLabel").html('<span>' + json.source + '</span> ' + json.firstName + ' ' + json.lastName);
		} else {$("#selectedUserNameLabel").html(json.firstName + ' ' + json.lastName);}
		$('#userDetailFName').val(json.firstName);
		$('#userDetailLName').val(json.lastName);
		$('#userDetailEmail').val(json.email);
		$('#userDetailLoginName').val(json.loginName);
		$('#userDetailFolioManagementPrivilege').val(permissionToText(json.productPrivilege));
		$('#userDetailUserManagementPrivilege').val(permissionToText(json.userPrivilege));
		$('#userDetailCompanyManagementPrivilege').val(permissionToText(json.companyPrivilege));
		$('#userDetailSettingManagementPrivilege').val(permissionToText(json.settingPrivilege));
		$('#userDetailNotificationManagementPrivilege').val(permissionToText(json.notificationPrivilege));
		$('#userDetailUdidManagementPrivilege').val(permissionToText(json.udidPrivilege));

		$("#singleUserFolioSelected").fadeIn(kTransitionDuration);
	    $("#multipleUsersFolioSelected").fadeOut(0);
	    
	    var url = getActionUrl(USER_MANAGEMENT_SERVICE, "getUserGroups") + "&id=" + json.id;
    	ajaxGet(url, function(data) {
    		if (data.success)
    			createAccessDenyTable("userDetailGroupsTable", "userDetailGroupsContainer", null, data.data, false, "group");
    	});
	}
}

/* delete user */
function manageUserDeleteUser() {
	var count = 0;
	var userList = '';
	var selected = $('#allUsersFolioTable').find('.dpsSelected').each(function() {
		if (userList.length > 0)
			userList += ',';
		userList += $(this).attr('objId');
		count++;
	});

	var confirmMsg = DELETE_USER_CONFIRMATION;
	var answer = confirm(confirmMsg);
	if (!answer)
		return;

	if (__DEBUG__) {
    	var json = jsonManageUsers_deleteUser;
    	refreshUserDetailResult(json, '', null);
    	console.warn("DEBUG manageUserDeleteUser");
    }
    else {
		var url = getActionUrl(USER_MANAGEMENT_SERVICE, "deleteUsers") + "&ids=" + userList;
		ajaxGet(url, manageUserDeleteUserResult);
    }
}

function manageUserDeleteUserResult(data) {
    if (data.success) {
    	hideUserFolio();
        refreshAllUsersFolio();
    }
    else {
        alert(data.message);
    }
}

function refreshSearchedUsersFolioTable(searchValue) {
	refreshAllUsersFolio(false, searchValue);
}

function generateUserList(json) {
	var list = [];
	for (var i = 0; i < json.items.length; ++i) {
		list.push(json.items[i]);
	}
	if (json.start + json.items.length < json.total)
		list.push({});
	return list;
}
